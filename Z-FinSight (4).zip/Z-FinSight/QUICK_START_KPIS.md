# Quick Start: Add Sample Data & Publish KPIs

## 🚀 Step 1: Add Sample Data (One-Time Setup)

Run this command in your terminal:

```bash
cd backend
npm run seed:sample
```

Or for a specific company:
```bash
node scripts/seedSampleData.js CMP_001
```

**What this does:**
- Creates 30+ accounts (Revenue, COGS, Expenses, Assets, Liabilities, Equity)
- Adds 13 sample transactions (Revenue: $100k, Expenses: $36k, etc.)
- Creates sample invoices and bills
- Sets up bank accounts

---

## 📊 Step 2: Publish KPIs from Accountant Dashboard

### Option A: Using Calculator (Easiest)

1. **Login** as Accountant user
2. Go to **Accountant Dashboard** → **Overview** page
3. Scroll to **"Profitability Calculator"** section
4. **Enter values:**
   ```
   Revenue:              100000
   COGS:                 40000
   Operating Expenses:   36000
   Interest Expense:      2000
   Taxes:                5600
   ```
5. **Click "Publish KPIs"** button
6. ✅ Done! KPIs are now published

### Option B: Using Calculated Data

1. **Login** as Accountant user
2. Go to **Accountant Dashboard** → **Overview** page
3. Click **"Refresh from server"** in KPI section
4. System calculates KPIs from your transactions
5. **Click "Publish KPIs"** button
6. ✅ Done! KPIs are now published

---

## 👀 Step 3: View Published KPIs in Admin Dashboard

1. **Login** as Admin user
2. Go to **Admin Dashboard** → **Overview** page
3. Look at the **second row of stat cards** (below Total Users, Active Users, etc.)
4. You should see:
   - **After-Tax Profit:** $16,400 (or your calculated value)
   - **Net Profit Margin:** 16.4% (or your calculated value)
   - **Tax Burden:** 25.45% (or your calculated value)
   - **Liquidity (Current Ratio):** 2.60 (or your calculated value)

---

## 📝 Example: Real Numbers from Seed Data

After running the seed script, you'll have:

**Transactions:**
- Revenue: $100,000 (3 transactions)
- COGS: $40,000 (3 transactions)
- Operating Expenses: $36,000 (7 transactions)
- Interest: $2,000 (1 transaction)
- Taxes: $5,600 (1 transaction)

**Expected KPIs:**
- Gross Profit: $60,000 (60% margin)
- Operating Profit: $24,000 (24% margin)
- Profit Before Tax: $22,000
- Net Profit After Tax: $16,400 (16.4% margin)
- Tax Burden: 25.45%

**Balance Sheet:**
- Current Assets: $112,000
- Current Liabilities: $43,000
- Current Ratio: 2.60

---

## 🔧 Troubleshooting

### KPIs show as zeros
- Make sure you clicked "Publish KPIs" (not just calculated)
- Check that you entered values in the calculator
- Verify you're logged in with the correct company

### "No published KPIs found"
- Go to Accountant Dashboard
- Enter values in calculator
- Click "Publish KPIs"
- Refresh Admin Dashboard

### Script fails
- Check MongoDB connection
- Verify company exists (companyId like "CMP_001")
- Check `.env` file has `MONGO_URI`

---

## 📚 More Information

See detailed guide: `backend/docs/HOW_TO_PUBLISH_KPIS.md`
