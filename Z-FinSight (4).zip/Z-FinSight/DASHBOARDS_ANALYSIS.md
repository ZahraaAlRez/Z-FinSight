# Dashboards & Pages Enhancement & Fix Analysis

## Overview
This document identifies issues, missing functionality, and enhancement opportunities for all dashboards and pages (excluding admin dashboard).

---

## 1. MANAGER DASHBOARD (`manager-dashboard.html`)

### 🔴 Critical Issues

1. **Hardcoded KPI Values**
   - `afterTaxProfit`, `netProfitMargin`, `taxBurden`, `liquidity` all show "—" (placeholder)
   - `fxRisk` hardcoded to "2%"
   - **Fix Needed:** Connect to real KPI API endpoints (`/api/kpis/latest` or similar)

2. **Company ID Issues**
   - `getCompanyId()` may return MongoDB ObjectId instead of public code
   - API calls pass `companyId` in query params, which `requireCompanyScope` middleware rejects
   - **Fix Needed:** 
     - Use `companyCode` (public ID) for news/top-companies APIs
     - Remove `companyId` from query params (middleware uses JWT token)

3. **API Endpoint Issues**
   - `/api/users/:companyId` - May not exist or expects different format
   - `/api/fx?companyId=...` - Endpoint may not exist
   - **Fix Needed:** Verify endpoints exist and use correct format

### 🟡 Medium Priority Issues

4. **Missing Features**
   - Analytics Hub page exists but may not have full functionality
   - Recommendations filtering not implemented
   - Team view is read-only (no actions)
   - Settings page may not save properly

5. **UI/UX Issues**
   - Charts use hardcoded SVG paths (not dynamic data)
   - No loading states for async operations
   - Error handling could be improved

### 🟢 Enhancement Opportunities

6. **Features to Add**
   - Real-time KPI updates
   - Export reports functionality
   - Advanced filtering for recommendations
   - Team member actions (view details, contact)
   - Notification system integration

---

## 2. ACCOUNTANT DASHBOARD (`accountant-dashboard.html`)

### 🔴 Critical Issues

1. **Company ID in Query Params**
   - All API calls pass `companyId` in query: `/api/stats/overview?companyId=...`
   - `requireCompanyScope` middleware rejects client-provided `companyId`
   - **Fix Needed:** Remove `companyId` from all query params (middleware uses JWT)

2. **Session Object Issues**
   - Uses `sess.companyId` which might be MongoDB ObjectId
   - Some endpoints need public code (like news/top-companies)
   - **Fix Needed:** 
     - Extract `companyCode` from JWT or fetch from API
     - Use appropriate ID type per endpoint

3. **Missing API Endpoints**
   - `/api/stats/overview` - May need to verify it exists and returns correct data
   - `/api/kpis/latest` - May not exist
   - **Fix Needed:** Verify endpoints or create missing ones

### 🟡 Medium Priority Issues

4. **Data Loading Issues**
   - Fallback to demo data when API fails (silent failure)
   - No user feedback when data fails to load
   - **Fix Needed:** Better error handling and user notifications

5. **Missing Features**
   - Transactions page may not have full CRUD operations
   - Reconciliation page may not be fully functional
   - Reports generation may not work
   - Uploads page functionality unclear

### 🟢 Enhancement Opportunities

6. **Features to Add**
   - Real-time transaction updates
   - Bulk transaction operations
   - Advanced reconciliation matching
   - Report templates and customization
   - File upload progress indicators
   - Export to Excel/PDF

---

## 3. FINANCIAL ANALYST DASHBOARD (`financial-dashboard.html`)

### 🔴 Critical Issues

1. **Wrong API Endpoints**
   - Uses `/api/market/top-companies` and `/api/market/news` (may not exist)
   - Should use `/api/top-companies` and `/api/news`
   - **Fix Needed:** Update API endpoint paths

2. **Company ID Issues**
   - `getCompanyId()` returns hardcoded "CMP_PREVIEW" as fallback
   - May not properly extract from JWT or localStorage
   - **Fix Needed:** Implement proper company code extraction (like admin dashboard)

3. **Hardcoded Calculator Values**
   - All input fields have hardcoded default values (120000, 65000, etc.)
   - No persistence of user inputs
   - **Fix Needed:** 
     - Load from saved snapshots or user preferences
     - Save user inputs to localStorage or backend

### 🟡 Medium Priority Issues

4. **Mock Data Fallbacks**
   - Falls back to `MOCK_TOP_COMPANIES` and `MOCK_NEWS` when API fails
   - Users may see fake data without knowing
   - **Fix Needed:** Show error messages instead of mock data

5. **Missing Features**
   - Reports page may not generate actual reports
   - Export functionality may not work
   - Snapshot saving/loading not implemented
   - Notes feature may not persist

### 🟢 Enhancement Opportunities

6. **Features to Add**
   - Save/load analysis scenarios
   - Historical KPI tracking
   - Comparison with industry benchmarks
   - Custom report builder
   - Data export in multiple formats
   - Collaboration features (share analysis)

---

## 4. EXTERNAL DASHBOARD (`external-dashboard.html`)

### 🔴 Critical Issues

1. **Many Features Not Implemented**
   - Reports: "MVP idea" - endpoint suggestions only
   - Documents: "MVP idea" - functionality unclear
   - Many endpoints marked as "suggested" not implemented
   - **Fix Needed:** Implement backend endpoints for external access

2. **Session/Authentication Issues**
   - Uses `requireExternalSession()` which may not work correctly
   - Pack-based access control may not be enforced on backend
   - **Fix Needed:** Verify external user authentication flow

3. **Missing Backend Endpoints**
   - `/api/external/reports/main` - Suggested, not implemented
   - `/api/external/reports/export` - Suggested, not implemented
   - Document sharing endpoints - Not implemented
   - **Fix Needed:** Create external-specific API routes

### 🟡 Medium Priority Issues

4. **Pack System**
   - Pack templates stored in localStorage (dev mode)
   - No backend persistence of pack configurations
   - **Fix Needed:** Store packs in database, enforce via backend

5. **Data Filtering**
   - Pack-based filtering may not work correctly
   - Some sections may show data they shouldn't
   - **Fix Needed:** Backend should filter data based on pack permissions

### 🟢 Enhancement Opportunities

6. **Features to Add**
   - Real document sharing with access control
   - Customizable report packs
   - Email notifications for shared reports
   - Download tracking and analytics
   - Time-limited access links

---

## 5. LOGIN PAGE (`login.html`)

### 🔴 Critical Issues

1. **API Base URL**
   - May have issues with `file://` protocol (like other pages)
   - **Fix Needed:** Ensure proper API_BASE detection

2. **Error Handling**
   - May not show specific error messages
   - **Fix Needed:** Improve error messages for invalid credentials, network errors, etc.

### 🟢 Enhancement Opportunities

3. **Features to Add**
   - "Remember me" functionality
   - Social login options
   - Password strength indicator
   - Two-factor authentication

---

## 6. REGISTER PAGE (`register.html`)

### ✅ Already Fixed
- Company registration flow
- Email verification
- User creation during registration

### 🟢 Enhancement Opportunities

1. **Features to Add**
   - Progress indicator for multi-step registration
   - Form validation improvements
   - Industry/country autocomplete
   - Terms & conditions acceptance

---

## 7. OTHER PAGES

### `reset-password.html`
- ✅ Already fixed (CORS, API_BASE, token handling)

### `change-password.html`
- ✅ Already fixed (redirect logic, error handling)

### `verify-email.html`
- **Check Needed:** Verify email verification flow works correctly

### `Identity_Cards_Page.html`
- **Check Needed:** Verify identity card generation works

### `index.html`
- **Check Needed:** Landing page functionality

---

## SUMMARY OF PRIORITY FIXES

### 🔴 HIGH PRIORITY (Critical - Breaks Functionality)

1. **All Dashboards:**
   - Fix `companyId` query parameter issues (remove from queries, use JWT)
   - Fix company code vs MongoDB ObjectId confusion
   - Update API endpoint paths to match backend

2. **Manager Dashboard:**
   - Connect KPI tiles to real API endpoints
   - Fix FX risk calculation

3. **Accountant Dashboard:**
   - Remove `companyId` from all query params
   - Fix session company ID extraction

4. **Financial Dashboard:**
   - Fix API endpoint paths (`/api/market/*` → `/api/*`)
   - Fix company ID extraction

5. **External Dashboard:**
   - Implement missing backend endpoints
   - Fix pack-based access control

### 🟡 MEDIUM PRIORITY (Enhancements)

1. **All Dashboards:**
   - Improve error handling and user feedback
   - Add loading states
   - Remove mock data fallbacks
   - Add proper empty states

2. **UI/UX Improvements:**
   - Make charts dynamic (use real data)
   - Add responsive design improvements
   - Improve accessibility

### 🟢 LOW PRIORITY (Nice to Have)

1. **Feature Additions:**
   - Real-time updates
   - Advanced filtering
   - Export functionality
   - Collaboration features

---

## RECOMMENDED ACTION PLAN

1. **Phase 1: Critical Fixes (Do First)**
   - Fix company ID issues across all dashboards
   - Remove `companyId` from query params
   - Fix API endpoint paths
   - Verify all endpoints exist

2. **Phase 2: Data Integration**
   - Connect hardcoded values to real APIs
   - Implement missing KPI endpoints
   - Fix calculator data persistence

3. **Phase 3: External Dashboard**
   - Create external API routes
   - Implement pack-based access control
   - Add document sharing

4. **Phase 4: Enhancements**
   - UI/UX improvements
   - Advanced features
   - Performance optimizations
