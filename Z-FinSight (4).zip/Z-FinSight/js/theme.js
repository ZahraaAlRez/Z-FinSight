const btn = document.getElementById("themeToggle");

function setTheme(theme){
  document.body.dataset.theme = theme;
  localStorage.setItem("theme", theme);
  btn.textContent = theme === "dark" ? "☀️" : "🌙";
}

const saved = localStorage.getItem("theme") || "light";
setTheme(saved);

btn.addEventListener("click", () => {
  const current = document.body.dataset.theme || "light";
  setTheme(current === "light" ? "dark" : "light");
});
