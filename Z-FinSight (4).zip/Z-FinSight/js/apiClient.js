// js/apiClient.js
const API_BASE = "http://localhost:4001";

function getToken() {
  return localStorage.getItem("token");
}

async function api(path, { method="GET", body, headers={} } = {}) {
  const token = getToken();

  const res = await fetch(`${API_BASE}${path}`, {
    method,
    headers: {
      "Content-Type": body instanceof FormData ? undefined : "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...headers,
    },
    body: body
      ? (body instanceof FormData ? body : JSON.stringify(body))
      : undefined,
  });

  const data = await res.json().catch(() => ({}));

  if (res.status === 401) {
    localStorage.removeItem("token");
    window.location.href = "login.html";
    return;
  }

  if (!res.ok) throw new Error(data.message || "Request failed");
  return data;
}
