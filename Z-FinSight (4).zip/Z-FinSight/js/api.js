// backend/public/js/api.js (or wherever you serve it)
// Compatibility layer for older dashboards that expect api.js
(function () {
  if (window.__ZF_API_LOADED__) return;
  window.__ZF_API_LOADED__ = true;

  const DEFAULT_API = "http://localhost:4001";

  // Keep API base consistent with auth.js
  const storedApi =
    localStorage.getItem("zf_api_base") ||
    localStorage.getItem("API_BASE") ||
    localStorage.getItem("api_base");

  window.API_BASE = window.API_BASE || storedApi || DEFAULT_API;

  try {
    localStorage.setItem("zf_api_base", window.API_BASE);
  } catch {}

  function getTokenCompat() {
    // If auth.js already exposed getToken(), use it
    try {
      if (typeof window.getToken === "function") return window.getToken() || "";
    } catch {}

    // Otherwise fallback to known keys
    return (
      localStorage.getItem("zf_token") ||
      localStorage.getItem("auth_token") ||
      localStorage.getItem("token") ||
      ""
    );
  }

  function getAuthHeaders(extra = {}) {
    const t = getTokenCompat();
    return Object.assign({}, extra, t ? { Authorization: "Bearer " + t } : {});
  }

  async function apiFetchCompat(path, opts = {}) {
    const p = path.startsWith("/") ? path : `/${path}`;
    const url = `${window.API_BASE}${p}`;

    const headers = new Headers(opts.headers || {});
    if (!headers.has("Content-Type") && !(opts.body instanceof FormData)) {
      headers.set("Content-Type", "application/json");
    }

    const token = getTokenCompat();
    if (token) headers.set("Authorization", `Bearer ${token}`);

    const res = await fetch(url, { ...opts, headers });

    const ct = res.headers.get("content-type") || "";
    let data = null;
    if (ct.includes("application/json")) data = await res.json().catch(() => null);
    else data = await res.text().catch(() => null);

    if (!res.ok) {
      const msg = (data && data.message) || `Request failed (${res.status})`;
      const err = new Error(msg);
      err.status = res.status;
      err.data = data;
      throw err;
    }

    return data;
  }

  // Don't override auth.js implementations if they exist
  window.getAuthHeaders = window.getAuthHeaders || getAuthHeaders;
  window.apiFetch = window.apiFetch || apiFetchCompat;
})();
