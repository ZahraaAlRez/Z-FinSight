(() => {
  // Prevent double-loading
  if (window.__ZF_AUTH_LOADED__) return;
  window.__ZF_AUTH_LOADED__ = true;

  // -----------------------------------------
  // API base (dev)
  // -----------------------------------------
  const DEFAULT_API = "http://localhost:4001";
  const storedApi =
    localStorage.getItem("zf_api_base") ||
    localStorage.getItem("API_BASE") ||
    localStorage.getItem("api_base");

  window.API_BASE = window.API_BASE || storedApi || DEFAULT_API;

  try {
    localStorage.setItem("zf_api_base", window.API_BASE);
  } catch {}

  // -----------------------------------------
  // LocalStorage keys (backward compatible)
  // -----------------------------------------
  function getToken() {
    return (
      localStorage.getItem("zf_token") ||
      localStorage.getItem("auth_token") ||
      localStorage.getItem("token") ||
      ""
    );
  }

  function getCurrentUser() {
    try {
      const raw =
        localStorage.getItem("zf_user") ||
        localStorage.getItem("auth_user") ||
        localStorage.getItem("user");
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  }

  function decodeJwtPayload(token) {
    try {
      const part = token.split(".")[1];
      if (!part) return null;
      const json = atob(part.replace(/-/g, "+").replace(/_/g, "/"));
      return JSON.parse(json);
    } catch {
      return null;
    }
  }

  function isJwtExpired(token) {
    const payload = token ? decodeJwtPayload(token) : null;
    if (!payload || !payload.exp) return false; // if no exp, don't block
    const nowSec = Math.floor(Date.now() / 1000);
    return payload.exp <= nowSec;
  }

  function normalizeRole(user, token) {
    // Priority:
    // 1) user.roles[0]
    // 2) user.role / user.userRole
    // 3) localStorage userRole
    // 4) JWT payload.role / roles[0]
    const uRoles = user && (user.roles || user.role || user.userRole);

    let r = "";
    if (Array.isArray(uRoles) && uRoles.length) r = String(uRoles[0] || "");
    else if (typeof uRoles === "string") r = uRoles;

    if (!r) {
      const legacy = localStorage.getItem("userRole");
      if (legacy) r = legacy;
    }

    if (!r && token) {
      const payload = decodeJwtPayload(token);
      if (payload) {
        if (payload.role) r = payload.role;
        else if (Array.isArray(payload.roles) && payload.roles.length) r = payload.roles[0];
      }
    }

    r = String(r || "").toLowerCase().trim();

    // normalize variants
    if (r === "financial analyst" || r === "financial_analyst" || r === "analyst") return "financial";
    if (r === "external user" || r === "external_user") return "external";

    return r || "user";
  }

  function pickCompanyId(user, token) {
    const fromUser =
      user && (user.companyId || user.company_id || user.company || user.companyPublicId);

    const fromStorage =
      localStorage.getItem("companyId") ||
      localStorage.getItem("companyPublicId");

    const payload = token ? decodeJwtPayload(token) : null;
    const fromToken = payload && (payload.companyId || payload.companyPublicId);

    // IMPORTANT: no hard-coded DEV id in production flows
    return fromUser || fromStorage || fromToken || "";
  }

  function pickCompanyName(user) {
    return (
      (user && (user.companyName || user.company_name || user.companyTitle || user.company)) ||
      localStorage.getItem("companyName") ||
      "Company"
    );
  }

  function pickFullName(user) {
    return (
      (user && (user.fullName || user.full_name || user.name || user.username || user.email)) ||
      localStorage.getItem("username") ||
      "User"
    );
  }

  function pickCompanyCode(user, token) {
    const fromUser = user && (user.companyCode || user.company_code);
    const fromStorage = localStorage.getItem("companyCode");
    const payload = token ? decodeJwtPayload(token) : null;
    const fromToken = payload && payload.companyCode;
    return fromUser || fromStorage || fromToken || "";
  }

  function ensureSession(token, user) {
    const companyCode = pickCompanyCode(user, token);
    try {
      const current = JSON.parse(localStorage.getItem("session") || "{}");
      if (current && current.role) {
        if (companyCode && !current.companyCode) {
          current.companyCode = companyCode;
          try { localStorage.setItem("session", JSON.stringify(current)); } catch {}
          if (companyCode) try { localStorage.setItem("companyCode", companyCode); } catch {}
        }
        return current;
      }
    } catch {}

    const sess = {
      role: normalizeRole(user, token),
      fullName: pickFullName(user),
      companyId: pickCompanyId(user, token),
      companyCode: companyCode || undefined,
      companyName: pickCompanyName(user),
      externalType:
        (user && (user.externalType || user.external_type)) ||
        localStorage.getItem("externalType") ||
        "",
    };

    try { localStorage.setItem("session", JSON.stringify(sess)); } catch {}
    try { localStorage.setItem("userRole", sess.role); } catch {}
    try { localStorage.setItem("username", sess.fullName); } catch {}
    try { localStorage.setItem("companyId", sess.companyId); } catch {}
    try { localStorage.setItem("companyPublicId", sess.companyId); } catch {}
    try { localStorage.setItem("companyName", sess.companyName); } catch {}
    if (companyCode) try { localStorage.setItem("companyCode", companyCode); } catch {}

    return sess;
  }

  function setAuth(token, user) {
    if (token) {
      localStorage.setItem("zf_token", token);
      // legacy keys
      localStorage.setItem("auth_token", token);
      localStorage.setItem("token", token);
    }

    if (user) {
      const uStr = JSON.stringify(user);
      localStorage.setItem("zf_user", uStr);
      // legacy keys
      localStorage.setItem("auth_user", uStr);
      localStorage.setItem("user", uStr);

      if (Array.isArray(user.roles)) {
        localStorage.setItem("roles", JSON.stringify(user.roles));
        localStorage.setItem("userRole", String(user.roles[0] || "user").toLowerCase());
      } else if (user.role) {
        localStorage.setItem("userRole", String(user.role).toLowerCase());
      }

      if (typeof user.mustChangePassword === "boolean") {
        localStorage.setItem("mustChangePassword", String(user.mustChangePassword));
      }
      
      // Store companyCode and companyDbId if available
      if (user.companyCode) {
        localStorage.setItem("companyCode", user.companyCode);
        console.log("✅ Stored companyCode from user:", user.companyCode);
      }
      if (user.companyId) {
        // Check if it's MongoDB ObjectId (24 hex chars) or public code
        if (String(user.companyId).match(/^[0-9a-f]{24}$/i)) {
          localStorage.setItem("companyDbId", user.companyId);
          console.log("✅ Stored companyDbId from user:", user.companyId);
        } else {
          // It's a public code, store as companyCode
          if (!localStorage.getItem("companyCode")) {
            localStorage.setItem("companyCode", user.companyId);
            console.log("✅ Stored companyCode from user.companyId:", user.companyId);
          }
        }
      }
      
      // Also extract from token if not already stored
      if (token && !localStorage.getItem("companyCode")) {
        try {
          const payload = decodeJwtPayload(token);
          if (payload && payload.companyCode) {
            localStorage.setItem("companyCode", payload.companyCode);
            console.log("✅ Stored companyCode from token:", payload.companyCode);
          }
          if (payload && payload.companyId && !localStorage.getItem("companyDbId")) {
            localStorage.setItem("companyDbId", payload.companyId);
            console.log("✅ Stored companyDbId from token:", payload.companyId);
          }
        } catch(e) {
          console.warn("Could not extract from token in setAuth:", e);
        }
      }
    }

    // Keep dashboards that depend on session working
    ensureSession(token || getToken(), user || getCurrentUser());
  }

  function clearAuth() {
    [
      "zf_token","zf_user",
      "auth_token","auth_user",
      "token","user",
      "roles","userRole","mustChangePassword","username",
      "session","isAdmin",
      "companyId","companyPublicId","companyName","companyCode","companyDbId",
      "externalType"
    ].forEach((k) => {
      try { localStorage.removeItem(k); } catch {}
    });
  }

  // -----------------------------------------
  // Fetch helper (adds Authorization)
  // -----------------------------------------
  async function apiFetch(path, opts = {}) {
    const p = path.startsWith("/") ? path : `/${path}`;
    const url = `${window.API_BASE}${p}`;
    const token = getToken();

    const headers = new Headers(opts.headers || {});
    
    // Handle body - stringify if it's an object and not FormData
    let body = opts.body;
    if (body && !(body instanceof FormData) && typeof body === 'object') {
      body = JSON.stringify(body);
      if (!headers.has("Content-Type")) {
        headers.set("Content-Type", "application/json");
      }
    } else if (!headers.has("Content-Type") && !(body instanceof FormData)) {
      headers.set("Content-Type", "application/json");
    }
    
    if (token) headers.set("Authorization", `Bearer ${token}`);

    const res = await fetch(url, {
      ...opts,
      headers,
      body: body || opts.body, // Use processed body
    });

    const ct = res.headers.get("content-type") || "";
    let data = null;
    if (ct.includes("application/json")) data = await res.json().catch(() => null);
    else data = await res.text().catch(() => null);

    if (!res.ok) {
      const msg = (data && data.message) || `Request failed (${res.status})`;
      const err = new Error(msg);
      err.status = res.status;
      err.data = data;
      throw err;
    }

    return data;
  }

  // Compatibility helper used by some dashboards
  function getAuthHeaders(extra = {}) {
    const token = getToken();
    return Object.assign({}, extra, token ? { Authorization: "Bearer " + token } : {});
  }

  // -----------------------------------------
  // Guards / Routing
  // -----------------------------------------
  function roleToDashboard(role) {
    const r = String(role || "").toLowerCase();
    if (r === "admin") return "admin-dashboard.html";
    if (r === "manager") return "manager-dashboard.html";
    if (r === "accountant") return "accountant-dashboard.html";
    if (r === "financial") return "financial-dashboard.html";
    if (r === "external") return "external-dashboard.html";
    return "login.html";
  }

  function requireAuth(options = {}) {
    const { allowMustChangePassword = false } = options;

    const token = getToken();
    const user = getCurrentUser();

    if (!token || !user) {
      window.location.href = "login.html";
      return false;
    }

    // ✅ Token expiry guard
    if (isJwtExpired(token)) {
      clearAuth();
      window.location.href = "login.html";
      return false;
    }

    // Keep session always available for dashboards that rely on it
    ensureSession(token, user);

    if (!allowMustChangePassword && user.mustChangePassword === true) {
      window.location.href = "change-password.html";
      return false;
    }

    return true;
  }

  async function getMe() {
    return apiFetch("/api/auth/me");
  }

  async function guardPage(options = {}) {
    const { allowedRoles, allowMustChangePassword = false } = options;

    if (!requireAuth({ allowMustChangePassword })) return false;

    const token = getToken();
    const user = getCurrentUser();
    const role = normalizeRole(user, token);

    if (Array.isArray(allowedRoles) && allowedRoles.length) {
      const ok = allowedRoles.map(r => String(r).toLowerCase()).includes(role);
      if (!ok) {
        window.location.href = roleToDashboard(role);
        return false;
      }
    }

    // Optional: validate token quickly if /api/auth/me exists
    try {
      await getMe();
      return true;
    } catch (e) {
      // If /me doesn't exist, don't block the UI (dev mode)
      if (e && (e.status === 404 || e.status === 405)) return true;

      // Network/CORS errors often have no status.
      if (!e || typeof e.status === "undefined") {
        console.warn("GuardPage: /api/auth/me unreachable (network/CORS). Skipping validation in dev.", e);
        return true;
      }

      // Only force logout on auth failures.
      if (e.status === 401 || e.status === 403) {
        clearAuth();
        window.location.href = "login.html";
        return false;
      }

      console.error("GuardPage: /api/auth/me error (non-auth). Keeping session.", e);
      return true;
    }
  }

  function logout(redirectTo = "login.html") {
    clearAuth();
    window.location.href = redirectTo;
  }

  // Export globally
  window.getToken = getToken;
  window.getCurrentUser = getCurrentUser;
  window.setAuth = setAuth;
  window.clearAuth = clearAuth;
  window.logout = logout;

  window.apiFetch = apiFetch;
  window.getAuthHeaders = window.getAuthHeaders || getAuthHeaders;

  window.requireAuth = requireAuth;
  window.getMe = getMe;
  window.guardPage = guardPage;
  window.authFetch = window.apiFetch;
})();
