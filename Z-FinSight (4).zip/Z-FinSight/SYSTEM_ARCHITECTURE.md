# Z-FinSight System Architecture & Flow Documentation

## 📋 Table of Contents
1. [System Overview](#system-overview)
2. [User Roles & Dashboards](#user-roles--dashboards)
3. [Data Flow Architecture](#data-flow-architecture)
4. [File Structure](#file-structure)
5. [Database Models](#database-models)
6. [API Endpoints](#api-endpoints)
7. [Security & Permissions](#security--permissions)
8. [Key Workflows](#key-workflows)

---

## 🎯 System Overview

**Z-FinSight** is a multi-tenant financial management system that enables companies to:
- Track financial transactions and KPIs
- Generate financial reports and insights
- Share read-only data with external stakeholders (banks, investors, auditors)
- Get AI-powered recommendations based on financial data

### Core Principles
- **Multi-tenant**: Each company has isolated data (company-scoped)
- **Role-based access**: Different dashboards for different user roles
- **Data security**: External users only see published snapshots, never raw data
- **Audit trail**: All actions are logged for compliance

---

## 👥 User Roles & Dashboards

### 1. **Admin** (`admin-dashboard.html`)
**Purpose**: System-wide administration and oversight

**Key Features**:
- Manage all companies in the system
- Create/manage users across companies
- System-wide analytics and monitoring
- Access to all company data
- Subscription management
- Audit logs

**Access Level**: Full system access

**Main Sections**:
- Overview (system stats)
- Analytics Hub
- Recommendations
- News & Competitors
- Users & Access Management
- Companies Management
- Subscriptions
- Audit Logs

---

### 2. **Manager** (`manager-dashboard.html`)
**Purpose**: Strategic oversight and decision-making for their company

**Key Features**:
- View published KPIs from Accountant
- Strategic analytics (profitability, market, efficiency, debt, liquidity)
- Recommendations (internal/external)
- News and competitor analysis
- Team view (read-only)
- **External Sharing**: Publish snapshots for external users
- Company settings

**Access Level**: Company-scoped, strategic view

**Data Sources**:
- Reads from `KpiSnapshot` (published by Accountant)
- Reads from `Recommendation` model
- Reads from `NewsItem` model
- Can publish to `ExternalSnapshot` model

**Main Sections**:
- Overview (KPI cards, charts)
- Analytics Hub (Tax, Profitability, Market, Efficiency, Debt, Liquidity)
- Recommendations Center
- News & Competitors
- Team (View Only)
- **External Sharing** (NEW: Publish external snapshots)
- Company Settings

---

### 3. **Accountant** (`accountant-dashboard.html`)
**Purpose**: Day-to-day financial data entry and transaction management

**Key Features**:
- Enter transactions (income, expenses, transfers)
- Reconcile bank statements
- Calculate and publish KPIs
- Generate financial reports
- View team (read-only)
- Upload documents

**Access Level**: Company-scoped, operational data entry

**Data Sources**:
- Creates `Transaction` records
- Creates `TransactionLine` records
- Creates `KpiSnapshot` records (published KPIs)
- Reads from `Account` model (chart of accounts)

**Main Sections**:
- Overview (Today's tasks, cash snapshot)
- Transactions (CRUD operations)
- Reconciliation
- Reports
- Recommendations
- News & Competitors
- Uploads
- Team (View Only)
- Company Settings

**Critical Workflow**:
1. Enter transactions → `Transaction` collection
2. Reconcile bank statements → Match transactions
3. Calculate KPIs → `POST /api/kpis/calculate`
4. **Publish KPIs** → `POST /api/kpis/publish` → Creates `KpiSnapshot`

---

### 4. **Financial Analyst** (`financial-dashboard.html`)
**Purpose**: Advanced financial analysis and reporting

**Key Features**:
- Deep financial analysis
- Advanced reporting
- Trend analysis
- Financial modeling

**Access Level**: Company-scoped, analytical view

**Note**: Currently in development, similar to Manager but focused on analysis

---

### 5. **External User** (`external-dashboard.html`)
**Purpose**: Read-only portal for external stakeholders

**Key Features**:
- View published financial snapshots (read-only)
- Pack-based visibility (Bank/Investor/Auditor/Partner)
- Limited reports and documents
- Recommendations (if enabled for pack)
- News (if enabled for pack)

**Access Level**: Read-only, pack-scoped, company-scoped

**External Types**:
- `bank`: Bank Pack (liquidity, debt, DSCR, cash runway)
- `investor`: Investor Pack (profitability, growth, market news)
- `auditor`: Auditor Pack (documents, statements, audit notes)
- `partner`: Partner Pack (selected KPIs, limited docs)

**Data Sources**:
- **ONLY** reads from `ExternalSnapshot` model
- **NEVER** accesses raw internal data (`Transaction`, `KpiSnapshot`, etc.)

**Main Sections** (visibility depends on pack):
- Overview (KPIs from published snapshot)
- Reports (if `allowExport: true`)
- News (if `allowNews: true`)
- Top Companies (if `allowTopCompanies: true`)
- Documents (if `allowDocs: true`)
- Notes
- Recommendations (external/internal based on pack flags)
- Settings

**Security**:
- Pack type comes from JWT token (`req.user.externalType`)
- Company scope enforced via token
- Access expiry checked
- No write operations allowed

---

## 🔄 Data Flow Architecture

### High-Level Flow

```
┌─────────────────┐
│   Accountant    │
│   Dashboard     │
└────────┬────────┘
         │
         │ 1. Enters Transactions
         ▼
┌─────────────────┐
│   Transaction   │
│     Model       │
└────────┬────────┘
         │
         │ 2. Calculates KPIs
         ▼
┌─────────────────┐
│  KpiSnapshot    │
│     Model       │
└────────┬────────┘
         │
         │ 3. Manager Reviews
         ▼
┌─────────────────┐
│    Manager      │
│   Dashboard     │
└────────┬────────┘
         │
         │ 4. Publishes External Snapshot
         ▼
┌─────────────────┐
│ ExternalSnapshot│
│     Model       │
└────────┬────────┘
         │
         │ 5. External User Views
         ▼
┌─────────────────┐
│    External     │
│   Dashboard     │
└─────────────────┘
```

### Detailed Data Flow

#### Step 1: Accountant Enters Data
```
Accountant Dashboard
  → POST /api/transactions
  → Creates Transaction + TransactionLine records
  → Stored in: Transaction collection
```

#### Step 2: Accountant Calculates & Publishes KPIs
```
Accountant Dashboard
  → GET /api/kpis/calculate (calculates from transactions)
  → POST /api/kpis/publish
  → Creates KpiSnapshot record
  → Stored in: KpiSnapshot collection
  → Fields: revenue, cogs, operating_expenses, afterTaxProfit, netMargin, taxBurden, liquidity, etc.
```

#### Step 3: Manager Views Published KPIs
```
Manager Dashboard
  → GET /api/kpis/latest
  → Reads from: KpiSnapshot collection (latest published)
  → Displays: After-Tax Profit, Net Margin, Tax Burden, Liquidity
```

#### Step 4: Manager Publishes External Snapshot
```
Manager Dashboard (External Sharing page)
  → Loads data from KpiSnapshot
  → Customizes what to share (pack-scoped)
  → POST /api/external/publish
  → Creates ExternalSnapshot record
  → Stored in: ExternalSnapshot collection
  → Fields: metrics, reports, docs, note, packType, period
```

#### Step 5: External User Views Snapshot
```
External Dashboard
  → GET /api/external/pack (gets pack config from token)
  → GET /api/external/snapshot (gets published snapshot)
  → Reads from: ExternalSnapshot collection ONLY
  → Displays: Pack-filtered data
```

---

## 📁 File Structure

### Frontend Files (Root Directory)

```
Z-FinSight/
├── index.html                    # Landing page
├── login.html                    # Login page (routes to dashboards)
├── register.html                 # Company registration
├── reset-password.html           # Password reset
├── change-password.html          # Change password (first login)
├── verify-email.html            # Email verification
│
├── admin-dashboard.html          # Admin dashboard
├── manager-dashboard.html        # Manager dashboard
├── accountant-dashboard.html     # Accountant dashboard
├── financial-dashboard.html      # Financial Analyst dashboard
├── external-dashboard.html       # External user portal (read-only)
│
├── js/
│   ├── auth.js                  # Authentication utilities
│   ├── api.js                   # API client functions
│   ├── lang.js                  # Internationalization (i18n)
│   └── Role_router.js           # Role-based routing
│
└── css/
    ├── main.css                 # Main styles
    ├── variables.css            # CSS variables
    └── register.css             # Registration styles
```

### Backend Files (`backend/`)

```
backend/
├── server.js                    # Express app entry point
│
├── models/                      # MongoDB models (Mongoose)
│   ├── User.js                  # User model (roles, externalType)
│   ├── Company.js               # Company model (multi-tenant)
│   ├── Transaction.js           # Financial transactions
│   ├── TransactionLine.js       # Transaction line items
│   ├── Account.js                # Chart of accounts
│   ├── KpiSnapshot.js            # Published KPI snapshots
│   ├── ExternalSnapshot.js       # Published external snapshots
│   ├── Recommendation.js         # AI recommendations
│   ├── NewsItem.js               # News items
│   ├── Notification.js           # User notifications
│   └── ... (other models)
│
├── routes/                       # API route handlers
│   ├── auth.js                  # Authentication (login, register)
│   ├── users.js                 # User management
│   ├── companies.js             # Company management
│   ├── transactions.js          # Transaction CRUD
│   ├── kpis.js                  # KPI calculation & publishing
│   ├── external.js              # External portal (read-only)
│   ├── recommendations.js       # Recommendations
│   ├── news.js                  # News items
│   ├── reports.js               # Financial reports
│   ├── reconcile.js             # Bank reconciliation
│   └── ... (other routes)
│
├── middleware/
│   ├── authGuard.js             # Authentication & authorization
│   ├── validators.js            # Request validation (Zod)
│   └── ... (other middleware)
│
├── utils/
│   ├── accountingCalculations.js # KPI calculation formulas
│   ├── balanceSheetCalculations.js
│   ├── dashboardCalculations.js
│   └── ... (other utilities)
│
└── services/
    ├── aiRecommendationEngine.js
    ├── newsProvider.js
    ├── fxProvider.js
    └── ... (other services)
```

---

## 🗄️ Database Models

### Core Models

#### 1. **Company** (`Company.js`)
```javascript
{
  companyId: "CMP_001",           // Auto-generated public ID
  companyName: "Acme Corp",
  industry: "retail",
  country: "lebanon",
  currencies: ["USD", "LBP"],
  isActive: true,
  isVerified: false
}
```
**Purpose**: Multi-tenant isolation, company profile

---

#### 2. **User** (`User.js`)
```javascript
{
  companyId: ObjectId,            // Links to Company
  email: "user@example.com",     // Unique globally
  username: "john",                // Unique per company
  fullName: "John Doe",
  roles: ["accountant"],          // Array of roles
  externalType: "bank",           // For external users
  allowedModules: ["profitability", "liquidity"],
  accessExpiry: Date,             // For external users
  isActive: true
}
```
**Purpose**: User accounts, role-based access control

---

#### 3. **Transaction** (`Transaction.js`)
```javascript
{
  companyId: "CMP_001",
  date: Date,
  description: "Invoice payment",
  type: "income" | "expense" | "transfer",
  amount: Number,
  currency: "USD",
  account_id: ObjectId,           // Links to Account
  // ... other fields
}
```
**Purpose**: Financial transaction records (created by Accountant)

---

#### 4. **KpiSnapshot** (`KpiSnapshot.js`)
```javascript
{
  companyId: "CMP_001",
  period: "2026-01",
  revenue: Number,
  cogs: Number,
  operating_expenses: Number,
  afterTaxProfit: Number,
  netMargin: Number,
  taxBurden: Number,
  current_ratio: Number,
  is_current: true,               // Latest published snapshot
  createdBy: "userId",
  createdAt: Date
}
```
**Purpose**: Published KPI snapshots (created by Accountant, read by Manager)

---

#### 5. **ExternalSnapshot** (`ExternalSnapshot.js`)
```javascript
{
  companyId: "CMP_001",
  packType: "bank" | "investor" | "auditor" | "partner",
  period: "2026-01",
  metrics: {
    netProfit: Number,
    netMargin: Number,
    liquidity: Number,
    debtEquity: Number,
    cashBank: Number
  },
  liquidity: { currentRatio, quickRatio, notes },
  debt: { debtEquity, dscr, notes },
  cashflow: { cashIn, cashOut, net },
  reports: [{ title, url, type }],
  docs: [{ title, url, type }],
  note: String,
  isCurrent: true,                // Latest snapshot for pack
  publishedBy: "userId",
  publishedAt: Date
}
```
**Purpose**: Published external snapshots (created by Manager, read by External users)

---

#### 6. **Recommendation** (`Recommendation.js`)
```javascript
{
  companyId: "CMP_001",
  type: "internal" | "external",
  category: "Market Opportunity" | "Risk Mitigation" | ...,
  priority: "Critical" | "High" | "Medium" | "Low",
  title: String,
  insight: String,
  recommendations: [String],
  status: "new" | "viewed" | "implemented"
}
```
**Purpose**: AI-generated recommendations for internal/external users

---

## 🔌 API Endpoints

### Authentication
- `POST /api/auth/user-login` - User login
- `POST /api/auth/admin-login` - Admin login
- `GET /api/auth/me` - Get current user
- `POST /api/register` - Company registration

### Transactions (Accountant)
- `GET /api/transactions` - List transactions
- `POST /api/transactions` - Create transaction
- `PUT /api/transactions/:id` - Update transaction
- `DELETE /api/transactions/:id` - Delete transaction

### KPIs (Accountant → Manager)
- `GET /api/kpis/calculate` - Calculate KPIs from transactions
- `POST /api/kpis/publish` - Publish KPI snapshot
- `GET /api/kpis/latest` - Get latest published snapshot
- `GET /api/kpis/timeseries?metric=net_profit_after_tax&period=12m` - Historical data

### External Portal (Manager → External)
- `GET /api/external/pack` - Get pack configuration (from token)
- `GET /api/external/snapshot` - Get latest published snapshot
- `GET /api/external/reports` - Get reports list
- `GET /api/external/recommendations?type=external` - Get recommendations
- `GET /api/external/documents` - Get documents list
- `POST /api/external/publish` - Publish external snapshot (Manager/Admin only)
- `GET /api/external/publish/history` - Publishing history

### Recommendations
- `GET /api/recommendations` - List recommendations
- `GET /api/recommendations/stats` - Statistics by priority/status
- `POST /api/recommendations` - Create recommendation

### News
- `GET /api/news` - List news items
- `GET /api/news/sentiment?range=30d` - Sentiment trend data

### Risk & FX
- `GET /api/risk/fx` - FX risk level calculation

---

## 🔒 Security & Permissions

### Authentication Flow
1. User logs in → `POST /api/auth/user-login`
2. Backend validates credentials
3. JWT token generated with:
   - `userId`, `roles`, `companyId`, `companyCode`, `externalType` (if external)
4. Token stored in `localStorage`
5. All API requests include: `Authorization: Bearer <token>`

### Authorization Middleware

#### `requireAuth`
- Validates JWT token
- Extracts user info to `req.user`
- Rejects if token missing/invalid/expired

#### `requireRoles(["admin", "manager"])`
- Checks if user has required role
- Admin bypass for admin role
- Rejects if role not found

#### `requireCompanyScope`
- Enforces company isolation
- Uses `req.user.companyId` from token
- Rejects if companyId mismatch

#### `checkExternalAccess`
- For external users only
- Checks `accessExpiry` date
- Rejects if access expired

### External Portal Security Rules

1. **Pack Type**: Comes from JWT token (`req.user.externalType`), **NEVER** from query params
2. **Company Scope**: Enforced via token, external users can only see their assigned company
3. **Read-Only**: External users have **NO** write endpoints
4. **Data Source**: External users **ONLY** read from `ExternalSnapshot`, **NEVER** from raw data
5. **Access Expiry**: Checked on every request

---

## 🔄 Key Workflows

### Workflow 1: Accountant Publishes KPIs

```
1. Accountant enters transactions
   → POST /api/transactions
   → Stored in Transaction collection

2. Accountant calculates KPIs
   → GET /api/kpis/calculate
   → Calculates: revenue, expenses, profit, margins, ratios

3. Accountant publishes KPIs
   → POST /api/kpis/publish
   → Creates KpiSnapshot with is_current: true
   → Previous snapshot marked is_current: false

4. Manager dashboard automatically shows new KPIs
   → GET /api/kpis/latest
   → Reads latest KpiSnapshot
```

### Workflow 2: Manager Publishes External Snapshot

```
1. Manager reviews published KPIs
   → GET /api/kpis/latest
   → Views in Manager dashboard

2. Manager goes to "External Sharing" page
   → Selects pack type (bank/investor/auditor/partner)
   → Loads data from latest KPIs
   → Customizes what to share

3. Manager publishes snapshot
   → POST /api/external/publish
   → Creates ExternalSnapshot with isCurrent: true
   → Previous snapshot for same pack marked isCurrent: false

4. External user sees new snapshot
   → GET /api/external/snapshot
   → Reads latest ExternalSnapshot for their pack type
```

### Workflow 3: External User Views Data

```
1. External user logs in
   → POST /api/auth/user-login
   → Token includes: externalType="bank", companyId, roles=["external"]

2. External dashboard loads
   → GET /api/external/pack
   → Backend returns pack config based on externalType from token
   → Frontend shows/hides sections based on pack flags

3. External user views snapshot
   → GET /api/external/snapshot
   → Backend queries ExternalSnapshot where:
     - companyId matches token
     - packType matches externalType from token
     - isCurrent: true
   → Returns published data only

4. External user views reports
   → GET /api/external/reports
   → Only if pack.flags.allowExport === true
   → Returns reports from ExternalSnapshot
```

### Workflow 4: Role-Based Dashboard Routing

```
1. User logs in
   → POST /api/auth/user-login
   → Response includes: { roles: ["accountant"], ... }

2. Frontend determines dashboard
   → login.html checks roles array
   → Priority: admin > manager > accountant > financial_analyst > external
   → Redirects to appropriate dashboard

3. Dashboard loads
   → Dashboard calls requireAuth()
   → Validates token, extracts user info
   → Loads data based on role
```

---

## 📊 Data Relationships

```
Company (1) ──→ (N) User
  │
  ├─→ (N) Transaction
  │     └─→ (N) TransactionLine
  │
  ├─→ (N) KpiSnapshot (published by Accountant)
  │
  ├─→ (N) ExternalSnapshot (published by Manager)
  │     └─→ packType: bank | investor | auditor | partner
  │
  ├─→ (N) Recommendation
  │     └─→ type: internal | external
  │
  └─→ (N) NewsItem
```

---

## 🎯 Key Concepts

### Multi-Tenancy
- Every data record is scoped to a `companyId`
- Users belong to one company
- API endpoints enforce company scope via `requireCompanyScope`

### Pack System (External Portal)
- **Pack** = Permission template defining what external user can see
- Pack type determined by `User.externalType` (bank/investor/auditor/other)
- Pack config defines:
  - `allowedPages`: Which pages are visible
  - `flags`: Feature toggles (allowNews, allowExport, allowDocs, etc.)
  - `masking`: Data masking rules (hideVendors, hideCustomers, hidePayroll)

### KPI Publishing
- Accountant calculates KPIs from transactions
- Accountant publishes snapshot → `KpiSnapshot` with `is_current: true`
- Manager reads latest snapshot → `GET /api/kpis/latest`
- Only one current snapshot per company at a time

### External Snapshot Publishing
- Manager publishes external snapshot → `ExternalSnapshot`
- One current snapshot per company per pack type
- External users read only from `ExternalSnapshot`, never raw data

---

## 🚀 Getting Started

### For Developers

1. **Backend Setup**:
   ```bash
   cd backend
   npm install
   # Set up .env with MONGO_URI, JWT_SECRET, etc.
   npm start
   ```

2. **Frontend Setup**:
   - Open HTML files in browser or use local server
   - API base URL configured in `js/api.js`

3. **Database**:
   - MongoDB connection via `MONGO_URI` in `.env`
   - Models auto-create collections on first use

### For Users

1. **Register Company**: `register.html`
2. **Login**: `login.html` → Redirects to role-appropriate dashboard
3. **Accountant**: Enter transactions → Publish KPIs
4. **Manager**: Review KPIs → Publish external snapshots
5. **External**: View published snapshots (read-only)

---

## 📝 Notes

- **External Portal is READ-ONLY**: External users never see raw internal data
- **Pack Type Security**: Pack comes from JWT token, never user input
- **Company Isolation**: All data queries are company-scoped
- **KPI Publishing**: Only Accountant can publish KPIs
- **External Publishing**: Only Manager/Admin can publish external snapshots
- **Access Expiry**: External users have `accessExpiry` date checked on every request

---

**Last Updated**: January 2026
**Version**: 2.1
