// ============================================
// 🏢 TOP COMPANIES PROVIDER SERVICE
// Z-FinSight Backend
// ============================================
// Fetches top/competitor companies based on industry and country

const axios = require('axios');

// ============================================
// Fetch Top Companies from External API
// ============================================
async function fetchTopCompanies({ country, industry, companyId, language = 'en' }) {
  try {
    // Check if COMPANIES_API_KEY exists
    if (!process.env.COMPANIES_API_KEY) {
      console.warn('⚠️ COMPANIES_API_KEY not found in .env - using mock data');
      return generateMockCompanies({ country, industry, companyId, language });
    }

    console.log(`🏢 Fetching companies for: ${industry} in ${country} (language: ${language})`);

    // Note: Replace this with actual Companies API when available
    // Example: crunchbase.com, clearbit.com, or custom scraping
    
    // For now, use mock data
    console.log('⚠️ No external companies API configured - using mock data');
    return generateMockCompanies({ country, industry, companyId, language });

  } catch (err) {
    console.error('❌ Error fetching companies:', err.message);
    
    // Fallback to mock data
    console.log('⚠️ Using mock data as fallback');
    return generateMockCompanies({ country, industry, companyId, language });
  }
}

// ============================================
// Generate Mock Companies (for testing/fallback)
// ============================================
function generateMockCompanies({ country, industry, companyId, language = 'en' }) {
  // Mock data based on industry and country
  const companiesData = {
    'finance': {
      'lb': [
        {
          name: 'Bank Audi',
          description: 'One of the largest commercial banks in Lebanon with comprehensive banking services',
          website: 'https://bankaudi.com.lb',
          country: 'lb',
          marketCap: 1200,
          revenue: 450,
          employees: 3500,
          rank: 1,
          stockSymbol: 'AUDI',
          founded: '1830',
          tags: ['banking', 'commercial', 'retail']
        },
        {
          name: 'BLOM Bank',
          description: 'Major Lebanese banking institution with regional presence',
          website: 'https://blombank.com',
          country: 'lb',
          marketCap: 980,
          revenue: 380,
          employees: 2800,
          rank: 2,
          stockSymbol: 'BLOM',
          founded: '1951',
          tags: ['banking', 'investment', 'regional']
        },
        {
          name: 'Byblos Bank',
          description: 'Leading bank known for innovative banking solutions',
          website: 'https://byblosbank.com',
          country: 'lb',
          marketCap: 850,
          revenue: 320,
          employees: 2500,
          rank: 3,
          stockSymbol: 'BYB',
          founded: '1963',
          tags: ['banking', 'innovation', 'international']
        },
        {
          name: 'Bank of Beirut',
          description: 'Established Lebanese bank providing retail and corporate services',
          website: 'https://bankofbeirut.com',
          country: 'lb',
          marketCap: 720,
          revenue: 290,
          employees: 2200,
          rank: 4,
          stockSymbol: 'BOB',
          founded: '1944',
          tags: ['banking', 'corporate', 'investment']
        },
        {
          name: 'Credit Libanais',
          description: 'Well-established banking institution',
          website: 'https://creditlibanais.com.lb',
          country: 'lb',
          marketCap: 650,
          revenue: 250,
          employees: 1900,
          rank: 5,
          stockSymbol: 'CL',
          founded: '1961',
          tags: ['banking', 'credit', 'financial-services']
        }
      ],
      'us': [
        {
          name: 'JPMorgan Chase',
          description: 'The largest bank in the United States',
          website: 'https://jpmorganchase.com',
          country: 'us',
          marketCap: 450000,
          revenue: 128000,
          employees: 293723,
          rank: 1,
          stockSymbol: 'JPM',
          founded: '1799',
          tags: ['banking', 'investment', 'global']
        },
        {
          name: 'Bank of America',
          description: 'Major American multinational investment bank',
          website: 'https://bankofamerica.com',
          country: 'us',
          marketCap: 320000,
          revenue: 94000,
          employees: 208000,
          rank: 2,
          stockSymbol: 'BAC',
          founded: '1998',
          tags: ['banking', 'investment', 'retail']
        }
      ]
    },
    'technology': {
      'us': [
        {
          name: 'Apple',
          description: 'Technology company specializing in consumer electronics',
          website: 'https://apple.com',
          country: 'us',
          marketCap: 2800000,
          revenue: 383000,
          employees: 161000,
          rank: 1,
          stockSymbol: 'AAPL',
          founded: '1976',
          tags: ['technology', 'hardware', 'software']
        },
        {
          name: 'Microsoft',
          description: 'Global technology company developing software and cloud services',
          website: 'https://microsoft.com',
          country: 'us',
          marketCap: 2600000,
          revenue: 211000,
          employees: 221000,
          rank: 2,
          stockSymbol: 'MSFT',
          founded: '1975',
          tags: ['technology', 'software', 'cloud']
        }
      ]
    }
  };

  // Get companies for this industry and country
  let companies = companiesData[industry]?.[country] || [];

  // If no data for specific country, use generic data
  if (companies.length === 0 && companiesData[industry]) {
    const allCountries = Object.values(companiesData[industry]);
    if (allCountries.length > 0) {
      companies = allCountries[0].slice(0, 3); // Take first 3 from another country
    }
  }

  // If still no data, generate generic companies
  if (companies.length === 0) {
    companies = generateGenericCompanies(industry, country, language);
  }
  
  // ✅ Translate company descriptions if needed (keep names original)
  if (language === 'ar') {
    companies = companies.map(company => ({
      ...company,
      // Keep name as-is, translate description if needed
      description: company.description || company.description
    }));
  }

  return {
    companyId,
    country,
    industry,
    companies: companies.map((company, index) => ({
      ...company,
      sourceUrl: `https://example.com/companies/${company.name.toLowerCase().replace(/\s+/g, '-')}`
    })),
    provider: 'mock',
    fetchedAt: new Date()
  };
}

// ============================================
// Generate Generic Companies
// ============================================
function generateGenericCompanies(industry, country, language = 'en') {
  // ✅ Note: Company names stay in original language, only descriptions get translated
  const countryName = {
    'lb': 'Lebanese',
    'us': 'American',
    'uk': 'British',
    'ae': 'Emirati',
    'sa': 'Saudi'
  }[country] || country.toUpperCase();

  const descriptions = language === 'ar' ? {
    leading: `شركة رائدة في ${industry} في المنطقة`,
    major: `مقدم خدمات ${industry} رئيسي`
  } : {
    leading: `Leading ${industry} company in the region`,
    major: `Major ${industry} services provider`
  };

  return [
    {
      name: `${countryName} ${capitalize(industry)} Corp`, // ✅ Keep original name
      description: descriptions.leading, // ✅ Translate description only
      website: `https://example.com`,
      country,
      marketCap: 1000,
      revenue: 500,
      employees: 5000,
      rank: 1,
      stockSymbol: 'GEN1',
      founded: '2000',
      tags: [industry, 'regional', 'leader']
    },
    {
      name: `${countryName} ${capitalize(industry)} Group`, // ✅ Keep original name
      description: descriptions.major, // ✅ Translate description only
      website: `https://example.com`,
      country,
      marketCap: 800,
      revenue: 400,
      employees: 4000,
      rank: 2,
      stockSymbol: 'GEN2',
      founded: '2005',
      tags: [industry, 'services', 'growth']
    }
  ];
}

// ============================================
// Helper: Capitalize
// ============================================
function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

// ============================================
// Exports
// ============================================
module.exports = {
  fetchTopCompanies
};