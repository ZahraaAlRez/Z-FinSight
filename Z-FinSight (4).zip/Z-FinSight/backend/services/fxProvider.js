// ============================================
// 💱 FX RATES PROVIDER SERVICE
// Z-FinSight Backend
// ============================================
// Fetches exchange rates from external API

const axios = require('axios');

// ============================================
// Fetch FX Rates from External API
// ============================================
async function fetchFxRates({ currencies, companyId }) {
  try {
    // Check if EXCHANGE_API_KEY exists
    if (!process.env.EXCHANGE_API_KEY) {
      console.warn('⚠️ EXCHANGE_API_KEY not found in .env - using mock data');
      return generateMockFxRates({ currencies, companyId });
    }

    console.log(`💱 Fetching rates for currencies: ${currencies.join(', ')}`);

    // Get previous snapshot for change calculation
    const FxRateSnapshot = require('../models/FxRateSnapshot');
    const previousSnapshot = await FxRateSnapshot.findOne({ companyId })
      .sort({ fetchedAt: -1 });

    const rates = [];

    // Fetch rates for each currency pair
    for (let i = 0; i < currencies.length; i++) {
      for (let j = 0; j < currencies.length; j++) {
        if (i !== j) {
          const base = currencies[i];
          const target = currencies[j];

          try {
            // Call Exchange Rate API
            const response = await axios.get(
              `https://api.exchangerate-api.com/v4/latest/${base}`
            );

            const rate = response.data.rates[target];

            if (rate) {
              // Calculate change from previous snapshot
              let change = 0;
              let changePercent = 0;

              if (previousSnapshot) {
                const prevRate = previousSnapshot.rates.find(
                  r => r.base === base && r.target === target
                );
                if (prevRate) {
                  change = rate - prevRate.rate;
                  changePercent = ((change / prevRate.rate) * 100).toFixed(2);
                }
              }

              rates.push({
                base,
                target,
                rate: parseFloat(rate.toFixed(2)),
                change: parseFloat(change.toFixed(2)),
                changePercent: parseFloat(changePercent),
                updatedAt: new Date()
              });
            }
          } catch (err) {
            console.error(`❌ Error fetching ${base}/${target}:`, err.message);
          }
        }
      }
    }

    return {
      companyId,
      rates,
      provider: 'exchangerate-api.com',
      fetchedAt: new Date()
    };

  } catch (err) {
    console.error('❌ Error fetching FX rates:', err.message);
    
    // Fallback to mock data
    console.log('⚠️ Using mock data as fallback');
    return generateMockFxRates({ currencies, companyId });
  }
}

// ============================================
// Generate Mock FX Rates (for testing/fallback)
// ============================================
function generateMockFxRates({ currencies, companyId }) {
  // Common exchange rates (mock data)
  const mockRates = {
    'USD': { 'LBP': 89500, 'EUR': 0.92, 'GBP': 0.79, 'AED': 3.67 },
    'EUR': { 'LBP': 95000, 'USD': 1.09, 'GBP': 0.86, 'AED': 4.00 },
    'LBP': { 'USD': 0.000011, 'EUR': 0.000010, 'GBP': 0.000009, 'AED': 0.000041 },
    'GBP': { 'USD': 1.27, 'EUR': 1.16, 'LBP': 113000, 'AED': 4.66 },
    'AED': { 'USD': 0.27, 'EUR': 0.25, 'LBP': 24390, 'GBP': 0.21 }
  };

  const rates = [];

  for (let i = 0; i < currencies.length; i++) {
    for (let j = 0; j < currencies.length; j++) {
      if (i !== j) {
        const base = currencies[i];
        const target = currencies[j];

        const rate = mockRates[base]?.[target] || 1;
        
        // Random change for mock data
        const randomChange = (Math.random() - 0.5) * 1000;
        const changePercent = ((randomChange / rate) * 100).toFixed(2);

        rates.push({
          base,
          target,
          rate: parseFloat(rate.toFixed(2)),
          change: parseFloat(randomChange.toFixed(2)),
          changePercent: parseFloat(changePercent),
          updatedAt: new Date()
        });
      }
    }
  }

  return {
    companyId,
    rates,
    provider: 'mock',
    fetchedAt: new Date()
  };
}

// ============================================
// Exports
// ============================================
module.exports = {
  fetchFxRates
};