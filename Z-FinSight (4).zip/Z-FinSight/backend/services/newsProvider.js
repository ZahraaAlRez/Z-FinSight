// ============================================
// 📰 NEWS PROVIDER SERVICE
// Z-FinSight Backend
// ============================================
// Fetches news from external News API based on company profile

const axios = require('axios');

// ============================================
// Fetch News from External API
// ============================================
async function fetchNews({ country, industry, companyId, language = 'en' }) {
  try {
    // Check if NEWS_API_KEY exists
    if (!process.env.NEWS_API_KEY) {
      console.warn('⚠️ NEWS_API_KEY not found in .env - using mock data');
      return generateMockNews({ country, industry, companyId, language });
    }

    // Build search query based on country and industry
    const query = buildSearchQuery(country, industry);
    
    console.log(`🔍 Searching news for: ${query} (language: ${language})`);

    // ✅ Map language to NewsAPI supported codes (ar, en)
    const newsApiLang = language === 'ar' ? 'ar' : 'en';

    // Call News API
    const response = await axios.get('https://newsapi.org/v2/everything', {
      params: {
        q: query,
        language: newsApiLang,
        sortBy: 'publishedAt',
        pageSize: 20,
        apiKey: process.env.NEWS_API_KEY
      }
    });

    // Transform API response to our schema
    const articles = response.data.articles || [];
    
    return articles.map(article => ({
      companyId,
      title: article.title,
      summary: article.description || '',
      url: article.url,
      source: article.source?.name || 'Unknown',
      country,
      industry,
      sentiment: 'neutral', // Default - will be analyzed by AI later
      tags: extractTags(article.title + ' ' + article.description),
      publishedAt: new Date(article.publishedAt),
      fetchedAt: new Date(),
      provider: 'newsapi.org'
    }));

  } catch (err) {
    console.error('❌ Error fetching news:', err.message);
    
    // Fallback to mock data if API fails
    console.log('⚠️ Using mock data as fallback');
    return generateMockNews({ country, industry, companyId, language });
  }
}

// ============================================
// Build Search Query
// ============================================
function buildSearchQuery(country, industry) {
  const countryNames = {
    'lb': 'Lebanon',
    'us': 'United States',
    'uk': 'United Kingdom',
    'ae': 'UAE',
    'sa': 'Saudi Arabia',
    // Add more countries as needed
  };

  const industryTerms = {
    'finance': 'finance OR banking OR financial',
    'technology': 'technology OR tech OR software',
    'healthcare': 'healthcare OR medical OR health',
    'retail': 'retail OR commerce OR shopping',
    'manufacturing': 'manufacturing OR industrial OR production',
    // Add more industries as needed
  };

  const countryName = countryNames[country] || country;
  const industryTerm = industryTerms[industry] || industry;

  return `${countryName} AND (${industryTerm})`;
}

// ============================================
// Extract Tags from Text
// ============================================
function extractTags(text) {
  if (!text) return [];
  
  const keywords = [
    'economy', 'banking', 'finance', 'investment', 'market',
    'technology', 'digital', 'innovation', 'growth', 'policy',
    'regulation', 'crisis', 'recovery', 'trade', 'currency'
  ];

  const lowerText = text.toLowerCase();
  return keywords.filter(keyword => lowerText.includes(keyword));
}

// ============================================
// Generate Mock News (for testing/fallback)
// ============================================
function generateMockNews({ country, industry, companyId, language = 'en' }) {
  const countryName = {
    'lb': language === 'ar' ? 'لبنان' : 'Lebanon',
    'us': language === 'ar' ? 'الولايات المتحدة' : 'United States',
    'uk': language === 'ar' ? 'المملكة المتحدة' : 'United Kingdom'
  }[country] || country;

  const industryName = language === 'ar' ? industry : industry;
  
  // ✅ Arabic translations
  const mockArticles = language === 'ar' ? [
    {
      title: `قطاع ${industryName} في ${countryName} يُظهر مرونة في مواجهة التحديات`,
      summary: `يُبلغ خبراء الصناعة عن اتجاهات إيجابية في قطاع ${industryName} رغم التحديات الاقتصادية العالمية.`,
      source: 'أخبار تجريبية',
      sentiment: 'positive'
    },
    {
      title: `أنظمة جديدة تؤثر على شركات ${industryName} في ${countryName}`,
      summary: `تعلن الحكومة عن سياسات جديدة تؤثر على شركات ${industryName} في جميع أنحاء البلاد.`,
      source: 'أخبار تجريبية',
      sentiment: 'neutral'
    },
    {
      title: `سوق ${industryName} في ${countryName} يشهد تحولاً رقمياً`,
      summary: `تتبنى الشركات في قطاع ${industryName} تقنيات رقمية بشكل متزايد.`,
      source: 'أخبار تجريبية',
      sentiment: 'positive'
    }
  ] : [
    {
      title: `${countryName} ${industry} sector shows resilience amid challenges`,
      summary: `Industry experts report positive trends in the ${industry} sector despite global economic headwinds.`,
      source: 'Mock News',
      sentiment: 'positive'
    },
    {
      title: `New regulations impact ${industry} companies in ${countryName}`,
      summary: `Government announces new policies affecting ${industry} businesses across the country.`,
      source: 'Mock News',
      sentiment: 'neutral'
    },
    {
      title: `${countryName} ${industry} market sees digital transformation`,
      summary: `Companies in the ${industry} sector are increasingly adopting digital technologies.`,
      source: 'Mock News',
      sentiment: 'positive'
    }
  ];

  return mockArticles.map((article, index) => ({
    companyId,
    title: article.title,
    summary: article.summary,
    url: `https://example.com/news/${companyId}-${Date.now()}-${index}`,
    source: article.source,
    country,
    industry,
    sentiment: article.sentiment,
    tags: extractTags(article.title + ' ' + article.summary),
    publishedAt: new Date(Date.now() - index * 3600000), // Stagger times
    fetchedAt: new Date(),
    provider: 'mock'
  }));
}

// ============================================
// Exports
// ============================================
module.exports = {
  fetchNews
};