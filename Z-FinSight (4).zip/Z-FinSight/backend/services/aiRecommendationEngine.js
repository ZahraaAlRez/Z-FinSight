const axios = require('axios');
const Recommendation = require('../models/Recommendation');

class AIRecommendationEngine {
  constructor() {
    this.apiKey = process.env.CLAUDE_API_KEY;
    this.apiUrl = 'https://api.anthropic.com/v1/messages';
    this.model = 'claude-sonnet-4-20250514';
  }

  // 🤖 Core AI Analysis Function
  async callClaudeAPI(prompt, systemPrompt = '') {
    try {
      const response = await axios.post(
        this.apiUrl,
        {
          model: this.model,
          max_tokens: 2000,
          temperature: 0.7,
          system: systemPrompt || 'You are an expert business analyst and strategic advisor.',
          messages: [
            {
              role: 'user',
              content: prompt
            }
          ]
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': this.apiKey,
            'anthropic-version': '2023-06-01'
          }
        }
      );

      const content = response.data.content[0].text;
      
      // Try to parse JSON if present
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      
      return { rawContent: content };
    } catch (error) {
      console.error('❌ Claude API Error:', error.response?.data || error.message);
      throw error;
    }
  }

  // 📰 Analyze News and Generate Recommendations
  async analyzeNews(news, company, language = 'en') {
    console.log(`🤖 Analyzing news for ${company.companyName || company.name} (language: ${language})...`);
    
    const langInstruction = language === 'ar' 
      ? '**IMPORTANT: Generate ALL output in Arabic (العربية). All text, titles, insights, recommendations, opportunities, and risks must be in Arabic.**'
      : '**IMPORTANT: Generate ALL output in English.**';
    
    const prompt = `
Analyze this news article for business recommendations:

${langInstruction}

**Company Context:**
- Name: ${company.companyName || company.name}
- Industry: ${company.industry}
- Country: ${company.country}
- Description: ${company.companyEmail || 'N/A'}

**News Article:**
- Title: ${news.title}
- Summary: ${news.summary || ''}
- Country: ${news.country || ''}
- Category: ${news.category || news.industry || ''}
- Published: ${news.publishedDate || news.publishedAt || 'N/A'}

**Task:**
Analyze how this news affects the company and provide actionable recommendations.

**Response Format (JSON only):**
{
  "impact": "High|Medium|Low",
  "category": "Market Opportunity|Risk Mitigation|Competitive Strategy|Financial Planning|Operational Efficiency|Strategic Investment|Crisis Management|Growth Strategy|Cost Optimization|Customer Retention",
  "priority": "Critical|High|Medium|Low",
  "title": "${language === 'ar' ? 'عنوان موجز ومؤثر' : 'Brief impactful title'}",
  "insight": "${language === 'ar' ? 'تحليل الموقف في 2-3 جملة' : '2-3 sentence analysis of the situation'}",
  "opportunities": ["${language === 'ar' ? 'فرصة 1' : 'opportunity 1'}", "${language === 'ar' ? 'فرصة 2' : 'opportunity 2'}"],
  "risks": ["${language === 'ar' ? 'خطر 1' : 'risk 1'}", "${language === 'ar' ? 'خطر 2' : 'risk 2'}"],
  "recommendations": [
    "${language === 'ar' ? 'توصية عملية ومحددة 1' : 'Specific actionable recommendation 1'}",
    "${language === 'ar' ? 'توصية عملية ومحددة 2' : 'Specific actionable recommendation 2'}",
    "${language === 'ar' ? 'توصية عملية ومحددة 3' : 'Specific actionable recommendation 3'}"
  ],
  "confidence": 85,
  "reasoning": "${language === 'ar' ? 'شرح موجز للتحليل' : 'Brief explanation of the analysis'}"
}

**Important Guidelines:**
1. Be specific and actionable
2. Focus on what the company can do NOW
3. Consider their industry and market position
4. Prioritize based on urgency and impact
5. Include both opportunities and risks
6. Keep recommendations practical and measurable
7. ${language === 'ar' ? 'USE ARABIC FOR ALL OUTPUT TEXT' : 'USE ENGLISH FOR ALL OUTPUT TEXT'}
`;

    try {
      // ✅ Check if API key exists, if not use mock recommendations
      if (!this.apiKey) {
        console.warn('⚠️ CLAUDE_API_KEY not found - using mock recommendation');
        return this.generateMockRecommendation(news, company, language);
      }

      const systemPrompt = language === 'ar' 
        ? 'أنت محلل أعمال استراتيجي خبير. قم بتحليل الأخبار والبيانات المالية وتقديم توصيات عملية باللغة العربية.'
        : 'You are an expert business analyst and strategic advisor.';

      const analysis = await this.callClaudeAPI(prompt, systemPrompt);
      
      // Create recommendation in database
      const recommendation = new Recommendation({
        companyId: company.companyId,
        sourceType: 'news',
        sourceId: news._id || news.id,
        sourceTitle: news.title,
        category: analysis.category,
        priority: analysis.priority,
        impact: analysis.impact,
        title: analysis.title,
        insight: analysis.insight,
        opportunities: analysis.opportunities || [],
        risks: analysis.risks || [],
        recommendations: analysis.recommendations || [],
        aiAnalysis: {
          confidence: analysis.confidence || 0,
          reasoning: analysis.reasoning || '',
          language: language // ✅ Store language used
        },
        status: 'new'
      });

      await recommendation.save();
      console.log(`✅ Recommendation created for ${company.companyName || company.name}`);
      
      return recommendation;
    } catch (error) {
      console.error(`❌ Error analyzing news for ${company.companyName || company.name}:`, error.message);
      // ✅ Fallback to mock recommendation if AI fails
      return this.generateMockRecommendation(news, company, language);
    }
  }

  // 🏢 Analyze Competitor Moves
  async analyzeCompetitor(competitor, company, language = 'en') {
    console.log(`🤖 Analyzing competitor data for ${company.companyName || company.name}...`);
    
    const langInstruction = language === 'ar' 
      ? '**IMPORTANT: Generate ALL output in Arabic (العربية). All text, titles, insights, recommendations, opportunities, and risks must be in Arabic.**'
      : '**IMPORTANT: Generate ALL output in English.**';
    
    const prompt = `
Analyze this competitor information and provide strategic recommendations:

${langInstruction}

**Your Company:**
- Name: ${company.companyName || company.name}
- Industry: ${company.industry}
- Country: ${company.country}

**Competitor:**
- Name: ${competitor.name}
- Industry: ${competitor.industry || 'N/A'}
- Country: ${competitor.country || 'N/A'}
- Revenue: ${competitor.revenue ? competitor.revenue.toLocaleString() : 'N/A'}
- Net Margin: ${competitor.netMargin ? (competitor.netMargin * 100).toFixed(2) + '%' : 'N/A'}

**Task:**
Analyze competitive threats and opportunities. What should the company do?

**Response Format (JSON only):**
{
  "impact": "High|Medium|Low",
  "category": "Competitive Strategy|Market Opportunity|Strategic Investment",
  "priority": "High|Medium|Low",
  "title": "${language === 'ar' ? 'رؤية استراتيجية موجزة' : 'Brief strategic insight'}",
  "insight": "${language === 'ar' ? 'تحليل المشهد التنافسي' : 'Analysis of competitive landscape'}",
  "opportunities": ["${language === 'ar' ? 'فرصة للاستغلال' : 'opportunity to exploit'}"],
  "risks": ["${language === 'ar' ? 'تهديدات تنافسية' : 'competitive threats'}"],
  "recommendations": [
    "${language === 'ar' ? 'إجراء استراتيجي 1' : 'Strategic action 1'}",
    "${language === 'ar' ? 'إجراء استراتيجي 2' : 'Strategic action 2'}",
    "${language === 'ar' ? 'إجراء استراتيجي 3' : 'Strategic action 3'}"
  ],
  "confidence": 80,
  "reasoning": "${language === 'ar' ? 'لماذا هذه التوصيات مهمة' : 'Why these recommendations matter'}"
}

**Important Guidelines:**
1. Be specific and actionable
2. Focus on competitive positioning
3. Consider market dynamics
4. Prioritize based on urgency and impact
5. ${language === 'ar' ? 'USE ARABIC FOR ALL OUTPUT TEXT' : 'USE ENGLISH FOR ALL OUTPUT TEXT'}
`;

    try {
      // ✅ Check if API key exists, if not use mock recommendations
      if (!this.apiKey) {
        console.warn('⚠️ CLAUDE_API_KEY not found - using mock competitor recommendation');
        return this.generateMockCompetitorRecommendation(competitor, company, language);
      }

      const systemPrompt = language === 'ar' 
        ? 'أنت محلل استراتيجي خبير. قم بتحليل المنافسين وتقديم توصيات استراتيجية باللغة العربية.'
        : 'You are an expert strategic analyst. Analyze competitors and provide strategic recommendations.';

      const analysis = await this.callClaudeAPI(prompt, systemPrompt);
      
      const recommendation = new Recommendation({
        companyId: company.companyId,
        sourceType: 'competitor',
        sourceTitle: `Competitor Analysis: ${competitor.name}`,
        category: analysis.category || 'Competitive Strategy',
        priority: analysis.priority || 'Medium',
        impact: analysis.impact || 'Medium',
        title: analysis.title,
        insight: analysis.insight,
        opportunities: analysis.opportunities || [],
        risks: analysis.risks || [],
        recommendations: analysis.recommendations || [],
        aiAnalysis: {
          confidence: analysis.confidence || 0,
          reasoning: analysis.reasoning || '',
          language: language
        },
        status: 'new',
        type: 'external' // Mark as external recommendation
      });

      await recommendation.save();
      console.log(`✅ Competitor recommendation created for ${company.companyName || company.name}`);
      
      return recommendation;
    } catch (error) {
      console.error(`❌ Error analyzing competitor:`, error.message);
      // ✅ Fallback to mock recommendation if AI fails
      return this.generateMockCompetitorRecommendation(competitor, company, language);
    }
  }

  // 🎭 Generate Mock Competitor Recommendation (fallback)
  async generateMockCompetitorRecommendation(competitor, company, language = 'en') {
    const title = language === 'ar' 
      ? `تحليل المنافس: ${competitor.name}`
      : `Competitor Analysis: ${competitor.name}`;
    
    const insight = language === 'ar'
      ? `منافس نشط في نفس الصناعة. مراقبة استراتيجياتهم يمكن أن تكشف فرص تحسين.`
      : `Active competitor in the same industry. Monitoring their strategies can reveal improvement opportunities.`;
    
    const recommendations = language === 'ar'
      ? ['مراقبة استراتيجيات التسعير', 'تحليل عروض المنتجات', 'تقييم الأداء التنافسي']
      : ['Monitor pricing strategies', 'Analyze product offerings', 'Assess competitive performance'];
    
    const opportunities = language === 'ar'
      ? ['تحسين الميزة التنافسية', 'تحديد فجوات السوق']
      : ['Improve competitive advantage', 'Identify market gaps'];
    
    const risks = language === 'ar'
      ? ['فقدان حصة السوق', 'ضغط تنافسي متزايد']
      : ['Losing market share', 'Increased competitive pressure'];

    const recommendation = new Recommendation({
      companyId: company.companyId,
      sourceType: 'competitor',
      sourceTitle: `Competitor Analysis: ${competitor.name}`,
      category: 'Competitive Strategy',
      priority: 'Medium',
      impact: 'Medium',
      title: title,
      insight: insight,
      opportunities: opportunities,
      risks: risks,
      recommendations: recommendations,
      aiAnalysis: {
        confidence: 70,
        reasoning: language === 'ar' ? 'توصية مبنية على بيانات المنافس' : 'Recommendation based on competitor data',
        language: language
      },
      status: 'new',
      type: 'external'
    });

    await recommendation.save();
    console.log(`✅ Mock competitor recommendation created for ${company.companyName || company.name}`);
    return recommendation;
  }

  // 💱 Analyze FX Rate Changes
  async analyzeFXImpact(fxData, company) {
    console.log(`🤖 Analyzing FX impact for ${company.name}...`);
    
    const prompt = `
Analyze currency exchange rate changes and their business impact:

**Company:**
- Name: ${company.name}
- Industry: ${company.industry}
- Country: ${company.country}

**FX Data:**
- Base Currency: ${fxData.baseCurrency}
- Target Currency: ${fxData.targetCurrency}
- Current Rate: ${fxData.rate}
- Change: ${fxData.change}%

**Task:**
Analyze how FX movements affect this company's operations, costs, and revenue.

**Response Format (JSON only):**
{
  "impact": "High|Medium|Low",
  "category": "Financial Planning|Risk Mitigation|Cost Optimization",
  "priority": "Critical|High|Medium|Low",
  "title": "FX impact summary",
  "insight": "How currency changes affect the business",
  "opportunities": ["ways to benefit from FX movements"],
  "risks": ["FX exposure risks"],
  "recommendations": [
    "Hedging strategy",
    "Pricing adjustment",
    "Cash flow management"
  ],
  "confidence": 75,
  "reasoning": "Financial analysis reasoning"
}
`;

    try {
      const analysis = await this.callClaudeAPI(prompt);
      
      const recommendation = new Recommendation({
        companyId: company.companyId,
        sourceType: 'fx',
        sourceId: fxData._id,
        sourceTitle: `FX Analysis: ${fxData.baseCurrency}/${fxData.targetCurrency}`,
        category: analysis.category,
        priority: analysis.priority,
        impact: analysis.impact,
        title: analysis.title,
        insight: analysis.insight,
        opportunities: analysis.opportunities || [],
        risks: analysis.risks || [],
        recommendations: analysis.recommendations || [],
        aiAnalysis: {
          confidence: analysis.confidence || 0,
          reasoning: analysis.reasoning || ''
        },
        status: 'new'
      });

      await recommendation.save();
      console.log(`✅ FX recommendation created for ${company.name}`);
      
      return recommendation;
    } catch (error) {
      console.error(`❌ Error analyzing FX:`, error.message);
      return null;
    }
  }

  // 🔄 Batch Process Multiple News Items
  async batchAnalyzeNews(newsArray, company, language = 'en') {
    console.log(`📰 Batch analyzing ${newsArray.length} news items for ${company.companyName || company.name} (language: ${language})...`);
    
    const results = [];
    
    for (const news of newsArray) {
      try {
        const recommendation = await this.analyzeNews(news, company, language);
        if (recommendation) {
          results.push(recommendation);
        }
        
        // Avoid rate limiting - wait 1 second between requests
        await new Promise(resolve => setTimeout(resolve, 1000));
      } catch (error) {
        console.error(`❌ Failed to analyze news ${news._id}:`, error.message);
      }
    }
    
    console.log(`✅ Batch analysis complete: ${results.length}/${newsArray.length} successful`);
    return results;
  }

  // 🎭 Generate Mock Recommendation (fallback when AI key missing)
  async generateMockRecommendation(news, company, language = 'en') {
    const mockData = language === 'ar' ? {
      title: 'فرصة تحليل السوق الحالية',
      insight: 'هذه الأخبار تقدم فرصة للمراجعة الاستراتيجية والنظر في إمكانيات النمو.',
      recommendations: [
        'راجع استراتيجية السوق الحالية',
        'فكر في توسيع نطاق الخدمات',
        'راقب اتجاهات الصناعة'
      ],
      opportunities: ['نمو السوق', 'فرص التوسع'],
      risks: ['منافسة متزايدة', 'تقلبات السوق']
    } : {
      title: 'Market Analysis Opportunity',
      insight: 'This news presents an opportunity to review current strategy and consider growth possibilities.',
      recommendations: [
        'Review current market strategy',
        'Consider expanding service offerings',
        'Monitor industry trends'
      ],
      opportunities: ['Market growth', 'Expansion opportunities'],
      risks: ['Increased competition', 'Market volatility']
    };

    const recommendation = new Recommendation({
      companyId: company.companyId,
      sourceType: 'news',
      sourceId: news._id || news.id,
      sourceTitle: news.title,
      category: 'Market Opportunity',
      priority: 'Medium',
      impact: 'Medium',
      title: mockData.title,
      insight: mockData.insight,
      opportunities: mockData.opportunities,
      risks: mockData.risks,
      recommendations: mockData.recommendations,
      aiAnalysis: {
        confidence: 70,
        reasoning: language === 'ar' ? 'توصية تجريبية' : 'Mock recommendation',
        language: language
      },
      status: 'new'
    });

    await recommendation.save();
    console.log(`✅ Mock recommendation created for ${company.companyName || company.name}`);
    return recommendation;
  }

  // 💰 Analyze Company Financial Data and Generate Internal Recommendations
  async analyzeFinancialData(company, financialData, language = 'en') {
    console.log(`💰 Analyzing financial data for ${company.companyName || company.name} (language: ${language})...`);
    
    const langInstruction = language === 'ar' 
      ? '**IMPORTANT: Generate ALL output in Arabic (العربية). All text, titles, insights, recommendations, opportunities, and risks must be in Arabic.**'
      : '**IMPORTANT: Generate ALL output in English.**';
    
    const prompt = `
Analyze this company's financial data and provide actionable internal recommendations:

${langInstruction}

**Company Context:**
- Name: ${company.companyName || company.name}
- Industry: ${company.industry}
- Country: ${company.country}

**Financial Data:**
- Revenue: ${financialData.revenue || 0}
- COGS: ${financialData.cogs || 0}
- Gross Profit: ${financialData.grossProfit || 0}
- Gross Margin: ${financialData.grossMargin ? (financialData.grossMargin * 100).toFixed(2) + '%' : 'N/A'}
- Operating Expenses: ${financialData.operating_expenses || financialData.opex || 0}
- Operating Profit (EBIT): ${financialData.operating_profit || 0}
- Operating Margin: ${financialData.operating_margin ? (financialData.operating_margin * 100).toFixed(2) + '%' : 'N/A'}
- Interest Expense: ${financialData.interest_expense || 0}
- Profit Before Tax: ${financialData.profit_before_tax || 0}
- Income Tax: ${financialData.income_tax || financialData.taxes || 0}
- Net Profit After Tax: ${financialData.net_profit_after_tax || financialData.afterTaxProfit || 0}
- Net Profit Margin: ${financialData.net_profit_margin || financialData.netMargin ? ((financialData.net_profit_margin || financialData.netMargin) * 100).toFixed(2) + '%' : 'N/A'}
- Tax Burden: ${financialData.taxBurden ? (financialData.taxBurden * 100).toFixed(2) + '%' : 'N/A'}
- Current Assets: ${financialData.current_assets || 0}
- Current Liabilities: ${financialData.current_liabilities || 0}
- Current Ratio: ${financialData.current_ratio || 'N/A'}
- Overdue Invoices: ${financialData.overdueInvoices || 0}
- Bills Due: ${financialData.billsDue || 0}
- Uncategorized Transactions: ${financialData.uncategorizedTransactions || 0}

**Task:**
Analyze the financial health and performance. Identify:
1. Areas of concern (low margins, high expenses, cash flow issues)
2. Opportunities for improvement (cost reduction, efficiency gains)
3. Specific actionable recommendations

**Response Format (JSON only):**
{
  "impact": "High|Medium|Low",
  "category": "Financial Planning|Operational Efficiency|Cost Optimization|Risk Mitigation",
  "priority": "Critical|High|Medium|Low",
  "title": "${language === 'ar' ? 'توصية مالية محددة' : 'Specific financial recommendation'}",
  "insight": "${language === 'ar' ? 'تحليل الوضع المالي في 2-3 جملة' : '2-3 sentence analysis of financial situation'}",
  "opportunities": ["${language === 'ar' ? 'فرصة 1' : 'opportunity 1'}", "${language === 'ar' ? 'فرصة 2' : 'opportunity 2'}"],
  "risks": ["${language === 'ar' ? 'خطر 1' : 'risk 1'}", "${language === 'ar' ? 'خطر 2' : 'risk 2'}"],
  "recommendations": [
    "${language === 'ar' ? 'توصية عملية ومحددة 1' : 'Specific actionable recommendation 1'}",
    "${language === 'ar' ? 'توصية عملية ومحددة 2' : 'Specific actionable recommendation 2'}",
    "${language === 'ar' ? 'توصية عملية ومحددة 3' : 'Specific actionable recommendation 3'}"
  ],
  "confidence": 85,
  "reasoning": "${language === 'ar' ? 'شرح موجز للتحليل المالي' : 'Brief explanation of financial analysis'}"
}

**Important Guidelines:**
1. Be specific and data-driven
2. Focus on actionable improvements
3. Consider industry benchmarks
4. Prioritize based on impact and urgency
5. Include both opportunities and risks
6. Keep recommendations practical and measurable
7. ${language === 'ar' ? 'USE ARABIC FOR ALL OUTPUT TEXT' : 'USE ENGLISH FOR ALL OUTPUT TEXT'}
`;

    try {
      // ✅ Check if API key exists, if not use mock recommendations
      if (!this.apiKey) {
        console.warn('⚠️ CLAUDE_API_KEY not found - using mock financial recommendation');
        return this.generateMockFinancialRecommendation(company, financialData, language);
      }

      const systemPrompt = language === 'ar' 
        ? 'أنت محلل مالي خبير. قم بتحليل البيانات المالية للشركة وتقديم توصيات عملية مبنية على البيانات باللغة العربية.'
        : 'You are an expert financial analyst. Analyze company financial data and provide data-driven actionable recommendations.';

      const analysis = await this.callClaudeAPI(prompt, systemPrompt);
      
      // Create recommendation in database
      const recommendation = new Recommendation({
        companyId: company.companyId,
        sourceType: 'financial',
        sourceTitle: 'Financial Data Analysis',
        category: analysis.category || 'Financial Planning',
        priority: analysis.priority || 'Medium',
        impact: analysis.impact || 'Medium',
        title: analysis.title,
        insight: analysis.insight,
        opportunities: analysis.opportunities || [],
        risks: analysis.risks || [],
        recommendations: analysis.recommendations || [],
        aiAnalysis: {
          confidence: analysis.confidence || 0,
          reasoning: analysis.reasoning || '',
          language: language
        },
        status: 'new',
        type: 'internal' // Mark as internal recommendation
      });

      await recommendation.save();
      console.log(`✅ Financial recommendation created for ${company.companyName || company.name}`);
      
      return recommendation;
    } catch (error) {
      console.error(`❌ Error analyzing financial data for ${company.companyName || company.name}:`, error.message);
      // ✅ Fallback to mock recommendation if AI fails
      return this.generateMockFinancialRecommendation(company, financialData, language);
    }
  }

  // 🎭 Generate Mock Financial Recommendation (fallback)
  async generateMockFinancialRecommendation(company, financialData, language = 'en') {
    const netMargin = financialData.net_profit_margin || financialData.netMargin || 0;
    const currentRatio = financialData.current_ratio;
    const overdueInvoices = financialData.overdueInvoices || 0;
    
    // Generate recommendations based on actual data
    let title, insight, recommendations, opportunities, risks;
    
    if (netMargin < 0.1 && netMargin > 0) {
      // Low profit margin
      title = language === 'ar' ? 'تحسين هامش الربح' : 'Improve Profit Margin';
      insight = language === 'ar' 
        ? `هامش الربح الصافي ${(netMargin * 100).toFixed(1)}% منخفض. هناك فرصة لتحسين الربحية من خلال تقليل التكاليف أو زيادة الأسعار.`
        : `Net profit margin of ${(netMargin * 100).toFixed(1)}% is low. Opportunity to improve profitability through cost reduction or price increases.`;
      recommendations = language === 'ar'
        ? ['مراجعة هيكل التكاليف', 'تحليل استراتيجية التسعير', 'تحسين كفاءة العمليات']
        : ['Review cost structure', 'Analyze pricing strategy', 'Improve operational efficiency'];
    } else if (currentRatio && currentRatio < 1) {
      // Low liquidity
      title = language === 'ar' ? 'تحسين السيولة' : 'Improve Liquidity';
      insight = language === 'ar'
        ? `نسبة السيولة الحالية ${currentRatio.toFixed(2)} أقل من 1، مما يشير إلى مشاكل محتملة في السيولة.`
        : `Current ratio of ${currentRatio.toFixed(2)} is below 1, indicating potential liquidity issues.`;
      recommendations = language === 'ar'
        ? ['تسريع تحصيل الذمم المدينة', 'إدارة أفضل للذمم الدائنة', 'زيادة الاحتياطي النقدي']
        : ['Accelerate receivables collection', 'Better manage payables', 'Increase cash reserves'];
    } else if (overdueInvoices > 0) {
      // Overdue invoices
      title = language === 'ar' ? 'تحصيل الفواتير المتأخرة' : 'Collect Overdue Invoices';
      insight = language === 'ar'
        ? `لديك ${overdueInvoices} فواتير متأخرة. تحصيل هذه الفواتير سيحسن التدفق النقدي.`
        : `You have ${overdueInvoices} overdue invoices. Collecting these will improve cash flow.`;
      recommendations = language === 'ar'
        ? ['إرسال تذكيرات للعملاء', 'تفاوض على خطط الدفع', 'النظر في خصومات الدفع المبكر']
        : ['Send reminders to customers', 'Negotiate payment plans', 'Consider early payment discounts'];
    } else {
      // Generic financial best practice
      title = language === 'ar' ? 'مراجعة الأداء المالي' : 'Review Financial Performance';
      insight = language === 'ar'
        ? 'مراجعة دورية للأداء المالي يمكن أن تكشف فرص التحسين.'
        : 'Regular review of financial performance can reveal improvement opportunities.';
      recommendations = language === 'ar'
        ? ['مراقبة KPIs بانتظام', 'مقارنة الأداء مع معايير الصناعة', 'تحديد أهداف مالية واضحة']
        : ['Monitor KPIs regularly', 'Compare performance to industry benchmarks', 'Set clear financial goals'];
    }

    opportunities = language === 'ar'
      ? ['تحسين الربحية', 'تعزيز التدفق النقدي']
      : ['Improve profitability', 'Enhance cash flow'];
    
    risks = language === 'ar'
      ? ['مشاكل السيولة', 'انخفاض الربحية']
      : ['Liquidity issues', 'Declining profitability'];

    const recommendation = new Recommendation({
      companyId: company.companyId,
      sourceType: 'financial',
      sourceTitle: 'Financial Data Analysis',
      category: 'Financial Planning',
      priority: 'Medium',
      impact: 'Medium',
      title: title,
      insight: insight,
      opportunities: opportunities,
      risks: risks,
      recommendations: recommendations,
      aiAnalysis: {
        confidence: 75,
        reasoning: language === 'ar' ? 'توصية مبنية على البيانات المالية' : 'Recommendation based on financial data',
        language: language
      },
      status: 'new',
      type: 'internal'
    });

    await recommendation.save();
    console.log(`✅ Mock financial recommendation created for ${company.companyName || company.name}`);
    return recommendation;
  }

  // 📊 Get Summary of All Recommendations
  async getSummaryForDashboard(companyId) {
    const recommendations = await Recommendation.find({ 
      companyId, 
      status: { $in: ['new', 'viewed'] } 
    })
      .sort({ priority: 1, createdAt: -1 })
      .limit(20)
      .lean();

    const stats = await Recommendation.getStats(companyId);

    return {
      total: recommendations.length,
      stats,
      topRecommendations: recommendations.slice(0, 5),
      critical: recommendations.filter(r => r.priority === 'Critical').length,
      high: recommendations.filter(r => r.priority === 'High').length
    };
  }
}

module.exports = new AIRecommendationEngine();