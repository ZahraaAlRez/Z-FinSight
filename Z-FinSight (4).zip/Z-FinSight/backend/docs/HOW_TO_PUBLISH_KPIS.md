# How to Publish Real KPIs - Step by Step Guide

## Overview
This guide explains how to publish real financial KPIs from the Accountant Dashboard so they appear in the Admin Dashboard.

## Prerequisites
1. You must be logged in as an **Accountant** user
2. Your company must have sample data (run seed script if needed)
3. Backend server must be running on `http://localhost:4001`

---

## Method 1: Using the Profitability Calculator (Recommended)

### Step 1: Navigate to Accountant Dashboard
1. Log in with your accountant credentials
2. You should land on the **Overview** page

### Step 2: Find the Profitability Calculator
- Scroll down to the **"Profitability Calculator"** section
- It's located on the Overview page, below the Cash & Bank Snapshot

### Step 3: Enter Financial Data
Enter the following values in the calculator inputs:

```
Revenue:              100000
COGS:                 40000
Operating Expenses:   36000
Interest Expense:      2000
Taxes:                5600
```

**Note:** You can use any real numbers from your company's financial data.

### Step 4: Review Calculated Results
The calculator will automatically show:
- **Gross Profit** and **Gross Margin %**
- **Operating Profit (EBIT)** and **Operating Margin %**
- **Profit Before Tax**
- **Net Profit After Tax** and **Net Profit Margin %**
- **Tax Burden %**
- **Current Ratio** (if available from balance sheet data)

### Step 5: Publish KPIs
1. Click the **"Publish KPIs"** button
2. You should see a success message: "✅ KPIs published successfully"
3. The KPIs are now saved and visible to Admin/Manager dashboards

---

## Method 2: Using Calculated KPIs from Transactions

### Step 1: Ensure You Have Transactions
- Make sure you have transactions in the system
- Transactions should be properly categorized
- Use the seed script to add sample data if needed

### Step 2: Navigate to Overview Page
- The system will automatically calculate KPIs from your transactions
- Click **"Refresh from server"** button in the KPI section

### Step 3: Review Calculated KPIs
- The system fetches calculated KPIs from `/api/kpis/calculate`
- This endpoint calculates KPIs from your actual transaction data
- Review the values displayed

### Step 4: Publish KPIs
1. Click **"Publish KPIs"** button
2. The calculated values will be saved as a snapshot
3. Admin/Manager dashboards will now see these values

---

## Method 3: Add Sample Data First (If No Data Exists)

### Step 1: Run the Seed Script
```bash
cd backend
node scripts/seedSampleData.js CMP_001
```

This will create:
- Chart of Accounts (Revenue, COGS, Expenses, Assets, Liabilities, Equity)
- Sample Transactions (Income and Expenses for January 2026)
- Sample Invoices (some overdue)
- Sample Bills (some due soon, some overdue)
- Bank Accounts

### Step 2: Use Method 1 or Method 2 Above
After seeding data, follow either Method 1 or Method 2 to publish KPIs.

---

## What Happens When You Publish?

1. **Backend Processing:**
   - All previous KPIs for your company are marked as `is_current: false`
   - A new KPI snapshot is created with `is_current: true`
   - All calculated values are stored in the database

2. **Data Stored:**
   - Revenue, COGS, Operating Expenses, Interest Expense, Taxes
   - Gross Profit, Operating Profit, Profit Before Tax, Net Profit After Tax
   - All margins (Gross, Operating, Net Profit)
   - Tax Burden %
   - Current Assets, Current Liabilities, Current Ratio

3. **Admin Dashboard:**
   - Automatically loads the latest published KPIs
   - Displays them in the Overview page stat cards
   - Shows when KPIs were last published

---

## Troubleshooting

### Problem: KPIs show as zeros in Admin Dashboard

**Solution:**
1. Make sure you've actually published KPIs (not just calculated them)
2. Check that you entered values in the calculator before publishing
3. Verify the accountant user has the correct `companyId`
4. Check browser console for errors

### Problem: "No published KPIs found"

**Solution:**
1. Go to Accountant Dashboard
2. Enter values in the Profitability Calculator
3. Click "Publish KPIs" button
4. Wait a moment, then refresh Admin Dashboard

### Problem: Calculator shows "—" for all values

**Solution:**
1. Make sure you've entered values in the input fields
2. The calculator calculates automatically as you type
3. If using API calculation, ensure you have transactions in the system

### Problem: Current Ratio shows "—"

**Solution:**
1. Current Ratio requires Balance Sheet data (Current Assets and Current Liabilities)
2. Make sure you have Account records with `account_type = 'asset'` and `account_subtype = 'current'`
3. Make sure you have Account records with `account_type = 'liability'` and `account_subtype = 'current'`
4. Run the seed script to create sample accounts

---

## Example: Publishing KPIs with Real Numbers

### Scenario: Company XYZ - January 2026

**Step 1: Enter Data**
```
Revenue:              100000
COGS:                 40000
Operating Expenses:   30000
Interest Expense:      2000
Taxes:                5600
```

**Step 2: Calculator Shows**
```
Gross Profit:         $60,000 (60% margin)
Operating Profit:     $30,000 (30% margin)
Profit Before Tax:    $28,000
Net Profit After Tax: $22,400 (22.4% margin)
Tax Burden:           20%
```

**Step 3: Click "Publish KPIs"**

**Step 4: Check Admin Dashboard**
- Navigate to Admin Dashboard
- Go to Overview page
- You should see:
  - After-Tax Profit: $22,400
  - Net Profit Margin: 22.4%
  - Tax Burden: 20%
  - Current Ratio: (if available)

---

## API Endpoints Used

- **GET /api/kpis/calculate** - Calculates KPIs from transaction data
- **POST /api/kpis/publish** - Saves KPI snapshot
- **GET /api/kpis/latest** - Retrieves latest published KPIs (used by Admin Dashboard)

---

## Data Flow

```
Accountant Dashboard
    ↓
Enter values in Calculator
    ↓
Click "Publish KPIs"
    ↓
POST /api/kpis/publish
    ↓
Backend saves to KpiSnapshot collection
    ↓
Admin Dashboard loads on page load
    ↓
GET /api/kpis/latest
    ↓
Displays KPIs in stat cards
```

---

## Quick Start Checklist

- [ ] Logged in as Accountant
- [ ] Navigated to Accountant Dashboard Overview page
- [ ] Found Profitability Calculator section
- [ ] Entered financial values (Revenue, COGS, etc.)
- [ ] Reviewed calculated results
- [ ] Clicked "Publish KPIs" button
- [ ] Saw success message
- [ ] Checked Admin Dashboard to verify KPIs are displayed

---

## Need Help?

If KPIs are still not showing:
1. Check browser console for errors
2. Check backend server logs
3. Verify database connection
4. Ensure companyId matches between accountant and admin users
5. Try running the seed script to add sample data
