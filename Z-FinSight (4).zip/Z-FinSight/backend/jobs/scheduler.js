// ============================================
// 🕒 SCHEDULER - Auto Update Data (WITH PATCH 6 SAFETY)
// Z-FinSight Backend
// ============================================

const cron = require("node-cron");

// ✅ FIXED PATHS (because this file is inside /jobs)
const Company = require("../models/Company");
const User = require("../models/User");
const NewsItem = require("../models/NewsItem");
const TopCompaniesSnapshot = require("../models/TopCompaniesSnapshot");
const FxRateSnapshot = require("../models/FxRateSnapshot");

// ✅ Providers
const newsProvider = require("../services/newsProvider");
const fxProvider = require("../services/fxProvider");
const topCompaniesProvider = require("../services/topCompaniesProvider");

// ============================================
// Helper: Get Active Companies Only (PATCH 6)
// ============================================
async function getActiveCompanies() {
  try {
    const companies = await Company.find({ isActive: true });
    console.log(`✅ Found ${companies.length} active companies for scheduler`);
    return companies;
  } catch (err) {
    console.error("❌ Error fetching active companies:", err);
    return [];
  }
}

// ============================================
// Core Execute Functions (can be used by cron + manual trigger)
// ============================================

async function executeNewsUpdate() {
  console.log("\n📄 [SCHEDULER] Starting news update...");

  try {
    // ✅ PATCH 6: Only get active companies
    const companies = await getActiveCompanies();
    
    if (companies.length === 0) {
      console.log("⏭️  No active companies found. Skipping news update.");
      return;
    }

    for (const company of companies) {
      try {
        // ✅ PATCH 6: Double-check company is active
        if (!company.isActive) {
          console.log(`⏭️  Skipping inactive company: ${company.companyId}`);
          continue;
        }

        console.log(`\n📰 Fetching news for ${company.companyName} (${company.companyId})`);

        // ✅ Pass company's language preference
        const language = company.language || 'en';
        const newsData = await newsProvider.fetchNews({
          country: company.country,
          industry: company.industry,
          companyId: company.companyId,
          language: language, // ✅ Pass language to provider
        });

        if (newsData && newsData.length > 0) {
          for (const article of newsData) {
            const exists = await NewsItem.findOne({
              companyId: company.companyId,
              url: article.url,
            });

            if (!exists) {
              await NewsItem.create(article);
              console.log(`  ✔ Added: "${article.title}"`);
            }
          }
          console.log(`✅ News updated for ${company.companyName}`);
        } else {
          console.log(`⚠️ No news found for ${company.companyName}`);
        }
      } catch (err) {
        // ✅ PATCH 6: Don't crash on single company failure
        console.error(`❌ Error fetching news for ${company.companyName}:`, err.message);
        continue; // Move to next company
      }
    }

    console.log("\n✅ [SCHEDULER] News update completed\n");
  } catch (err) {
    console.error("❌ [SCHEDULER] News update error:", err);
    // ✅ PATCH 6: Don't crash the server
  }
}

async function executeFxUpdate() {
  console.log("\n📄 [SCHEDULER] Starting FX rates update...");

  try {
    // ✅ PATCH 6: Only get active companies
    const companies = await getActiveCompanies();
    
    if (companies.length === 0) {
      console.log("⏭️  No active companies found. Skipping FX update.");
      return;
    }

    for (const company of companies) {
      try {
        // ✅ PATCH 6: Double-check company is active
        if (!company.isActive) {
          console.log(`⏭️  Skipping inactive company: ${company.companyId}`);
          continue;
        }

        console.log(`\n💱 Fetching FX rates for ${company.companyName} (${company.companyId})`);

        const fxData = await fxProvider.fetchFxRates({
          currencies: company.currencies,
          companyId: company.companyId,
        });

        if (fxData && fxData.rates && fxData.rates.length > 0) {
          await FxRateSnapshot.create(fxData);
          console.log(`✅ FX rates updated for ${company.companyName}: ${fxData.rates.length} rates`);
        } else {
          console.log(`⚠️ No FX rates found for ${company.companyName}`);
        }
      } catch (err) {
        // ✅ PATCH 6: Don't crash on single company failure
        console.error(`❌ Error fetching FX rates for ${company.companyName}:`, err.message);
        continue; // Move to next company
      }
    }

    console.log("\n✅ [SCHEDULER] FX rates update completed\n");
  } catch (err) {
    console.error("❌ [SCHEDULER] FX rates update error:", err);
    // ✅ PATCH 6: Don't crash the server
  }
}

async function executeCompaniesUpdate() {
  console.log("\n📄 [SCHEDULER] Starting top companies update...");

  try {
    // ✅ PATCH 6: Only get active companies
    const companies = await getActiveCompanies();
    
    if (companies.length === 0) {
      console.log("⏭️  No active companies found. Skipping companies update.");
      return;
    }

    for (const company of companies) {
      try {
        // ✅ PATCH 6: Double-check company is active
        if (!company.isActive) {
          console.log(`⏭️  Skipping inactive company: ${company.companyId}`);
          continue;
        }

        console.log(`\n🏢 Fetching top companies for ${company.companyName} (${company.companyId})`);

        // ✅ Pass company's language preference
        const language = company.language || 'en';
        const companiesData = await topCompaniesProvider.fetchTopCompanies({
          country: company.country,
          industry: company.industry,
          companyId: company.companyId,
          language: language, // ✅ Pass language to provider
        });

        if (companiesData && companiesData.companies && companiesData.companies.length > 0) {
          await TopCompaniesSnapshot.create(companiesData);
          console.log(`✅ Top companies updated for ${company.companyName}: ${companiesData.companies.length} companies`);
        } else {
          console.log(`⚠️ No companies found for ${company.companyName}`);
        }
      } catch (err) {
        // ✅ PATCH 6: Don't crash on single company failure
        console.error(`❌ Error fetching companies for ${company.companyName}:`, err.message);
        continue; // Move to next company
      }
    }

    console.log("\n✅ [SCHEDULER] Top companies update completed\n");
  } catch (err) {
    console.error("❌ [SCHEDULER] Top companies update error:", err);
    // ✅ PATCH 6: Don't crash the server
  }
}

// ============================================
// CRON Jobs (scheduled: false -> we start them manually)
// ============================================

const fetchNewsJob = cron.schedule("0 9 * * *", executeNewsUpdate, { scheduled: false });
const fetchFxRatesJob = cron.schedule("0 8 * * *", executeFxUpdate, { scheduled: false });
const fetchTopCompaniesJob = cron.schedule("0 10 1 * *", executeCompaniesUpdate, { scheduled: false });

// ============================================
// Start/Stop Functions
// ============================================

function startScheduler() {
  console.log("\n⏰ Starting main scheduler...");
  console.log("📅 Schedule:");
  console.log("   - News: Daily at 9:00 AM");
  console.log("   - FX Rates: Daily at 8:00 AM");
  console.log("   - Top Companies: Monthly on 1st at 10:00 AM");
  console.log("");

  fetchNewsJob.start();
  fetchFxRatesJob.start();
  fetchTopCompaniesJob.start();

  console.log("✅ Main scheduler started successfully\n");
}

function stopScheduler() {
  console.log("⏹️ Stopping main scheduler...");
  fetchNewsJob.stop();
  fetchFxRatesJob.stop();
  fetchTopCompaniesJob.stop();
  console.log("✅ Main scheduler stopped\n");
}

// ============================================
// Manual Triggers (for API routes)
// ============================================

async function runNewsUpdate() {
  await executeNewsUpdate();
}

async function runFxUpdate() {
  await executeFxUpdate();
}

async function runCompaniesUpdate() {
  await executeCompaniesUpdate();
}

// ============================================
// EXPORTS
// ============================================

module.exports = {
  startScheduler,
  stopScheduler,
  runNewsUpdate,
  runFxUpdate,
  runCompaniesUpdate,
};