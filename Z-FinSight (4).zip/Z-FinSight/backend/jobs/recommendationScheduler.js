const cron = require('node-cron');
const aiEngine = require('../services/aiRecommendationEngine');
const Company = require('../models/Company');
const User = require('../models/User');
const NewsItem = require('../models/NewsItem');
const Recommendation = require('../models/Recommendation');
const KpiSnapshot = require('../models/KpiSnapshot');
const Invoice = require('../models/Invoice');
const Bill = require('../models/Bill');
const Transaction = require('../models/Transaction');
const { calculateAllKPIs } = require('../utils/accountingCalculations');
const { getOverviewDashboardMetrics } = require('../utils/dashboardCalculations');

class RecommendationScheduler {
  constructor() {
    this.jobs = [];
  }

  // ============================================
  // Helper: Get Active Companies Only (PATCH 6)
  // ============================================
  async getActiveCompanies() {
    try {
      const companies = await Company.find({ isActive: true }).lean();
      console.log(`✅ Found ${companies.length} active companies for recommendations`);
      return companies;
    } catch (err) {
      console.error("❌ Error fetching active companies:", err);
      return [];
    }
  }

  // ============================================
  // Helper: Get Non-External Active Users (PATCH 6)
  // ============================================
  async getNonExternalUsers(companyId) {
    try {
      const users = await User.find({
        companyId,
        isActive: true,
        roles: { $nin: ['external'] }  // ✅ PATCH 6: Exclude external users
      });
      return users;
    } catch (err) {
      console.error(`❌ Error fetching users for company ${companyId}:`, err);
      return [];
    }
  }

  // 🤖 Generate recommendations for all companies based on recent news
  async generateRecommendationsForAllCompanies() {
    console.log('📊 [SCHEDULER] Starting recommendation generation for all companies...');
    
    try {
      // ✅ PATCH 6: Get only active companies
      const companies = await this.getActiveCompanies();
      
      if (companies.length === 0) {
        console.log('⏭️  No active companies found. Skipping recommendation generation.');
        return;
      }
      
      console.log(`📢 Found ${companies.length} active companies`);

      for (const company of companies) {
        try {
          // ✅ PATCH 6: Double-check company is active
          if (!company.isActive) {
            console.log(`⏭️  Skipping inactive company: ${company.companyId}`);
            continue;
          }

          const language = company.language || 'en';

          // ============================================
          // 1. GENERATE INTERNAL RECOMMENDATIONS (Based on Company Financial Data)
          // ============================================
          console.log(`💰 Generating internal recommendations for ${company.companyName || company.name}...`);
          await this.generateInternalRecommendations(company, language);

          // ============================================
          // 2. GENERATE EXTERNAL RECOMMENDATIONS (Based on News AND Competitors)
          // ============================================
          console.log(`🌐 Generating external recommendations for ${company.companyName || company.name}...`);
          
          // Get recent news relevant to this company (last 24 hours)
          const recentNews = await NewsItem.find({
            $or: [
              { country: company.country },
              { category: company.industry }
            ],
            publishedDate: { $gte: new Date(Date.now() - 24 * 60 * 60 * 1000) }
          })
            .sort({ publishedDate: -1 })
            .limit(5) // Limit to top 5 news items per company
            .lean();

          if (recentNews.length > 0) {
            console.log(`📰 Found ${recentNews.length} recent news items for ${company.companyName || company.name}`);
            
            // Generate external recommendations for each news item
            for (const news of recentNews) {
              try {
                // Check if we already have a recommendation for this news + company combo
                const existingRec = await Recommendation.findOne({
                  companyId: company.companyId,
                  sourceType: 'news',
                  sourceId: news._id,
                  type: 'external'
                });

                if (!existingRec) {
                  // ✅ Pass company's language preference and mark as external
                  const rec = await aiEngine.analyzeNews(news, company, language);
                  if (rec) {
                    rec.type = 'external';
                    await rec.save();
                  }
                  console.log(`✅ Generated external recommendation for ${company.companyName || company.name} - ${news.title} (${language})`);
                  
                  // Wait 2 seconds to avoid rate limiting
                  await new Promise(resolve => setTimeout(resolve, 2000));
                } else {
                  console.log(`⏭️ Skipping - recommendation already exists`);
                }
              } catch (newsErr) {
                // ✅ PATCH 6: Don't crash on single news item failure
                console.error(`❌ Error processing news item:`, newsErr.message);
                continue;
              }
            }
          }

          // Get competitor data and generate recommendations
          await this.generateCompetitorRecommendations(company, language);

        } catch (error) {
          // ✅ PATCH 6: Don't crash on single company failure
          console.error(`❌ Error processing ${company.companyName || company.name}:`, error.message);
          continue; // Move to next company
        }
      }

      console.log('✅ [SCHEDULER] Recommendation generation completed');
    } catch (error) {
      console.error('❌ [SCHEDULER] Error in recommendation generation:', error);
      // ✅ PATCH 6: Don't crash the server
    }
  }

  // 💰 Generate Internal Recommendations Based on Company Financial Data
  async generateInternalRecommendations(company, language = 'en') {
    try {
      const companyId = company.companyId;
      
      // Get latest KPIs
      const latestKPI = await KpiSnapshot.findOne({ 
        companyId, 
        is_current: true 
      })
        .sort({ createdAt: -1 })
        .lean();

      // Get dashboard metrics
      const dashboardMetrics = await getOverviewDashboardMetrics(companyId);

      // Combine financial data
      const financialData = {
        revenue: latestKPI?.revenue || 0,
        cogs: latestKPI?.cogs || 0,
        grossProfit: latestKPI?.grossProfit || 0,
        grossMargin: latestKPI?.grossMargin ? latestKPI.grossMargin / 100 : 0,
        operating_expenses: latestKPI?.operating_expenses || latestKPI?.opex || 0,
        operating_profit: latestKPI?.operating_profit || 0,
        operating_margin: latestKPI?.operating_margin ? latestKPI.operating_margin / 100 : 0,
        interest_expense: latestKPI?.interest_expense || 0,
        profit_before_tax: latestKPI?.profit_before_tax || 0,
        income_tax: latestKPI?.income_tax || latestKPI?.taxes || 0,
        net_profit_after_tax: latestKPI?.net_profit_after_tax || latestKPI?.afterTaxProfit || 0,
        net_profit_margin: latestKPI?.net_profit_margin || latestKPI?.netMargin ? (latestKPI.net_profit_margin || latestKPI.netMargin) / 100 : 0,
        taxBurden: latestKPI?.taxBurden ? latestKPI.taxBurden / 100 : 0,
        current_assets: latestKPI?.current_assets || 0,
        current_liabilities: latestKPI?.current_liabilities || 0,
        current_ratio: latestKPI?.current_ratio || null,
        overdueInvoices: dashboardMetrics?.overdueInvoices || 0,
        billsDue: dashboardMetrics?.billsDue || 0,
        uncategorizedTransactions: dashboardMetrics?.uncategorizedTransactions || 0,
      };

      // Check if we already have a recent financial recommendation (within last 7 days)
      const existingRec = await Recommendation.findOne({
        companyId,
        sourceType: 'financial',
        type: 'internal',
        createdAt: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) }
      });

      if (!existingRec && (latestKPI || dashboardMetrics)) {
        // Generate recommendation based on financial data
        await aiEngine.analyzeFinancialData(company, financialData, language);
        console.log(`✅ Generated internal recommendation based on financial data for ${company.companyName || company.name}`);
      } else if (existingRec) {
        console.log(`⏭️ Recent internal recommendation already exists for ${company.companyName || company.name}`);
      } else {
        console.log(`ℹ️ No financial data available for ${company.companyName || company.name} - skipping internal recommendations`);
      }
    } catch (error) {
      console.error(`❌ Error generating internal recommendations:`, error.message);
    }
  }

  // 🏢 Generate External Recommendations Based on Competitor Data
  async generateCompetitorRecommendations(company, language = 'en') {
    try {
      const companyId = company.companyId;
      
      // Get other companies in the same industry/country (competitors)
      const competitors = await Company.find({
        isActive: true,
        companyId: { $ne: companyId }, // Exclude current company
        $or: [
          { industry: company.industry },
          { country: company.country }
        ]
      })
        .select('companyId companyName industry country')
        .limit(5)
        .lean();

      if (competitors.length > 0) {
        console.log(`🏢 Found ${competitors.length} competitors for ${company.companyName || company.name}`);
        
        // Generate recommendations for top competitors
        for (const competitor of competitors.slice(0, 3)) { // Limit to top 3
          try {
            // Check if we already have a recommendation for this competitor
            const existingRec = await Recommendation.findOne({
              companyId,
              sourceType: 'competitor',
              sourceTitle: { $regex: competitor.companyName || competitor.companyId, $options: 'i' },
              type: 'external',
              createdAt: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) } // Last 7 days
            });

            if (!existingRec) {
              // Get competitor's latest KPIs for comparison
              const competitorKPI = await KpiSnapshot.findOne({ 
                companyId: competitor.companyId, 
                is_current: true 
              })
                .sort({ createdAt: -1 })
                .lean();

              const competitorData = {
                name: competitor.companyName || competitor.companyId,
                industry: competitor.industry,
                country: competitor.country,
                revenue: competitorKPI?.revenue || 0,
                netMargin: competitorKPI?.net_profit_margin || competitorKPI?.netMargin || 0,
              };

              const rec = await aiEngine.analyzeCompetitor(competitorData, company, language);
              console.log(`✅ Generated competitor recommendation for ${company.companyName || company.name} - ${competitorData.name}`);
              
              // Wait 2 seconds to avoid rate limiting
              await new Promise(resolve => setTimeout(resolve, 2000));
            }
          } catch (compErr) {
            console.error(`❌ Error processing competitor:`, compErr.message);
            continue;
          }
        }
      } else {
        console.log(`ℹ️ No competitors found for ${company.companyName || company.name}`);
      }
    } catch (error) {
      console.error(`❌ Error generating competitor recommendations:`, error.message);
    }
  }

  // 🎲 Generate dummy recommendations when no news is available (DEPRECATED - kept for backward compatibility)
  async generateDummyRecommendations(company) {
    try {
      const language = company.language || 'en';
      const dummyRecommendations = [
        {
          title: language === 'ar' 
            ? 'مراجعة استراتيجية التسعير للربع القادم'
            : 'Review pricing strategy for next quarter',
          insight: language === 'ar'
            ? 'تحليل تنافسي للسوق يمكن أن يكشف فرص تحسين هوامش الربح'
            : 'Competitive market analysis could reveal opportunities to improve profit margins',
          category: 'Financial Planning',
          priority: 'Medium',
          recommendations: language === 'ar'
            ? ['تحليل أسعار المنافسين', 'مراجعة هيكل التكاليف', 'اختبار استراتيجيات تسعير جديدة']
            : ['Analyze competitor pricing', 'Review cost structure', 'Test new pricing strategies'],
          opportunities: language === 'ar'
            ? ['زيادة هوامش الربح', 'تحسين القدرة التنافسية']
            : ['Increase profit margins', 'Improve competitiveness'],
          risks: language === 'ar'
            ? ['فقدان حصة السوق إذا كانت الأسعار مرتفعة']
            : ['Losing market share if prices are too high'],
        },
        {
          title: language === 'ar'
            ? 'تحسين إدارة التدفق النقدي'
            : 'Improve cash flow management',
          insight: language === 'ar'
            ? 'مراقبة أفضل للذمم المدينة والدائنة يمكن أن تحسن السيولة'
            : 'Better monitoring of receivables and payables can improve liquidity',
          category: 'Operational Efficiency',
          priority: 'High',
          recommendations: language === 'ar'
            ? ['تسريع تحصيل الفواتير', 'تفاوض شروط دفع أفضل مع الموردين', 'إنشاء توقعات تدفق نقدي شهرية']
            : ['Accelerate invoice collection', 'Negotiate better payment terms with suppliers', 'Create monthly cash flow forecasts'],
          opportunities: language === 'ar'
            ? ['تحسين السيولة', 'تقليل التكاليف المالية']
            : ['Improve liquidity', 'Reduce financing costs'],
          risks: language === 'ar'
            ? ['نقص السيولة في فترات الذروة']
            : ['Cash shortages during peak periods'],
        },
        {
          title: language === 'ar'
            ? 'توسيع قاعدة العملاء'
            : 'Expand customer base',
          insight: language === 'ar'
            ? 'استهداف قطاعات سوق جديدة يمكن أن يزيد الإيرادات'
            : 'Targeting new market segments could increase revenue',
          category: 'Growth Strategy',
          priority: 'Medium',
          recommendations: language === 'ar'
            ? ['إجراء بحث السوق', 'تطوير منتجات جديدة', 'زيادة جهود التسويق']
            : ['Conduct market research', 'Develop new products', 'Increase marketing efforts'],
          opportunities: language === 'ar'
            ? ['زيادة الإيرادات', 'تنويع مصادر الدخل']
            : ['Increase revenue', 'Diversify income sources'],
          risks: language === 'ar'
            ? ['استثمارات كبيرة بدون عائد مضمون']
            : ['Large investments without guaranteed returns'],
        },
      ];

      // Generate 1-2 dummy recommendations per company
      const numRecommendations = Math.floor(Math.random() * 2) + 1;
      const selected = dummyRecommendations.slice(0, numRecommendations);

      for (const dummy of selected) {
        // Check if similar recommendation already exists
        const existing = await Recommendation.findOne({
          companyId: company.companyId,
          title: dummy.title,
          createdAt: { $gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) } // Last 7 days
        });

        if (!existing) {
          await Recommendation.create({
            companyId: company.companyId,
            sourceType: 'financial',
            sourceTitle: 'System Generated',
            category: dummy.category,
            priority: dummy.priority,
            title: dummy.title,
            insight: dummy.insight,
            recommendations: dummy.recommendations,
            opportunities: dummy.opportunities,
            risks: dummy.risks,
            status: 'new',
            type: 'internal',
            confidence: 75,
            reasoning: language === 'ar'
              ? 'توصية مبنية على أفضل الممارسات المالية'
              : 'Recommendation based on financial best practices',
          });
          console.log(`✅ Generated dummy recommendation: ${dummy.title} for ${company.companyName || company.name}`);
        }
      }
    } catch (error) {
      console.error(`❌ Error generating dummy recommendations:`, error.message);
    }
  }

  // 🧹 Clean up old recommendations
  async cleanupOldRecommendations() {
    console.log('🧹 [SCHEDULER] Cleaning up old recommendations...');
    
    try {
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - 60); // Delete recommendations older than 60 days

      const result = await Recommendation.deleteMany({
        status: { $in: ['dismissed', 'archived'] },
        updatedAt: { $lt: cutoffDate }
      });

      console.log(`✅ Cleaned up ${result.deletedCount} old recommendations`);
    } catch (error) {
      console.error('❌ Error cleaning up recommendations:', error);
      // ✅ PATCH 6: Don't crash the server
    }
  }

  // 📊 Update priority for aging recommendations
  async updateRecommendationPriorities() {
    console.log('📊 [SCHEDULER] Updating recommendation priorities...');
    
    try {
      // Get all unactioned recommendations older than 7 days
      const oldRecs = await Recommendation.find({
        status: { $in: ['new', 'viewed'] },
        createdAt: { $lt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) }
      });

      let updated = 0;
      
      for (const rec of oldRecs) {
        try {
          // Downgrade priority if not actioned
          if (rec.priority === 'Critical') {
            rec.priority = 'High';
            await rec.save();
            updated++;
          } else if (rec.priority === 'High') {
            rec.priority = 'Medium';
            await rec.save();
            updated++;
          }
        } catch (recErr) {
          // ✅ PATCH 6: Don't crash on single rec failure
          console.error(`❌ Error updating recommendation ${rec._id}:`, recErr.message);
          continue;
        }
      }

      console.log(`✅ Updated priority for ${updated} recommendations`);
    } catch (error) {
      console.error('❌ Error updating priorities:', error);
      // ✅ PATCH 6: Don't crash the server
    }
  }

  // 📈 Generate daily summary stats
  async generateDailySummary() {
    console.log('📈 [SCHEDULER] Generating daily summary...');
    
    try {
      // ✅ PATCH 6: Only get active companies
      const companies = await this.getActiveCompanies();
      
      const summary = {
        date: new Date(),
        totalRecommendations: 0,
        byPriority: { Critical: 0, High: 0, Medium: 0, Low: 0 },
        byStatus: {},
        topCompanies: []
      };

      for (const company of companies) {
        try {
          const count = await Recommendation.countDocuments({
            companyId: company.companyId,
            status: 'new'
          });

          if (count > 0) {
            summary.topCompanies.push({
              companyId: company.companyId,
              name: company.companyName,
              newRecommendations: count
            });
          }
        } catch (compErr) {
          // ✅ PATCH 6: Don't crash on single company failure
          console.error(`❌ Error getting stats for ${company.companyId}:`, compErr.message);
          continue;
        }
      }

      summary.topCompanies.sort((a, b) => b.newRecommendations - a.newRecommendations);
      summary.topCompanies = summary.topCompanies.slice(0, 10);

      console.log('📊 Daily Summary:', JSON.stringify(summary, null, 2));
    } catch (error) {
      console.error('❌ Error generating summary:', error);
      // ✅ PATCH 6: Don't crash the server
    }
  }

  // 🚀 Start all scheduled jobs
  startAll() {
    console.log('🚀 Starting Recommendation Scheduler Jobs...');

    // Job 1: Generate recommendations every 2 hours
    const job1 = cron.schedule('0 */2 * * *', () => {
      this.generateRecommendationsForAllCompanies();
    });
    this.jobs.push({ name: 'Generate Recommendations', job: job1 });
    console.log('✅ Job 1: Generate recommendations every 2 hours');

    // Job 2: Clean up old recommendations daily at 2 AM
    const job2 = cron.schedule('0 2 * * *', () => {
      this.cleanupOldRecommendations();
    });
    this.jobs.push({ name: 'Cleanup Old Recommendations', job: job2 });
    console.log('✅ Job 2: Cleanup old recommendations daily at 2 AM');

    // Job 3: Update priorities daily at 3 AM
    const job3 = cron.schedule('0 3 * * *', () => {
      this.updateRecommendationPriorities();
    });
    this.jobs.push({ name: 'Update Priorities', job: job3 });
    console.log('✅ Job 3: Update priorities daily at 3 AM');

    // Job 4: Generate daily summary at 9 AM
    const job4 = cron.schedule('0 9 * * *', () => {
      this.generateDailySummary();
    });
    this.jobs.push({ name: 'Daily Summary', job: job4 });
    console.log('✅ Job 4: Generate daily summary at 9 AM');

    console.log(`✅ ${this.jobs.length} Recommendation Scheduler Jobs Started Successfully!`);
  }

  // 🛑 Stop all jobs
  stopAll() {
    console.log('🛑 Stopping all recommendation scheduler jobs...');
    this.jobs.forEach(({ name, job }) => {
      job.stop();
      console.log(`✅ Stopped: ${name}`);
    });
    this.jobs = [];
  }

  // 🔄 Manually trigger recommendation generation (for testing)
  async triggerManual() {
    console.log('🔄 Manual trigger: Generating recommendations...');
    await this.generateRecommendationsForAllCompanies();
  }
}

module.exports = new RecommendationScheduler();