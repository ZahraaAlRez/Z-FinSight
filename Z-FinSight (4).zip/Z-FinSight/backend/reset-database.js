/**
 * Reset Database Script
 * 
 * This script deletes all documents from the following collections:
 * - companies
 * - admins
 * - users
 * - verificationcodes
 * - recommendations (optional, but included for clean reset)
 * 
 * After running this script, the companyId counter will restart from CMP_001
 * because the Company model's pre-save hook generates companyId based on
 * the last company in the database.
 * 
 * Usage:
 *   npm run reset:db
 *   or
 *   node reset-database.js
 * 
 * WARNING: This will permanently delete all data!
 */

require('dotenv').config();
const mongoose = require('mongoose');

// Import models to ensure they're registered
const Company = require('./models/Company');
const Admin = require('./models/Admin');
const User = require('./models/User');
const VerificationCode = require('./models/VerificationCode');
const Recommendation = require('./models/Recommendation');
const NewsItem = require('./models/NewsItem');
const TopCompaniesSnapshot = require('./models/TopCompaniesSnapshot');
const FxRateSnapshot = require('./models/FxRateSnapshot');

// Collections to reset
const COLLECTIONS_TO_RESET = [
  'companies',
  'admins',
  'users',
  'verificationcodes',
  'recommendations',
  'newsitems',
  'topcompaniessnapshots',
  'fxratesnapshots',
];

async function resetDatabase() {
  try {
    // Check if MONGO_URI is set
    if (!process.env.MONGO_URI) {
      console.error('❌ Error: MONGO_URI is not set in .env file');
      process.exit(1);
    }

    console.log('🔄 Connecting to MongoDB...');
    console.log('   URI:', process.env.MONGO_URI.replace(/\/\/.*@/, '//***:***@')); // Hide credentials

    // Connect to MongoDB
    await mongoose.connect(process.env.MONGO_URI);
    console.log('✅ Connected to MongoDB');

    // Get database instance
    const db = mongoose.connection.db;

    // Get all collection names
    const allCollections = await db.listCollections().toArray();
    const collectionNames = allCollections.map(c => c.name);

    console.log('\n📊 Found collections:', collectionNames.join(', '));

    // Delete documents from each collection
    let totalDeleted = 0;
    const results = {};

    for (const collectionName of COLLECTIONS_TO_RESET) {
      // Check if collection exists (case-insensitive)
      const actualCollectionName = collectionNames.find(
        name => name.toLowerCase() === collectionName.toLowerCase()
      );

      if (!actualCollectionName) {
        console.log(`⏭️  Collection "${collectionName}" not found, skipping...`);
        results[collectionName] = 0;
        continue;
      }

      try {
        const collection = db.collection(actualCollectionName);
        const count = await collection.countDocuments();
        
        if (count > 0) {
          const deleteResult = await collection.deleteMany({});
          results[collectionName] = deleteResult.deletedCount;
          totalDeleted += deleteResult.deletedCount;
          console.log(`✅ Deleted ${deleteResult.deletedCount} document(s) from "${actualCollectionName}"`);
        } else {
          results[collectionName] = 0;
          console.log(`ℹ️  Collection "${actualCollectionName}" is already empty`);
        }
      } catch (err) {
        console.error(`❌ Error deleting from "${actualCollectionName}":`, err.message);
        results[collectionName] = -1; // Error indicator
      }
    }

    // Summary
    console.log('\n' + '='.repeat(50));
    console.log('📋 RESET SUMMARY');
    console.log('='.repeat(50));
    for (const [collection, count] of Object.entries(results)) {
      if (count === -1) {
        console.log(`   ${collection}: ❌ Error`);
      } else {
        console.log(`   ${collection}: ${count} document(s) deleted`);
      }
    }
    console.log('='.repeat(50));
    console.log(`✅ Total documents deleted: ${totalDeleted}`);
    console.log('='.repeat(50));

    // Note about companyId
    console.log('\n💡 Note: Company ID counter will restart from CMP_001');
    console.log('   The next company registration will get CMP_001 automatically.\n');

    // Close connection
    await mongoose.connection.close();
    console.log('✅ Database connection closed');
    console.log('✅ Reset complete!');

    process.exit(0);

  } catch (err) {
    console.error('\n❌ Error resetting database:', err);
    console.error('   Stack:', err.stack);
    
    // Try to close connection
    try {
      await mongoose.connection.close();
    } catch (closeErr) {
      // Ignore close errors
    }
    
    process.exit(1);
  }
}

// Run the reset
console.log('🚀 Starting database reset...\n');
resetDatabase();
