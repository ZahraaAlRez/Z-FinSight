// backend/models/ExternalSnapshot.js
const mongoose = require("mongoose");

const ExternalSnapshotSchema = new mongoose.Schema(
  {
    // Company identifier (public code like "CMP_001")
    companyId: { 
      type: String, 
      required: true,
      index: true
    },
    
    // Pack type (bank, investor, auditor, partner)
    packType: { 
      type: String, 
      required: true,
      enum: ["bank", "investor", "auditor", "partner"],
      index: true
    },
    
    // Period identifier (e.g., "2026-01" or date range)
    period: { 
      type: String, 
      default: "" 
    },
    
    // Metrics (pack-scoped)
    metrics: {
      netProfit: { type: Number, default: null },
      netMargin: { type: Number, default: null },
      liquidity: { type: Number, default: null },
      debtEquity: { type: Number, default: null },
      dscr: { type: Number, default: null },
      cashBank: { type: Number, default: null },
      runwayMonths: { type: Number, default: null },
      // Additional metrics can be added here
    },
    
    // Section data
    liquidity: {
      currentRatio: { type: Number, default: null },
      quickRatio: { type: Number, default: null },
      notes: { type: String, default: "" }
    },
    
    debt: {
      debtEquity: { type: Number, default: null },
      dscr: { type: Number, default: null },
      notes: { type: String, default: "" }
    },
    
    cashflow: {
      cashIn: { type: Number, default: null },
      cashOut: { type: Number, default: null },
      net: { type: Number, default: null }
    },
    
    // Allowed sections for this pack
    allowedSections: {
      type: [String],
      default: []
    },
    
    // Reports list
    reports: [{
      title: { type: String, required: true },
      url: { type: String, default: "" },
      type: { type: String, default: "" },
      format: { type: String, default: "" },
      period: { type: String, default: "" },
      createdAt: { type: Date, default: Date.now }
    }],
    
    // Documents list
    docs: [{
      title: { type: String, required: true },
      url: { type: String, default: "" },
      type: { type: String, default: "" },
      format: { type: String, default: "" },
      date: { type: String, default: "" }
    }],
    
    // Latest note
    note: { 
      type: String, 
      default: "" 
    },
    
    // Currency
    currency: {
      type: String,
      default: "USD"
    },
    
    // Metadata
    publishedBy: { 
      type: String, // userId
      required: true
    },
    publishedAt: { 
      type: Date, 
      default: Date.now 
    },
    isCurrent: { 
      type: Boolean, 
      default: true,
      index: true
    }
  },
  { timestamps: true }
);

// Indexes for efficient queries
ExternalSnapshotSchema.index({ companyId: 1, packType: 1, isCurrent: 1 });
ExternalSnapshotSchema.index({ companyId: 1, packType: 1, publishedAt: -1 });

// Static method to get latest snapshot for a company and pack
ExternalSnapshotSchema.statics.getLatest = async function(companyId, packType) {
  return this.findOne({ 
    companyId, 
    packType, 
    isCurrent: true 
  }).sort({ publishedAt: -1 });
};

// Static method to mark previous snapshots as not current
ExternalSnapshotSchema.statics.markPreviousAsNotCurrent = async function(companyId, packType) {
  return this.updateMany(
    { companyId, packType, isCurrent: true },
    { $set: { isCurrent: false } }
  );
};

module.exports = mongoose.model("ExternalSnapshot", ExternalSnapshotSchema);
