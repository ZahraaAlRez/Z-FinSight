const mongoose = require("mongoose");

/**
 * Counter model (Atomic sequence generator)
 * Stored in collection: counters
 */
const counterSchema = new mongoose.Schema(
  {
    _id: { type: String, required: true }, // e.g. "companyId"
    seq: { type: Number, default: 0 },
  },
  { versionKey: false }
);

// Prevent OverwriteModelError in dev/hot-reload
const Counter =
  mongoose.models.Counter || mongoose.model("Counter", counterSchema);

const companySchema = new mongoose.Schema({
  companyId: {
    type: String,
    unique: true,
    // Auto-generated in pre-save hook (CMP_001, CMP_002, etc.)
  },
  companyName: {
    type: String,
    required: true,
    trim: true,
  },
  industry: {
    type: String,
    required: true,
    trim: true,
    lowercase: true,
    // Used for: News filtering, Top companies recommendations
  },
  industryOther: {
    type: String,
    default: "",
    // If industry === "other", this contains the custom value
  },
  country: {
    type: String,
    required: true,
    trim: true,
    lowercase: true,
    // Used for: News filtering, Top companies recommendations
  },
  countryOther: {
    type: String,
    default: "",
    // If country === "other", this contains the custom value
  },
  currencies: {
    type: [String],
    required: true,
    validate: {
      validator: function (arr) {
        return arr && arr.length > 0;
      },
      message: "At least one currency is required",
    },
    // Example: ["USD", "LBP", "EUR"]
  },
  companyEmail: {
    type: String,
    default: "",
    trim: true,
    lowercase: true,
  },
  language: {
    type: String,
    enum: ["ar", "en"],
    default: "en",
    trim: true,
    lowercase: true,
  },
  isActive: {
    type: Boolean,
    default: false,
  },
  isVerified: {
    type: Boolean,
    default: false,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

// (Optional but helpful) enforce unique index explicitly
companySchema.index({ companyId: 1 }, { unique: true, sparse: true });

/**
 * ✅ Atomic auto-increment companyId before saving
 * Works safely with MongoDB Atlas (no race conditions).
 */
companySchema.pre("save", async function () {
  if (this.isNew && !this.companyId) {
    // 1) Atomically increment counter
    const counterDoc = await Counter.findOneAndUpdate(
      { _id: "companyId" },
      { $inc: { seq: 1 } },
      { new: true, upsert: true }
    );

    // 2) Build CMP_XXX
    this.companyId = `CMP_${String(counterDoc.seq).padStart(3, "0")}`;

    console.log("✅ Auto-generated companyId:", this.companyId);
  }
});

module.exports = mongoose.model("Company", companySchema);
