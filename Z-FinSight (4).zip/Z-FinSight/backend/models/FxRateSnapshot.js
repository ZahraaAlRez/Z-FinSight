const mongoose = require("mongoose");

const FxRateSnapshotSchema = new mongoose.Schema(
  {
    // 🔗 Link to company (public id like CMP_007)
    companyId: {
      type: String,
      required: true,
      index: true,
    },

    // Optional Mongo reference (if needed later)
    companyDbId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Company",
    },

    // 💱 Exchange rates data
    rates: [
      {
        // Base currency (e.g., "USD")
        base: {
          type: String,
          required: true,
          uppercase: true,
          trim: true,
        },

        // Target currency (e.g., "LBP")
        target: {
          type: String,
          required: true,
          uppercase: true,
          trim: true,
        },

        // Exchange rate value (e.g., 89500)
        rate: {
          type: Number,
          required: true,
        },

        // Rate change from previous snapshot (optional)
        change: {
          type: Number,
          default: 0,
        },

        // Percentage change
        changePercent: {
          type: Number,
          default: 0,
        },

        // Last update time for this specific rate
        updatedAt: {
          type: Date,
          default: Date.now,
        },
      },
    ],

    // 🌐 Data provider info
    provider: {
      type: String,
      default: "manual",
      // Examples: "exchangerate-api", "fixer.io", "manual"
    },

    // 🕒 Timestamps
    fetchedAt: {
      type: Date,
      default: Date.now,
      // When we fetched this data from external API
    },

    // 🛑 Prevent duplicates (optional)
    dedupeKey: {
      type: String,
      unique: true,
      sparse: true,
      // Format: "CMP_007_2024-01-15" (companyId + date)
    },
  },
  {
    timestamps: true, // Adds createdAt and updatedAt
  }
);

// Indexes for performance
FxRateSnapshotSchema.index({ companyId: 1, fetchedAt: -1 });

// ✅ FIXED: Pre-save hook to generate dedupeKey
FxRateSnapshotSchema.pre("save", function () {
  if (this.isNew && !this.dedupeKey) {
    const date = new Date().toISOString().split("T")[0]; // YYYY-MM-DD
    this.dedupeKey = `${this.companyId}_${date}`;
  }
});

// آخر سطر:
module.exports = mongoose.models.FxRateSnapshot || mongoose.model("FxRateSnapshot", FxRateSnapshotSchema);