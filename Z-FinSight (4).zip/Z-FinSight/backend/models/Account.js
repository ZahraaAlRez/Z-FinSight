const mongoose = require("mongoose");

const AccountSchema = new mongoose.Schema(
  {
    companyId: {
      type: String,
      required: true,
      index: true,
    },

    account_name: {
      type: String,
      required: true,
      trim: true,
    },

    account_type: {
      type: String,
      enum: ["asset", "liability", "equity", "revenue", "expense", "cogs"],
      required: true,
      index: true,
    },

    account_subtype: {
      type: String,
      enum: ["current", "non_current", null],
      default: null,
    },

    is_cash_account: {
      type: Boolean,
      default: false,
    },

    is_bank_account: {
      type: Boolean,
      default: false,
    },

    current_balance: {
      type: Number,
      default: 0,
    },

    is_active: {
      type: Boolean,
      default: true,
      index: true,
    },

    category_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "AccountCategory",
      default: null,
    },

    expense_category: {
      type: String,
      enum: ["selling", "general", "administrative", "marketing", "research", "financing", "tax", null],
      default: null,
    },
  },
  { timestamps: true }
);

// Compound indexes
AccountSchema.index({ companyId: 1, account_type: 1 });
AccountSchema.index({ companyId: 1, is_active: 1 });

module.exports = mongoose.model("Account", AccountSchema);
