const mongoose = require("mongoose");

const InvoiceSchema = new mongoose.Schema(
  {
    companyId: {
      type: String,
      required: true,
      index: true,
    },

    invoice_number: {
      type: String,
      required: true,
      trim: true,
    },

    invoice_type: {
      type: String,
      enum: ["sales", "purchase"],
      required: true,
      default: "sales",
    },

    customer_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Customer",
      default: null,
    },

    vendor_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Vendor",
      default: null,
    },

    invoice_date: {
      type: Date,
      required: true,
      index: true,
    },

    due_date: {
      type: Date,
      required: true,
      index: true,
    },

    total_amount: {
      type: Number,
      required: true,
      min: 0,
    },

    balance_due: {
      type: Number,
      default: 0,
      min: 0,
      index: true,
    },

    status: {
      type: String,
      enum: ["unpaid", "partially_paid", "paid", "cancelled"],
      default: "unpaid",
      index: true,
    },

    is_posted: {
      type: Boolean,
      default: false,
      index: true,
    },

    currency: {
      type: String,
      default: "USD",
    },

    description: {
      type: String,
      default: "",
      trim: true,
    },
  },
  { timestamps: true }
);

// Compound indexes
InvoiceSchema.index({ companyId: 1, due_date: 1 });
InvoiceSchema.index({ companyId: 1, status: 1 });
InvoiceSchema.index({ companyId: 1, balance_due: 1 });

module.exports = mongoose.model("Invoice", InvoiceSchema);
