const mongoose = require("mongoose");

const UploadSchema = new mongoose.Schema({
  companyId: { type: String, index: true, required: true },
  kind: { type: String, default: "generic" }, // transactions|receipts|bank_statement|generic
  originalName: String,
  mimeType: String,
  size: Number,
  storedAt: { type: Date, default: Date.now },

  parseStatus: { type: String, default: "pending" }, // pending|parsed|failed
  parseError: { type: String, default: "" },

  meta: { type: Object, default: {} } // counts, columns, etc
}, { timestamps: true });

module.exports = mongoose.model("Upload", UploadSchema);
