const mongoose = require("mongoose");

const NewsItemSchema = new mongoose.Schema(
  {
    // 🔗 Link to company (public id like CMP_007)
    companyId: {
      type: String,
      required: true,
      index: true,
    },

    // Optional Mongo reference (if needed later)
    companyDbId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Company",
    },

    // 📰 News content
    title: {
      type: String,
      required: true,
      trim: true,
    },

    summary: {
      type: String,
      default: "",
    },

    url: {
      type: String,
      required: true,
    },

    source: {
      type: String,
      default: "unknown",
    },

    // 🏷️ Context
    country: {
      type: String,
    },

    industry: {
      type: String,
    },

    tags: [
      {
        type: String,
      },
    ],

    // 🧠 AI-ready fields (later)
    sentiment: {
      type: String,
      enum: ["positive", "neutral", "negative"],
      default: "neutral",
    },

    // 🕒 Dates
    publishedAt: {
      type: Date,
    },

    fetchedAt: {
      type: Date,
      default: Date.now,
    },

    // 🛑 Prevent duplicates
    dedupeKey: {
      type: String,
      unique: true,
      sparse: true,
    },

    provider: {
      type: String,
      default: "manual",
    },
  },
  {
    timestamps: true,
  }
);

// Indexes for performance
NewsItemSchema.index({ companyId: 1, publishedAt: -1 });

// آخر سطر:
module.exports = mongoose.models.NewsItem || mongoose.model("NewsItem", NewsItemSchema);
