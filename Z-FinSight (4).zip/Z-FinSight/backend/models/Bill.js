const mongoose = require("mongoose");

const BillSchema = new mongoose.Schema(
  {
    companyId: {
      type: String,
      required: true,
      index: true,
    },

    bill_number: {
      type: String,
      required: true,
      trim: true,
    },

    bill_type: {
      type: String,
      enum: ["purchase"],
      required: true,
      default: "purchase",
    },

    vendor_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Vendor",
      default: null,
    },

    bill_date: {
      type: Date,
      required: true,
      index: true,
    },

    due_date: {
      type: Date,
      required: true,
      index: true,
    },

    total_amount: {
      type: Number,
      required: true,
      min: 0,
    },

    balance_due: {
      type: Number,
      default: 0,
      min: 0,
      index: true,
    },

    status: {
      type: String,
      enum: ["unpaid", "partially_paid", "paid", "cancelled"],
      default: "unpaid",
      index: true,
    },

    is_posted: {
      type: Boolean,
      default: false,
      index: true,
    },

    currency: {
      type: String,
      default: "USD",
    },

    description: {
      type: String,
      default: "",
      trim: true,
    },
  },
  { timestamps: true }
);

// Compound indexes
BillSchema.index({ companyId: 1, due_date: 1 });
BillSchema.index({ companyId: 1, status: 1 });
BillSchema.index({ companyId: 1, balance_due: 1 });

module.exports = mongoose.model("Bill", BillSchema);
