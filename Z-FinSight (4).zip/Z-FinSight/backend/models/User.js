const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    companyId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Company",
      required: true,
      // Indexed via compound index below: { companyId: 1, username: 1 }
    },

    fullName: { type: String, required: true, trim: true },

    // ✅ username should be unique PER company (NOT global)
    username: { type: String, required: true, trim: true },

    // ✅ email is usually unique globally (login identity)
    email: {
      type: String,
      required: true,
      lowercase: true,
      trim: true,
      unique: true,
      index: true,
    },

    department: { type: String, required: true, trim: true },

    roles: {
      type: [String],
      default: [],
      enum: ["admin", "manager", "accountant", "financial_analyst", "external"],
    },

    // ✅ IMPORTANT: auth/user-login checks this
    isActive: { type: Boolean, default: true },

    passwordHash: { type: String, required: true },
    mustChangePassword: { type: Boolean, default: false },

    externalType: {
      type: String,
      enum: ["bank", "investor", "government", "auditor", "other"],
      default: null,
    },

    allowedModules: {
      type: [String],
      default: [],
      enum: ["profitability", "market", "efficiency", "debt", "liquidity", "tax"],
    },

    accessExpiry: { type: Date, default: null },

    // Password reset fields
    resetPasswordTokenHash: { 
      type: String, 
      default: null,
      index: true,
    },
    resetPasswordExpires: { 
      type: Date, 
      default: null,
    },
  },
  { timestamps: true }
);

// ✅ compound unique index (companyId + username)
userSchema.index({ companyId: 1, username: 1 }, { unique: true });

module.exports = mongoose.model("User", userSchema);



