const mongoose = require("mongoose");

const BankAccountSchema = new mongoose.Schema(
  {
    companyId: {
      type: String,
      required: true,
      index: true,
    },

    account_name: {
      type: String,
      required: true,
      trim: true,
    },

    account_type: {
      type: String,
      enum: ["checking", "savings"],
      required: true,
    },

    current_balance: {
      type: Number,
      default: 0,
    },

    is_active: {
      type: Boolean,
      default: true,
      index: true,
    },

    last_reconciled_date: {
      type: Date,
      default: null,
    },

    account_number: {
      type: String,
      default: "",
      trim: true,
    },

    bank_name: {
      type: String,
      default: "",
      trim: true,
    },

    currency: {
      type: String,
      default: "USD",
    },
  },
  { timestamps: true }
);

// Compound indexes
BankAccountSchema.index({ companyId: 1, is_active: 1 });

module.exports = mongoose.model("BankAccount", BankAccountSchema);
