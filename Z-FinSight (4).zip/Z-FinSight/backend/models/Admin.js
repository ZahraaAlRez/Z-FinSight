const mongoose = require("mongoose");

const adminSchema = new mongoose.Schema({
  companyId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Company",
    required: true,
  },
  fullName: {
    type: String,
    required: true,
    trim: true,
  },
  username: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true,
    minlength: 3,
  },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true,
  },
  passwordHash: {
    type: String,
    required: true,
  },
  isVerified: {
    type: Boolean,
    default: false,
  },
  // ✅ ADDED: isActive field for admin account status
  isActive: {
    type: Boolean,
    default: true,
  },
  roles: {
    type: [String],
    default: ["admin"],
    // Array of roles: ["admin"], can be extended later
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

// ✅ Safe export - prevents overwrite error
module.exports = mongoose.models.Admin || mongoose.model("Admin", adminSchema);