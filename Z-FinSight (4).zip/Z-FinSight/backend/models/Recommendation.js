const mongoose = require('mongoose');

const recommendationSchema = new mongoose.Schema({
  // 🔗 Linking
  companyId: {
    type: String,
    required: true,
    index: true
  },
  
  // 📊 Source Information
  sourceType: {
    type: String,
    enum: ['news', 'competitor', 'fx', 'financial', 'market'],
    required: true
  },
  sourceId: {
    type: mongoose.Schema.Types.ObjectId,
    required: false // Optional - some recommendations might be generated without specific source
  },
  sourceTitle: {
    type: String,
    default: ''
  },
  
  // 🎯 Classification
  type: {
    type: String,
    enum: ['internal', 'external'],
    default: 'internal',
    index: true
  },
  
  category: {
    type: String,
    enum: [
      'Market Opportunity',
      'Risk Mitigation',
      'Competitive Strategy',
      'Financial Planning',
      'Operational Efficiency',
      'Strategic Investment',
      'Crisis Management',
      'Growth Strategy',
      'Cost Optimization',
      'Customer Retention'
    ],
    required: true
  },
  
  priority: {
    type: String,
    enum: ['Critical', 'High', 'Medium', 'Low'],
    default: 'Medium',
    required: true
  },
  
  impact: {
    type: String,
    enum: ['High', 'Medium', 'Low'],
    default: 'Medium'
  },
  
  // 📝 Content
  title: {
    type: String,
    required: true,
    trim: true
  },
  
  insight: {
    type: String,
    required: true,
    trim: true
  },
  
  opportunities: [{
    type: String,
    trim: true
  }],
  
  risks: [{
    type: String,
    trim: true
  }],
  
  recommendations: [{
    type: String,
    trim: true,
    required: true
  }],
  
  // 📈 Analysis Details
  aiAnalysis: {
    confidence: {
      type: Number,
      min: 0,
      max: 100,
      default: 0
    },
    reasoning: {
      type: String,
      default: ''
    }
  },
  
  // ✅ Status & Actions
  status: {
    type: String,
    enum: ['new', 'viewed', 'in_progress', 'implemented', 'dismissed', 'archived'],
    default: 'new',
    required: true
  },
  
  viewedAt: {
    type: Date,
    default: null
  },
  
  implementedAt: {
    type: Date,
    default: null
  },
  
  dismissedAt: {
    type: Date,
    default: null
  },
  
  // 📝 Notes & Feedback
  notes: {
    type: String,
    default: ''
  },
  
  feedback: {
    rating: {
      type: Number,
      min: 1,
      max: 5
    },
    comment: String
  },
  
  // 🕐 Timestamps
  expiresAt: {
    type: Date,
    default: null
  }
}, {
  timestamps: true
});

// 🔍 Indexes for better performance
recommendationSchema.index({ companyId: 1, status: 1 });
recommendationSchema.index({ companyId: 1, priority: 1 });
recommendationSchema.index({ companyId: 1, category: 1 });
recommendationSchema.index({ companyId: 1, type: 1 }); // Index for internal/external filtering
recommendationSchema.index({ createdAt: -1 });
recommendationSchema.index({ expiresAt: 1 });

// 📊 Static Methods
recommendationSchema.statics.getByCompany = function(companyId, filters = {}) {
  const query = { companyId };
  
  if (filters.status) {
    query.status = filters.status;
  }
  
  if (filters.priority) {
    query.priority = filters.priority;
  }
  
  if (filters.category) {
    query.category = filters.category;
  }
  
  return this.find(query)
    .sort({ priority: 1, createdAt: -1 })
    .lean();
};

recommendationSchema.statics.getStats = async function(companyId) {
  const stats = await this.aggregate([
    { $match: { companyId } },
    {
      $group: {
        _id: '$status',
        count: { $sum: 1 }
      }
    }
  ]);
  
  const priorityStats = await this.aggregate([
    { $match: { companyId, status: 'new' } },
    {
      $group: {
        _id: '$priority',
        count: { $sum: 1 }
      }
    }
  ]);
  
  return {
    byStatus: stats.reduce((acc, stat) => {
      acc[stat._id] = stat.count;
      return acc;
    }, {}),
    byPriority: priorityStats.reduce((acc, stat) => {
      acc[stat._id] = stat.count;
      return acc;
    }, {})
  };
};

// 📝 Instance Methods
recommendationSchema.methods.markAsViewed = function() {
  this.status = 'viewed';
  this.viewedAt = new Date();
  return this.save();
};

recommendationSchema.methods.markAsImplemented = function() {
  this.status = 'implemented';
  this.implementedAt = new Date();
  return this.save();
};

recommendationSchema.methods.markAsDismissed = function() {
  this.status = 'dismissed';
  this.dismissedAt = new Date();
  return this.save();
};



// آخر سطر - شوفي إذا موجود variable اسمها Recommendation:
const Recommendation = mongoose.models.Recommendation || mongoose.model('Recommendation', recommendationSchema);
module.exports = Recommendation;