const mongoose = require("mongoose");

const TopCompaniesSnapshotSchema = new mongoose.Schema(
  {
    // 🔗 Link to company (public id like CMP_007)
    companyId: {
      type: String,
      required: true,
      index: true,
    },

    // Optional Mongo reference (if needed later)
    companyDbId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Company",
    },

    // 🏷️ Context (to verify data relevance)
    country: {
      type: String,
      required: true,
      lowercase: true,
      trim: true,
    },

    industry: {
      type: String,
      required: true,
      lowercase: true,
      trim: true,
    },

    // 🏢 Top/Competitor companies data
    companies: [
      {
        // Company name
        name: {
          type: String,
          required: true,
          trim: true,
        },

        // Company description
        description: {
          type: String,
          default: "",
        },

        // Company website
        website: {
          type: String,
          default: "",
        },

        // Company country
        country: {
          type: String,
          lowercase: true,
          trim: true,
        },

        // Market metrics
        marketCap: {
          type: Number, // in millions USD
          default: 0,
        },

        revenue: {
          type: Number, // in millions USD
          default: 0,
        },

        employees: {
          type: Number,
          default: 0,
        },

        // Company rank/position
        rank: {
          type: Number,
          default: 0,
        },

        // Additional metadata
        stockSymbol: {
          type: String,
          uppercase: true,
          default: "",
        },

        founded: {
          type: String, // Year as string (e.g., "1994")
          default: "",
        },

        // Tags for filtering
        tags: [
          {
            type: String,
            lowercase: true,
          },
        ],

        // Source URL (where we got this info)
        sourceUrl: {
          type: String,
          default: "",
        },
      },
    ],

    // 🌐 Data provider info
    provider: {
      type: String,
      default: "manual",
      // Examples: "companies-api", "manual", "web-scraping"
    },

    // 🕒 Timestamps
    fetchedAt: {
      type: Date,
      default: Date.now,
      // When we fetched this data
    },

    // 🛑 Prevent duplicates (optional)
    dedupeKey: {
      type: String,
      unique: true,
      sparse: true,
      // Format: "CMP_007_finance_lb_2024-01" (companyId + industry + country + month)
    },
  },
  {
    timestamps: true, // Adds createdAt and updatedAt
  }
);

// Indexes for performance
TopCompaniesSnapshotSchema.index({ companyId: 1, fetchedAt: -1 });
TopCompaniesSnapshotSchema.index({ industry: 1, country: 1 });

// Pre-save hook to generate dedupeKey
TopCompaniesSnapshotSchema.pre("save", function () {
  if (this.isNew && !this.dedupeKey) {
    const date = new Date();
    const yearMonth = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
    this.dedupeKey = `${this.companyId}_${this.industry}_${this.country}_${yearMonth}`;
  }
});

// آخر سطر:
module.exports = mongoose.models.TopCompaniesSnapshot || mongoose.model("TopCompaniesSnapshot", TopCompaniesSnapshotSchema);