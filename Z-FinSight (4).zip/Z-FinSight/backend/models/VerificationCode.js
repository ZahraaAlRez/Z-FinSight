const mongoose = require("mongoose");

const verificationCodeSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    lowercase: true,
    trim: true,
  },
  code: {
    type: String,
    required: true,
    // Random 6-digit code (e.g., "123456")
  },
  expiresAt: {
    type: Date,
    required: true,
    // Expires 10 minutes after creation
    default: () => new Date(Date.now() + 10 * 60 * 1000),
  },
  attempts: {
    type: Number,
    default: 0,
    // Track failed verification attempts (optional security feature)
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

// TTL index - MongoDB automatically deletes expired codes
verificationCodeSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

// آخر سطر:
module.exports = mongoose.models.VerificationCode || mongoose.model("VerificationCode", verificationCodeSchema);