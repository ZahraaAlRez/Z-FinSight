const mongoose = require("mongoose");

const TransactionSchema = new mongoose.Schema(
  {
    companyId: { type: String, required: true, index: true },

    // core
    date: { type: Date, required: true, index: true },
    type: { type: String, enum: ["income", "expense"], required: true },
    amount: { type: Number, required: true },
    currency: { type: String, default: "USD" },

    category: { type: String, default: "Uncategorized", index: true },
    description: { type: String, default: "" },
    counterparty: { type: String, default: "" }, // customer/supplier name
    method: { type: String, enum: ["cash", "bank", "card", "other"], default: "bank" },

    // accounting workflow
    status: { type: String, enum: ["draft", "posted"], default: "posted", index: true },

    // reconciliation
    reconciled: { type: Boolean, default: false, index: true },
    reconciledAt: { type: Date, default: null },
    bankLineId: { type: mongoose.Schema.Types.ObjectId, ref: "BankLine", default: null },

    // optional attachments: store uploaded file urls/ids
    attachments: [{ type: String }],
    createdBy: { type: String, default: "" }, // username or userId
  },
  { timestamps: true }
);

module.exports = mongoose.model("Transaction", TransactionSchema);