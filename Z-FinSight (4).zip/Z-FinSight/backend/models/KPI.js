const mongoose = require("mongoose");

const KPISchema = new mongoose.Schema({
  companyId: { type: String, index: true, required: true },
  period: { type: String, index: true, required: true }, // YYYY-MM

  currency: { type: String, default: "USD" },

  revenue: { type: Number, default: 0 },
  cogs: { type: Number, default: 0 },
  opex: { type: Number, default: 0 },
  taxes: { type: Number, default: 0 },

  grossProfit: { type: Number, default: 0 },
  afterTaxProfit: { type: Number, default: 0 },

  grossMargin: { type: Number, default: 0 }, // 0..1
  netMargin: { type: Number, default: 0 },   // 0..1
  taxBurden: { type: Number, default: 0 },   // 0..1
  liquidity: { type: Number, default: null } // ratio

}, { timestamps: true });

module.exports = mongoose.model("KPI", KPISchema);
