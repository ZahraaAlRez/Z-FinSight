const mongoose = require("mongoose");

const BankLineSchema = new mongoose.Schema({
  companyId: { type: String, index: true, required: true },
  uploadId: { type: mongoose.Schema.Types.ObjectId, ref: "Upload" },

  date: { type: Date, index: true, required: true },
  description: { type: String, default: "" },
  amount: { type: Number, required: true }, // positive
  direction: { type: String, required: true }, // in|out
  currency: { type: String, default: "USD" },

  matched: { type: Boolean, default: false },
  matchedTransactionId: { type: mongoose.Schema.Types.ObjectId, ref: "Transaction" }
}, { timestamps: true });

module.exports = mongoose.model("BankLine", BankLineSchema);
