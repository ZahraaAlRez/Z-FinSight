const mongoose = require("mongoose");

const TransactionLineSchema = new mongoose.Schema(
  {
    transaction_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Transaction",
      required: true,
      index: true,
    },

    account_id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Account",
      required: true,
      index: true,
    },

    debit_amount: {
      type: Number,
      default: 0,
      min: 0,
    },

    credit_amount: {
      type: Number,
      default: 0,
      min: 0,
    },

    description: {
      type: String,
      default: "",
      trim: true,
    },
  },
  { timestamps: true }
);

// Compound indexes for efficient queries
TransactionLineSchema.index({ transaction_id: 1, account_id: 1 });
TransactionLineSchema.index({ account_id: 1 });

module.exports = mongoose.model("TransactionLine", TransactionLineSchema);
