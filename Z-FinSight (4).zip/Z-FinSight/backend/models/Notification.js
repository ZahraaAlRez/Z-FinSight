// backend/models/Notification.js
const mongoose = require("mongoose");

const NotificationSchema = new mongoose.Schema(
  {
    companyId: { 
      type: String, 
      required: true, 
      index: true 
    },
    
    // Who should see this notification
    userId: { 
      type: mongoose.Schema.Types.ObjectId, 
      ref: "User",
      default: null // null = all users in company
    },
    
    // Notification content
    type: { 
      type: String, 
      enum: [
        "info",           // General information
        "warning",        // Warnings (e.g., overdue invoice)
        "error",          // Errors/critical
        "success",        // Success messages
        "task",           // To-do tasks
        "recommendation"  // System recommendations
      ],
      default: "info" 
    },
    
    title: { 
      type: String, 
      required: true,
      maxlength: 200 
    },
    
    message: { 
      type: String, 
      required: true,
      maxlength: 1000 
    },
    
    // Link/action
    link: { 
      type: String, 
      default: null  // e.g., "/reports", "/transactions/123"
    },
    
    // Status
    read: { 
      type: Boolean, 
      default: false,
      index: true 
    },
    
    readAt: { 
      type: Date, 
      default: null 
    },
    
    // Priority
    priority: { 
      type: String, 
      enum: ["low", "medium", "high", "urgent"],
      default: "medium" 
    },
    
    // Auto-generated or manual
    source: {
      type: String,
      enum: ["system", "manual", "scheduler"],
      default: "system"
    },
    
    // Related data
    relatedModel: {
      type: String,
      default: null  // e.g., "Transaction", "Invoice"
    },
    
    relatedId: {
      type: mongoose.Schema.Types.ObjectId,
      default: null
    },
    
    // Expiry (for auto-cleanup)
    expiresAt: {
      type: Date,
      default: null
    },
    
    createdBy: { 
      type: String, 
      default: "system" 
    }
  },
  { timestamps: true }
);

// Indexes for performance
NotificationSchema.index({ companyId: 1, read: 1, createdAt: -1 });
NotificationSchema.index({ companyId: 1, userId: 1, read: 1 });
NotificationSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 }); // Auto-delete expired

// Virtual: Is this notification urgent?
NotificationSchema.virtual("isUrgent").get(function() {
  return this.priority === "urgent" || this.priority === "high";
});

// Method: Mark as read
NotificationSchema.methods.markAsRead = async function() {
  this.read = true;
  this.readAt = new Date();
  return await this.save();
};

// Static: Get unread count for company
NotificationSchema.statics.getUnreadCount = async function(companyId, userId = null) {
  const query = { companyId, read: false };
  if (userId) {
    // User-specific or company-wide notifications
    query.$or = [{ userId }, { userId: null }];
  }
  return await this.countDocuments(query);
};

// Static: Create system notification
NotificationSchema.statics.createSystemNotification = async function(data) {
  return await this.create({
    companyId: data.companyId,
    userId: data.userId || null,
    type: data.type || "info",
    title: data.title,
    message: data.message,
    link: data.link || null,
    priority: data.priority || "medium",
    source: "system",
    relatedModel: data.relatedModel || null,
    relatedId: data.relatedId || null,
    expiresAt: data.expiresAt || null
  });
};

module.exports = mongoose.model("Notification", NotificationSchema);