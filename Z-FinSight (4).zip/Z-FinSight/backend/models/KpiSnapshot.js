// backend/models/KpiSnapshot.js
const mongoose = require("mongoose");

const KpiSnapshotSchema = new mongoose.Schema(
  {
    companyId: { type: String, required: true },
    // Indexed via compound index below: { companyId: 1, createdAt: -1 }
    period: { type: String, default: "" }, // optional (e.g., "2026-01")

    revenue: { type: Number, default: 0 },
    cogs: { type: Number, default: 0 },
    operating_expenses: { type: Number, default: 0 },
    opex: { type: Number, default: 0 }, // Legacy field, same as operating_expenses
    interest_expense: { type: Number, default: 0 },
    taxes: { type: Number, default: 0 },
    income_tax: { type: Number, default: 0 }, // More specific name

    grossProfit: { type: Number, default: 0 },
    operating_profit: { type: Number, default: 0 }, // EBIT
    profit_before_tax: { type: Number, default: 0 }, // PBT/EBT
    afterTaxProfit: { type: Number, default: 0 }, // PAT/Net Income
    net_profit_after_tax: { type: Number, default: 0 }, // More specific name

    grossMargin: { type: Number, default: 0 },
    operating_margin: { type: Number, default: 0 },
    netMargin: { type: Number, default: 0 },
    net_profit_margin: { type: Number, default: 0 }, // More specific name
    taxBurden: { type: Number, default: 0 },
    
    // Balance Sheet metrics
    current_assets: { type: Number, default: 0 },
    current_liabilities: { type: Number, default: 0 },
    current_ratio: { type: Number, default: null },
    liquidity: { type: Number, default: null }, // Legacy field, same as current_ratio

    createdBy: { type: String, default: "" },
    is_current: { type: Boolean, default: true },
  },
  { timestamps: true }
);

KpiSnapshotSchema.index({ companyId: 1, createdAt: -1 });

module.exports = mongoose.model("KpiSnapshot", KpiSnapshotSchema);
