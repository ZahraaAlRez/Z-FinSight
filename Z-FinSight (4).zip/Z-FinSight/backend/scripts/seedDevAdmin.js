// scripts/seedDevAdmin.js
require("dotenv").config();
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

const Company = require("../models/Company");
const Admin = require("../models/Admin");

async function run() {
  const MONGO_URI = process.env.MONGO_URI || process.env.MONGODB_URI;
  if (!MONGO_URI) {
    console.log("❌ Missing MONGO_URI (or MONGODB_URI) in .env");
    process.exit(1);
  }

  await mongoose.connect(MONGO_URI);
  console.log("✅ Connected to MongoDB");

  // === Dev Company ===
  const companyId = "DEV001";

  const companyData = {
    companyId,
    companyName: "Z-FinSight Demo Company",
    companyEmail: "company@demo.com", // ✅ correct field name
    country: "lebanon",
    industry: "finance",
    currencies: ["USD", "LBP"],
    language: "en",
    isVerified: true,
    isActive: true,
  };

  const company = await Company.findOneAndUpdate(
    { companyId },
    { $set: companyData },
    { upsert: true, new: true, setDefaultsOnInsert: true }
  );

  console.log("✅ Company ready:", company.companyId, company.companyName);

  // === Dev Admin ===
  const adminEmail = "admin@example.com";
  const adminPassword = "Admin123!";

  const passwordHash = await bcrypt.hash(adminPassword, 10);

  const adminData = {
    companyId: company._id, // ✅ IMPORTANT: ObjectId not "DEV001"
    fullName: "Dev Admin",
    username: "admin",
    email: adminEmail,
    passwordHash,
    isVerified: true,
    isActive: true,
    roles: ["admin"],
  };

  const admin = await Admin.findOneAndUpdate(
    { email: adminEmail },
    { $set: adminData },
    { upsert: true, new: true, setDefaultsOnInsert: true }
  );

  console.log("✅ Admin ready:", admin.email, " / password:", adminPassword);
  console.log("✅ Use this for login: identifier =", adminEmail);

  await mongoose.disconnect();
  console.log("✅ Done");
}

run().catch(async (err) => {
  console.error("❌ Seed failed:", err);
  try {
    await mongoose.disconnect();
  } catch (_) {}
  process.exit(1);
});
