# Seed Sample Data - Quick Guide

## Quick Start

### 1. Add Sample Data to Your Company

```bash
# For default company (CMP_001)
npm run seed:sample

# Or for a specific company
node scripts/seedSampleData.js CMP_001
```

### 2. What Gets Created

The script creates:
- **30+ Chart of Accounts** (Revenue, COGS, Expenses, Assets, Liabilities, Equity)
- **13 Sample Transactions** (Revenue: $100k, COGS: $40k, Expenses: $36k, Interest: $2k, Tax: $5.6k)
- **3 Sample Invoices** (some overdue, some current)
- **3 Sample Bills** (some due soon, some overdue)
- **2 Bank Accounts** (checking and savings)

### 3. Expected Results

After seeding, you can:
- **Calculate KPIs** from the transaction data
- **View Reports** (P&L, Balance Sheet, AR/AP Aging)
- **See Dashboard Metrics** (overdue invoices, bills due, etc.)

### 4. Publish KPIs

1. Go to **Accountant Dashboard**
2. Scroll to **Profitability Calculator**
3. Enter values:
   - Revenue: `100000`
   - COGS: `40000`
   - Operating Expenses: `36000`
   - Interest Expense: `2000`
   - Taxes: `5600`
4. Click **"Publish KPIs"**
5. Check **Admin Dashboard** to see published KPIs

## Expected KPI Results

With the seeded data, you should see:
- **Revenue:** $100,000
- **COGS:** $40,000
- **Gross Profit:** $60,000 (60% margin)
- **Operating Expenses:** $36,000
- **Operating Profit:** $24,000 (24% margin)
- **Interest Expense:** $2,000
- **Profit Before Tax:** $22,000
- **Income Tax:** $5,600
- **Net Profit After Tax:** $16,400 (16.4% margin)
- **Tax Burden:** 25.45%

## Notes

- The script uses **upsert** (update or insert), so running it multiple times is safe
- It won't duplicate data if accounts/invoices already exist
- All dates are set to January 2026 for consistency
- Transactions are marked as `posted` and ready for calculations

## Troubleshooting

**Error: Company not found**
- Make sure the company exists in the database
- Check the companyId (should be like "CMP_001")

**Error: MongoDB connection failed**
- Check your `.env` file has `MONGO_URI` set
- Make sure MongoDB is running

**Data not showing in dashboard**
- Refresh the page
- Check that you're logged in with the correct company
- Verify the companyId matches
