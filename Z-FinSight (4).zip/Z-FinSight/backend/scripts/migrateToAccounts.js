/**
 * Migration Script: Populate Account and TransactionLine from existing Transactions
 * 
 * This script:
 * 1. Creates Account records from existing Transaction categories
 * 2. Creates TransactionLine records for existing Transactions
 * 3. Migrates invoice/bill data from Transaction records to Invoice/Bill models
 * 4. Calculates initial account balances
 * 
 * Run with: node backend/scripts/migrateToAccounts.js
 */

const mongoose = require("mongoose");
require("dotenv").config({ path: require("path").join(__dirname, "../.env") });

const Transaction = require("../models/Transaction");
const Account = require("../models/Account");
const TransactionLine = require("../models/TransactionLine");
const Invoice = require("../models/Invoice");
const Bill = require("../models/Bill");

// Map transaction types to account types
function getAccountTypeFromTransaction(tx) {
  if (tx.type === "income") return "revenue";
  if (tx.type === "expense") {
    const cat = (tx.category || "").toLowerCase();
    if (cat.includes("cogs") || cat.includes("cost_of_goods") || cat.includes("inventory")) {
      return "cogs";
    }
    return "expense";
  }
  return "expense"; // default
}

// Determine if account is cash/bank
function isCashOrBankAccount(category, method) {
  const cat = (category || "").toLowerCase();
  const meth = (method || "").toLowerCase();
  return (
    cat.includes("cash") ||
    cat.includes("bank") ||
    meth === "cash" ||
    meth === "bank"
  );
}

async function migrateAccounts() {
  try {
    console.log("🔄 Starting migration to Accounts system...");

    // Connect to MongoDB
    await mongoose.connect(process.env.MONGO_URI);
    console.log("✅ Connected to MongoDB");

    // Get all unique company IDs
    const companies = await Transaction.distinct("companyId");
    console.log(`📊 Found ${companies.length} companies to migrate`);

    for (const companyId of companies) {
      console.log(`\n📦 Processing company: ${companyId}`);

      // Get all transactions for this company
      const transactions = await Transaction.find({ companyId }).lean();
      console.log(`   Found ${transactions.length} transactions`);

      // Step 1: Create Account records from categories
      const accountMap = new Map(); // category -> account_id

      for (const tx of transactions) {
        const category = tx.category || "Uncategorized";
        const accountType = getAccountTypeFromTransaction(tx);

        if (!accountMap.has(category)) {
          // Check if account already exists
          let account = await Account.findOne({
            companyId,
            account_name: category,
            account_type: accountType,
          });

          if (!account) {
            // Create new account
            account = await Account.create({
              companyId,
              account_name: category,
              account_type: accountType,
              is_cash_account: isCashOrBankAccount(category, tx.method) && tx.method === "cash",
              is_bank_account: isCashOrBankAccount(category, tx.method) && tx.method === "bank",
              current_balance: 0,
              is_active: true,
            });
            console.log(`   ✅ Created account: ${category} (${accountType})`);
          }

          accountMap.set(category, account._id);
        }
      }

      // Step 2: Create TransactionLine records and update account balances
      let transactionLineCount = 0;

      for (const tx of transactions) {
        const category = tx.category || "Uncategorized";
        const accountId = accountMap.get(category);

        if (!accountId) {
          console.warn(`   ⚠️  No account found for category: ${category}`);
          continue;
        }

        // Determine debit/credit based on account type and transaction type
        let debitAmount = 0;
        let creditAmount = 0;

        const account = await Account.findById(accountId).lean();
        if (!account) continue;

        if (account.account_type === "asset" || account.account_type === "expense" || account.account_type === "cogs") {
          // Assets and expenses: debit increases, credit decreases
          if (tx.type === "expense") {
            debitAmount = Number(tx.amount || 0);
          } else {
            creditAmount = Number(tx.amount || 0);
          }
        } else if (account.account_type === "liability" || account.account_type === "equity" || account.account_type === "revenue") {
          // Liabilities, equity, revenue: credit increases, debit decreases
          if (tx.type === "income") {
            creditAmount = Number(tx.amount || 0);
          } else {
            debitAmount = Number(tx.amount || 0);
          }
        }

        // Create TransactionLine
        const existingLine = await TransactionLine.findOne({
          transaction_id: tx._id,
          account_id: accountId,
        });

        if (!existingLine) {
          await TransactionLine.create({
            transaction_id: tx._id,
            account_id: accountId,
            debit_amount: debitAmount,
            credit_amount: creditAmount,
            description: tx.description || "",
          });
          transactionLineCount++;

          // Update account balance
          const balanceChange = debitAmount - creditAmount;
          await Account.updateOne(
            { _id: accountId },
            { $inc: { current_balance: balanceChange } }
          );
        }
      }

      console.log(`   ✅ Created ${transactionLineCount} transaction lines`);

      // Step 3: Migrate invoices/bills
      let invoiceCount = 0;
      let billCount = 0;

      for (const tx of transactions) {
        // Check if transaction is an invoice (income with due date or invoice-like description)
        if (
          tx.type === "income" &&
          (tx.dueDate || tx.description?.toLowerCase().includes("invoice"))
        ) {
          const existingInvoice = await Invoice.findOne({
            companyId,
            invoice_number: tx.description || `INV-${tx._id}`,
          });

          if (!existingInvoice) {
            await Invoice.create({
              companyId,
              invoice_number: tx.description || `INV-${tx._id}`,
              invoice_type: "sales",
              invoice_date: tx.date,
              due_date: tx.dueDate || tx.date,
              total_amount: Number(tx.amount || 0),
              balance_due: tx.status === "paid" ? 0 : Number(tx.amount || 0),
              status: tx.status === "paid" ? "paid" : "unpaid",
              is_posted: tx.status === "posted",
              description: tx.description || "",
            });
            invoiceCount++;
          }
        }

        // Check if transaction is a bill (expense with due date or bill-like description)
        if (
          tx.type === "expense" &&
          (tx.dueDate || tx.description?.toLowerCase().includes("bill"))
        ) {
          const existingBill = await Bill.findOne({
            companyId,
            bill_number: tx.description || `BILL-${tx._id}`,
          });

          if (!existingBill) {
            await Bill.create({
              companyId,
              bill_number: tx.description || `BILL-${tx._id}`,
              bill_type: "purchase",
              bill_date: tx.date,
              due_date: tx.dueDate || tx.date,
              total_amount: Number(tx.amount || 0),
              balance_due: tx.status === "paid" ? 0 : Number(tx.amount || 0),
              status: tx.status === "paid" ? "paid" : "unpaid",
              is_posted: tx.status === "posted",
              description: tx.description || "",
            });
            billCount++;
          }
        }
      }

      console.log(`   ✅ Created ${invoiceCount} invoices and ${billCount} bills`);
    }

    console.log("\n✅ Migration completed successfully!");
    console.log("\n📝 Summary:");
    console.log(`   - Companies processed: ${companies.length}`);
    console.log(`   - Accounts created: ${await Account.countDocuments()}`);
    console.log(`   - Transaction lines created: ${await TransactionLine.countDocuments()}`);
    console.log(`   - Invoices created: ${await Invoice.countDocuments()}`);
    console.log(`   - Bills created: ${await Bill.countDocuments()}`);

    process.exit(0);
  } catch (error) {
    console.error("❌ Migration error:", error);
    process.exit(1);
  }
}

// Run migration if called directly
if (require.main === module) {
  migrateAccounts();
}

module.exports = { migrateAccounts };
