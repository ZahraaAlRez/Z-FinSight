/**
 * DEV-ONLY Database Reset Script
 * 
 * ⚠️  WARNING: This script permanently deletes ALL data from the database!
 * 
 * This script is SAFE for development only:
 * - Only works when NODE_ENV !== "production"
 * - Deletes all documents from all collections
 * - Resets the system so the next company will be CMP_001
 * 
 * Usage:
 *   node backend/scripts/devReset.js
 *   or
 *   npm run dev:reset (if added to package.json)
 * 
 * Collections cleared:
 * - companies
 * - admins  
 * - users
 * - verificationcodes
 * - recommendations
 * - newsitems
 * - topcompaniessnapshots
 * - fxratesnapshots
 */

require('dotenv').config();
const mongoose = require('mongoose');

// Import all models to ensure they're registered and indexes are created
const Company = require('../models/Company');
const Admin = require('../models/Admin');
const User = require('../models/User');
const VerificationCode = require('../models/VerificationCode');
const Recommendation = require('../models/Recommendation');
const NewsItem = require('../models/NewsItem');
const TopCompaniesSnapshot = require('../models/TopCompaniesSnapshot');
const FxRateSnapshot = require('../models/FxRateSnapshot');

// Collections to reset (using lowercase plural names as MongoDB stores them)
const COLLECTIONS_TO_RESET = [
  'companies',
  'admins',
  'users',
  'verificationcodes',
  'recommendations',
  'newsitems',
  'topcompaniessnapshots',
  'fxratesnapshots',
];

async function devReset() {
  try {
    // ⚠️  SAFETY CHECK: Only allow in development
    if (process.env.NODE_ENV === 'production') {
      console.error('❌ ERROR: This reset script is BLOCKED in production mode!');
      console.error('   Set NODE_ENV=development to use this script.');
      process.exit(1);
    }

    console.log('🔄 Z-FinSight DEV Reset Script');
    console.log('   Environment:', process.env.NODE_ENV || 'development');
    console.log('   Mode: DEVELOPMENT ONLY\n');

    // Check if MONGO_URI is set
    if (!process.env.MONGO_URI) {
      console.error('❌ Error: MONGO_URI is not set in .env file');
      process.exit(1);
    }

    // Mask credentials in log
    const maskedUri = process.env.MONGO_URI.replace(/\/\/.*@/, '//***:***@');
    console.log('📡 Connecting to MongoDB...');
    console.log('   URI:', maskedUri);

    // Connect to MongoDB
    await mongoose.connect(process.env.MONGO_URI);
    console.log('✅ Connected to MongoDB\n');

    // Get database instance
    const db = mongoose.connection.db;
    const dbName = db.databaseName;
    console.log('📊 Database:', dbName);
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

    // Get collection counts before deletion
    console.log('📋 Current collection counts:');
    const beforeCounts = {};
    for (const collectionName of COLLECTIONS_TO_RESET) {
      try {
        const collection = db.collection(collectionName);
        const count = await collection.countDocuments();
        beforeCounts[collectionName] = count;
        if (count > 0) {
          console.log(`   ${collectionName.padEnd(25)} : ${count} documents`);
        }
      } catch (err) {
        beforeCounts[collectionName] = 0;
        // Collection doesn't exist yet, that's fine
      }
    }

    const totalBefore = Object.values(beforeCounts).reduce((sum, count) => sum + (typeof count === 'number' ? count : 0), 0);
    console.log(`   ${'TOTAL'.padEnd(25)} : ${totalBefore} documents\n`);

    if (totalBefore === 0) {
      console.log('✅ Database is already empty. Nothing to reset.');
      await mongoose.connection.close();
      console.log('✅ Connection closed\n');
      process.exit(0);
    }

    // Delete all documents from each collection
    console.log('🗑️  Deleting all documents...\n');
    const results = {};
    let totalDeleted = 0;

    for (const collectionName of COLLECTIONS_TO_RESET) {
      try {
        const collection = db.collection(collectionName);
        const count = beforeCounts[collectionName] || 0;
        
        if (count > 0) {
          const deleteResult = await collection.deleteMany({});
          const deletedCount = deleteResult.deletedCount || 0;
          results[collectionName] = deletedCount;
          totalDeleted += deletedCount;
          console.log(`   ✔ ${collectionName.padEnd(25)} : ${deletedCount} documents deleted`);
        } else {
          results[collectionName] = 0;
          console.log(`   ○ ${collectionName.padEnd(25)} : already empty`);
        }
      } catch (err) {
        results[collectionName] = 'error';
        console.warn(`   ⚠  ${collectionName.padEnd(25)} : error - ${err.message}`);
      }
    }

    console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('✅ RESET COMPLETE!\n');
    console.log(`   Total documents deleted: ${totalDeleted}`);
    console.log('   Collections cleared:');
    
    for (const [collectionName, count] of Object.entries(results)) {
      if (count > 0) {
        console.log(`      ✔ ${collectionName} (${count} documents)`);
      } else if (count === 0) {
        console.log(`      ○ ${collectionName} (already empty)`);
      } else {
        console.log(`      ⚠  ${collectionName} (error occurred)`);
      }
    }

    // Verify all collections are empty
    console.log('\n🔍 Verifying reset...');
    let allEmpty = true;
    for (const collectionName of COLLECTIONS_TO_RESET) {
      try {
        const collection = db.collection(collectionName);
        const count = await collection.countDocuments();
        if (count > 0) {
          console.warn(`   ⚠  ${collectionName} still has ${count} documents`);
          allEmpty = false;
        }
      } catch (err) {
        // Collection doesn't exist, that's fine
      }
    }

    if (allEmpty) {
      console.log('   ✅ All collections are empty\n');
    }

    // Important notes
    console.log('📌 IMPORTANT NOTES:');
    console.log('   • Next company created will have companyId = "CMP_001"');
    console.log('   • All unique indexes (email, username) are cleared');
    console.log('   • You can now register companies and users without conflicts\n');

    // Close connection
    await mongoose.connection.close();
    console.log('✅ Connection closed');
    console.log('✅ System reset completed successfully!\n');

    process.exit(0);
  } catch (err) {
    console.error('\n❌ Reset failed:', err);
    if (mongoose.connection.readyState === 1) {
      await mongoose.connection.close();
    }
    process.exit(1);
  }
}

// Run the reset
devReset();
