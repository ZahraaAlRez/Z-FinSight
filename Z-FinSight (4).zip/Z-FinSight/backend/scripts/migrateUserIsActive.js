require("dotenv").config();
const mongoose = require("mongoose");
const User = require("../models/User");

async function run() {
  await mongoose.connect(process.env.MONGO_URI);
  const res = await User.updateMany(
    { isActive: { $exists: false } },
    { $set: { isActive: true } }
  );

  console.log("✅ Users updated:", res.modifiedCount);
  await mongoose.disconnect();
}

run().catch(async (err) => {
  console.error("❌ Migration failed:", err);
  try { await mongoose.disconnect(); } catch {}
  process.exit(1);
});
