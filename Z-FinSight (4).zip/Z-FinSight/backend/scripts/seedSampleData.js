/**
 * Seed Sample Data Script
 * 
 * This script creates sample accounting data for testing and demonstration:
 * - Chart of Accounts (Revenue, COGS, Expenses, Assets, Liabilities, Equity)
 * - Sample Transactions (Income and Expenses)
 * - Sample Invoices (some overdue, some current)
 * - Sample Bills (some due soon, some overdue)
 * - Bank Accounts
 * 
 * Usage:
 *   node backend/scripts/seedSampleData.js [companyId]
 * 
 * Example:
 *   node backend/scripts/seedSampleData.js CMP_001
 */

require("dotenv").config();
const mongoose = require("mongoose");

const Company = require("../models/Company");
const Account = require("../models/Account");
const Transaction = require("../models/Transaction");
const TransactionLine = require("../models/TransactionLine");
const Invoice = require("../models/Invoice");
const Bill = require("../models/Bill");
const BankAccount = require("../models/BankAccount");

async function seedSampleData(companyPublicId = "CMP_001") {
  try {
    console.log("🔌 Connecting to MongoDB...");
    await mongoose.connect(process.env.MONGO_URI);
    console.log("✅ Connected to MongoDB\n");

    // Find company
    const company = await Company.findOne({ companyId: companyPublicId });
    if (!company) {
      console.error(`❌ Company ${companyPublicId} not found. Please create the company first.`);
      process.exit(1);
    }

    const companyId = companyPublicId; // Use public ID for all models

    console.log(`📊 Seeding data for company: ${company.companyName} (${companyId})\n`);

    // ============================================
    // 1. CREATE CHART OF ACCOUNTS
    // ============================================
    console.log("📋 Creating Chart of Accounts...");

    const accounts = [
      // REVENUE ACCOUNTS
      { account_name: "Sales Revenue", account_type: "revenue", current_balance: 0 },
      { account_name: "Service Revenue", account_type: "revenue", current_balance: 0 },
      
      // COGS ACCOUNTS
      { account_name: "Cost of Goods Sold", account_type: "cogs", current_balance: 0 },
      { account_name: "Direct Materials", account_type: "cogs", current_balance: 0 },
      { account_name: "Direct Labor", account_type: "cogs", current_balance: 0 },
      
      // OPERATING EXPENSE ACCOUNTS
      { account_name: "Salaries & Wages", account_type: "expense", expense_category: "general", current_balance: 0 },
      { account_name: "Rent Expense", account_type: "expense", expense_category: "general", current_balance: 0 },
      { account_name: "Utilities", account_type: "expense", expense_category: "general", current_balance: 0 },
      { account_name: "Marketing & Advertising", account_type: "expense", expense_category: "marketing", current_balance: 0 },
      { account_name: "Office Supplies", account_type: "expense", expense_category: "general", current_balance: 0 },
      { account_name: "Insurance", account_type: "expense", expense_category: "general", current_balance: 0 },
      { account_name: "Depreciation", account_type: "expense", expense_category: "general", current_balance: 0 },
      
      // INTEREST EXPENSE
      { account_name: "Interest Expense", account_type: "expense", expense_category: "financing", current_balance: 0 },
      
      // TAX EXPENSE
      { account_name: "Income Tax Expense", account_type: "expense", expense_category: "tax", current_balance: 0 },
      
      // CURRENT ASSETS
      { account_name: "Cash", account_type: "asset", account_subtype: "current", is_cash_account: true, current_balance: 15000 },
      { account_name: "Bank - Checking", account_type: "asset", account_subtype: "current", is_bank_account: true, current_balance: 45000 },
      { account_name: "Bank - Savings", account_type: "asset", account_subtype: "current", is_bank_account: true, current_balance: 20000 },
      { account_name: "Accounts Receivable", account_type: "asset", account_subtype: "current", current_balance: 30000 },
      { account_name: "Inventory", account_type: "asset", account_subtype: "current", current_balance: 20000 },
      { account_name: "Prepaid Expenses", account_type: "asset", account_subtype: "current", current_balance: 2000 },
      
      // NON-CURRENT ASSETS
      { account_name: "Property, Plant & Equipment", account_type: "asset", account_subtype: "non_current", current_balance: 80000 },
      { account_name: "Accumulated Depreciation", account_type: "asset", account_subtype: "non_current", current_balance: -20000 },
      { account_name: "Intangible Assets", account_type: "asset", account_subtype: "non_current", current_balance: 10000 },
      
      // CURRENT LIABILITIES
      { account_name: "Accounts Payable", account_type: "liability", account_subtype: "current", current_balance: 25000 },
      { account_name: "Short-term Loans", account_type: "liability", account_subtype: "current", current_balance: 10000 },
      { account_name: "Accrued Expenses", account_type: "liability", account_subtype: "current", current_balance: 5000 },
      { account_name: "Taxes Payable", account_type: "liability", account_subtype: "current", current_balance: 3000 },
      
      // NON-CURRENT LIABILITIES
      { account_name: "Long-term Loans", account_type: "liability", account_subtype: "non_current", current_balance: 40000 },
      
      // EQUITY
      { account_name: "Capital", account_type: "equity", current_balance: 50000 },
      { account_name: "Retained Earnings", account_type: "equity", current_balance: 49000 },
    ];

    const createdAccounts = [];
    for (const acc of accounts) {
      const account = await Account.findOneAndUpdate(
        { companyId, account_name: acc.account_name },
        { 
          $set: { 
            ...acc, 
            companyId,
            is_active: true 
          } 
        },
        { upsert: true, new: true }
      );
      createdAccounts.push(account);
    }

    console.log(`✅ Created ${createdAccounts.length} accounts\n`);

    // ============================================
    // 2. CREATE SAMPLE TRANSACTIONS (January 2026)
    // ============================================
    console.log("💼 Creating sample transactions...");

    const today = new Date();
    const janStart = new Date(2026, 0, 1); // January 1, 2026
    const janEnd = new Date(2026, 0, 31); // January 31, 2026

    // Revenue transactions
    const revenueTransactions = [
      { date: new Date(2026, 0, 5), amount: 50000, description: "Sales to Customer A", category: "Sales" },
      { date: new Date(2026, 0, 12), amount: 30000, description: "Sales to Customer B", category: "Sales" },
      { date: new Date(2026, 0, 20), amount: 20000, description: "Service Revenue", category: "Services" },
    ];

    // COGS transactions
    const cogsTransactions = [
      { date: new Date(2026, 0, 6), amount: 20000, description: "Materials for Customer A order", category: "Direct Materials" },
      { date: new Date(2026, 0, 13), amount: 12000, description: "Materials for Customer B order", category: "Direct Materials" },
      { date: new Date(2026, 0, 7), amount: 8000, description: "Direct Labor", category: "Direct Labor" },
    ];

    // Operating expense transactions
    const expenseTransactions = [
      { date: new Date(2026, 0, 1), amount: 20000, description: "Monthly Salaries", category: "Salaries" },
      { date: new Date(2026, 0, 1), amount: 4000, description: "Office Rent", category: "Rent" },
      { date: new Date(2026, 0, 3), amount: 1000, description: "Utilities", category: "Utilities" },
      { date: new Date(2026, 0, 10), amount: 5000, description: "Marketing Campaign", category: "Marketing" },
      { date: new Date(2026, 0, 15), amount: 500, description: "Office Supplies", category: "Supplies" },
      { date: new Date(2026, 0, 1), amount: 1000, description: "Insurance Premium", category: "Insurance" },
      { date: new Date(2026, 0, 1), amount: 2000, description: "Depreciation", category: "Depreciation" },
    ];

    // Interest expense
    const interestTransaction = {
      date: new Date(2026, 0, 15),
      amount: 2000,
      description: "Loan Interest Payment",
      category: "Interest",
    };

    // Tax expense
    const taxTransaction = {
      date: new Date(2026, 0, 25),
      amount: 5600,
      description: "Income Tax Payment",
      category: "Tax",
    };

    // Create all transactions
    const allTransactions = [
      ...revenueTransactions.map(t => ({ ...t, type: "income" })),
      ...cogsTransactions.map(t => ({ ...t, type: "expense" })),
      ...expenseTransactions.map(t => ({ ...t, type: "expense" })),
      { ...interestTransaction, type: "expense" },
      { ...taxTransaction, type: "expense" },
    ];

    const createdTransactions = [];
    for (const txData of allTransactions) {
      // Transaction model uses String companyId (public code), not ObjectId
      const tx = await Transaction.create({
        companyId: companyId, // Use public companyId string
        date: txData.date,
        type: txData.type,
        amount: txData.amount,
        currency: "USD",
        category: txData.category,
        description: txData.description,
        status: "posted",
        createdBy: "seed-script",
      });
      createdTransactions.push(tx);
    }

    console.log(`✅ Created ${createdTransactions.length} transactions\n`);

    // ============================================
    // 3. CREATE SAMPLE INVOICES (AR)
    // ============================================
    console.log("📄 Creating sample invoices...");

    const invoices = [
      {
        invoice_number: "INV-001",
        invoice_type: "sales",
        invoice_date: new Date(2026, 0, 10),
        due_date: new Date(2026, 0, 25), // 15 days, not overdue yet
        total_amount: 5000,
        balance_due: 5000,
        status: "unpaid",
        is_posted: true,
        description: "Invoice to ABC Corp",
      },
      {
        invoice_number: "INV-002",
        invoice_type: "sales",
        invoice_date: new Date(2025, 11, 15), // December 2025
        due_date: new Date(2026, 0, 15), // Overdue by 12 days
        total_amount: 3000,
        balance_due: 3000,
        status: "unpaid",
        is_posted: true,
        description: "Invoice to XYZ Inc",
      },
      {
        invoice_number: "INV-003",
        invoice_type: "sales",
        invoice_date: new Date(2025, 10, 20), // November 2025
        due_date: new Date(2025, 11, 20), // Overdue by 38 days
        total_amount: 2000,
        balance_due: 2000,
        status: "unpaid",
        is_posted: true,
        description: "Invoice to Smith & Co",
      },
    ];

    const createdInvoices = [];
    for (const inv of invoices) {
      const invoice = await Invoice.create({
        companyId,
        ...inv,
      });
      createdInvoices.push(invoice);
    }

    console.log(`✅ Created ${createdInvoices.length} invoices\n`);

    // ============================================
    // 4. CREATE SAMPLE BILLS (AP)
    // ============================================
    console.log("🧾 Creating sample bills...");

    const bills = [
      {
        bill_number: "BILL-001",
        bill_type: "purchase",
        bill_date: new Date(2026, 0, 5),
        due_date: new Date(2026, 1, 5), // Due in 9 days (Feb 5)
        total_amount: 2500,
        balance_due: 2500,
        status: "unpaid",
        is_posted: true,
        description: "Bill from Supplier A",
      },
      {
        bill_number: "BILL-002",
        bill_type: "purchase",
        bill_date: new Date(2025, 11, 20), // December 2025
        due_date: new Date(2026, 0, 20), // Overdue by 7 days
        total_amount: 1500,
        balance_due: 1500,
        status: "unpaid",
        is_posted: true,
        description: "Bill from Supplier B",
      },
      {
        bill_number: "BILL-003",
        bill_type: "purchase",
        bill_date: new Date(2025, 10, 15), // November 2025
        due_date: new Date(2025, 11, 15), // Overdue by 43 days
        total_amount: 1000,
        balance_due: 1000,
        status: "unpaid",
        is_posted: true,
        description: "Bill from Supplier C",
      },
    ];

    const createdBills = [];
    for (const bill of bills) {
      const createdBill = await Bill.create({
        companyId,
        ...bill,
      });
      createdBills.push(createdBill);
    }

    console.log(`✅ Created ${createdBills.length} bills\n`);

    // ============================================
    // 5. CREATE BANK ACCOUNTS
    // ============================================
    console.log("🏦 Creating bank accounts...");

    const bankAccounts = [
      {
        account_name: "Main Checking Account",
        account_type: "checking",
        current_balance: 45000,
        is_active: true,
        last_reconciled_date: new Date(2025, 11, 31), // Last reconciled Dec 31, 2025
        account_number: "CHK-001",
        bank_name: "Bank of Lebanon",
      },
      {
        account_name: "Savings Account",
        account_type: "savings",
        current_balance: 20000,
        is_active: true,
        last_reconciled_date: null, // Never reconciled
        account_number: "SAV-001",
        bank_name: "Bank of Lebanon",
      },
    ];

    const createdBankAccounts = [];
    for (const bank of bankAccounts) {
      const bankAccount = await BankAccount.findOneAndUpdate(
        { companyId, account_name: bank.account_name },
        { $set: { companyId, ...bank } },
        { upsert: true, new: true }
      );
      createdBankAccounts.push(bankAccount);
    }

    console.log(`✅ Created ${createdBankAccounts.length} bank accounts\n`);

    // ============================================
    // SUMMARY
    // ============================================
    console.log("═══════════════════════════════════════════════════════");
    console.log("✅ SEED DATA SUMMARY");
    console.log("═══════════════════════════════════════════════════════");
    console.log(`Company: ${company.companyName} (${companyId})`);
    console.log(`Accounts: ${createdAccounts.length}`);
    console.log(`Transactions: ${createdTransactions.length}`);
    console.log(`Invoices: ${createdInvoices.length} (some overdue)`);
    console.log(`Bills: ${createdBills.length} (some due soon, some overdue)`);
    console.log(`Bank Accounts: ${createdBankAccounts.length}`);
    console.log("\n📊 Expected KPIs (if calculated):");
    console.log("   Revenue: $100,000");
    console.log("   COGS: $40,000");
    console.log("   Gross Profit: $60,000 (60% margin)");
    console.log("   Operating Expenses: $36,000");
    console.log("   Operating Profit: $24,000 (24% margin)");
    console.log("   Interest Expense: $2,000");
    console.log("   Profit Before Tax: $22,000");
    console.log("   Income Tax: $5,600");
    console.log("   Net Profit After Tax: $16,400 (16.4% margin)");
    console.log("   Tax Burden: 25.45%");
    console.log("\n💡 Next Steps:");
    console.log("   1. Go to Accountant Dashboard");
    console.log("   2. Use the Profitability Calculator");
    console.log("   3. Enter: Revenue=100000, COGS=40000, Operating Expenses=36000, Interest=2000, Taxes=5600");
    console.log("   4. Click 'Publish KPIs'");
    console.log("   5. Check Admin Dashboard to see published KPIs");
    console.log("═══════════════════════════════════════════════════════\n");

    await mongoose.disconnect();
    console.log("✅ Done! Disconnected from MongoDB");
    process.exit(0);
  } catch (err) {
    console.error("❌ Seed failed:", err);
    await mongoose.disconnect();
    process.exit(1);
  }
}

// Get companyId from command line or use default
const companyId = process.argv[2] || "CMP_001";
seedSampleData(companyId);
