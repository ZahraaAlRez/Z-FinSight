const express = require("express");
const cors = require("cors");
const morgan = require("morgan");

const health = require("../routes/health");
const transactions = require("../routes/transactions");
const uploads = require("../routes/uploads");
const accountant = require("../routes/accountant");
const kpis = require("../routes/kpis");
const reports = require("../routes/reports");
const reconciliation = require("../routes/reconciliation");
const recommendations = require("../routes/recommendations");
const users = require("../routes/users");
const news = require("../routes/news");
const topCompanies = require("../routes/topCompanies");
const companies = require("../routes/companies");

function createApp() {
  const app = express();

  app.use(cors({
    origin: process.env.CORS_ORIGIN || "*",
    credentials: true
  }));
  app.use(express.json({ limit: "10mb" }));
  app.use(express.urlencoded({ extended: true }));
  app.use(morgan("dev"));

  app.use("/api/health", health);
  app.use("/api/transactions", transactions);
  app.use("/api/uploads", uploads);
  app.use("/api/accountant", accountant);
  app.use("/api/kpis", kpis);
  app.use("/api/reports", reports);
  app.use("/api/reconciliation", reconciliation);
  app.use("/api/recommendations", recommendations);
  app.use("/api/users", users);
  app.use("/api/news", news);
  app.use("/api/top-companies", topCompanies);
  app.use("/api/companies", companies);

  // 404
  app.use((req, res) => res.status(404).json({ success: false, message: "Resource not found" }));

  return app;
}

module.exports = { createApp };