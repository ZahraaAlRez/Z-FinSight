require('dotenv').config();
const mongoose = require('mongoose');
const NewsItem = require('./models/NewsItem');
const TopCompaniesSnapshot = require('./models/TopCompaniesSnapshot');
const FxRateSnapshot = require('./models/FxRateSnapshot');

async function insertTestData() {
  try {
    console.log('🔌 Connecting to MongoDB...');
    await mongoose.connect(process.env.MONGO_URI);
    console.log('✅ Connected to MongoDB\n');

    // Insert News
    console.log('📰 Inserting News data...');
    await NewsItem.create({
      companyId: "CMP_001",
      title: "Lebanon Central Bank Announces New Monetary Policies",
      summary: "The Central Bank has introduced new policies.",
      url: "https://example.com/news/1",
      source: "Reuters",
      country: "lb",
      industry: "finance",
      sentiment: "neutral",
      publishedAt: new Date("2024-01-15T10:00:00Z"),
      fetchedAt: new Date()
    });
    console.log('✅ News inserted\n');

    // Insert Top Companies
    console.log('🏢 Inserting Top Companies...');
    await TopCompaniesSnapshot.create({
      companyId: "CMP_001",
      country: "lb",
      industry: "finance",
      companies: [
        { name: "Bank Audi", marketCap: 1200, rank: 1 },
        { name: "BLOM Bank", marketCap: 980, rank: 2 }
      ],
      fetchedAt: new Date()
    });
    console.log('✅ Companies inserted\n');

    // Insert FX Rates
    console.log('💱 Inserting FX Rates...');
    await FxRateSnapshot.create({
      companyId: "CMP_001",
      rates: [
        { base: "USD", target: "LBP", rate: 89500, change: 500 },
        { base: "EUR", target: "LBP", rate: 95000, change: -200 }
      ],
      fetchedAt: new Date()
    });
    console.log('✅ FX Rates inserted\n');

    console.log('🎉 All data inserted successfully!');
    process.exit(0);
  } catch (err) {
    console.error('❌ Error:', err);
    process.exit(1);
  }
}

insertTestData();