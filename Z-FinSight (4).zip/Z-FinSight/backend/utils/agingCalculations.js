const Invoice = require("../models/Invoice");
const Bill = require("../models/Bill");
const Transaction = require("../models/Transaction");

/**
 * Calculate days overdue
 */
function calculateDaysOverdue(dueDate) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const due = new Date(dueDate);
  due.setHours(0, 0, 0, 0);
  const diffTime = today - due;
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
}

/**
 * Get aging bucket
 * Buckets: current (not due), 1-30, 31-60, 61-90, 90+
 */
function getAgingBucket(daysOverdue) {
  if (daysOverdue <= 0) return "current";
  if (daysOverdue >= 1 && daysOverdue <= 30) return "1-30";
  if (daysOverdue >= 31 && daysOverdue <= 60) return "31-60";
  if (daysOverdue >= 61 && daysOverdue <= 90) return "61-90";
  return "90+";
}

/**
 * AR Aging Report
 * Query invoices with balance_due > 0 AND status NOT IN ('paid', 'cancelled')
 * Calculate days_overdue = CURRENT_DATE - due_date
 * Bucket: current (not due), 1-30, 31-60, 61-90, 90+
 */
async function getARAgingReport(companyId) {
  try {
    const invoices = await Invoice.find({
      companyId,
      balance_due: { $gt: 0 },
      status: { $nin: ["paid", "cancelled"] },
    })
      .populate("customer_id", "name customer_name")
      .sort({ due_date: 1 })
      .lean();

    const list = invoices.map((inv) => {
      const daysOverdue = calculateDaysOverdue(inv.due_date);
      const bucket = getAgingBucket(daysOverdue);

      return {
        invoice_id: inv._id,
        invoice_number: inv.invoice_number,
        customer_name: inv.customer_id?.name || inv.customer_id?.customer_name || "N/A",
        invoice_date: inv.invoice_date,
        due_date: inv.due_date,
        amount: inv.total_amount,
        balance_due: inv.balance_due,
        days_overdue: daysOverdue,
        aging_bucket: bucket,
      };
    });

    // Calculate summary by bucket
    const summary = {
      current: { count: 0, amount: 0 },
      "1-30": { count: 0, amount: 0 },
      "31-60": { count: 0, amount: 0 },
      "61-90": { count: 0, amount: 0 },
      "90+": { count: 0, amount: 0 },
    };

    list.forEach((inv) => {
      summary[inv.aging_bucket].count++;
      summary[inv.aging_bucket].amount += Number(inv.balance_due || 0);
    });

    const totalAR = Object.values(summary).reduce(
      (sum, bucket) => sum + bucket.amount,
      0
    );

    // Add percentages
    Object.keys(summary).forEach((bucket) => {
      summary[bucket].percentage =
        totalAR > 0 ? (summary[bucket].amount / totalAR) * 100 : 0;
      summary[bucket].amount = Math.round(summary[bucket].amount * 100) / 100;
      summary[bucket].percentage = Math.round(summary[bucket].percentage * 100) / 100;
    });

    return {
      list: list.sort((a, b) => b.days_overdue - a.days_overdue),
      summary,
      total: {
        count: list.length,
        amount: Math.round(totalAR * 100) / 100,
      },
    };
  } catch (error) {
    console.error("Error generating AR aging report:", error);
    // Fallback to Transaction model
    const transactions = await Transaction.find({
      companyId,
      type: "income",
      status: { $ne: "paid" },
    })
      .sort({ date: 1 })
      .lean();

    const list = transactions.map((tx) => {
      const dueDate = tx.dueDate || tx.date;
      const daysOverdue = calculateDaysOverdue(dueDate);
      const bucket = getAgingBucket(daysOverdue);

      return {
        transaction_id: tx._id,
        invoice_number: tx.description || "N/A",
        customer_name: tx.counterparty || "N/A",
        invoice_date: tx.date,
        due_date: dueDate,
        amount: tx.amount,
        balance_due: tx.amount,
        days_overdue: daysOverdue,
        aging_bucket: bucket,
      };
    });

    const summary = {
      current: { count: 0, amount: 0 },
      "1-30": { count: 0, amount: 0 },
      "31-60": { count: 0, amount: 0 },
      "61-90": { count: 0, amount: 0 },
      "90+": { count: 0, amount: 0 },
    };

    list.forEach((tx) => {
      summary[tx.aging_bucket].count++;
      summary[tx.aging_bucket].amount += Number(tx.balance_due || 0);
    });

    const totalAR = Object.values(summary).reduce(
      (sum, bucket) => sum + bucket.amount,
      0
    );

    Object.keys(summary).forEach((bucket) => {
      summary[bucket].percentage =
        totalAR > 0 ? (summary[bucket].amount / totalAR) * 100 : 0;
      summary[bucket].amount = Math.round(summary[bucket].amount * 100) / 100;
      summary[bucket].percentage = Math.round(summary[bucket].percentage * 100) / 100;
    });

    return {
      list: list.sort((a, b) => b.days_overdue - a.days_overdue),
      summary,
      total: {
        count: list.length,
        amount: Math.round(totalAR * 100) / 100,
      },
    };
  }
}

/**
 * AP Aging Report
 * Same structure as AR but for bills
 */
async function getAPAgingReport(companyId) {
  try {
    const bills = await Bill.find({
      companyId,
      balance_due: { $gt: 0 },
      status: { $nin: ["paid", "cancelled"] },
    })
      .populate("vendor_id", "name vendor_name")
      .sort({ due_date: 1 })
      .lean();

    const list = bills.map((bill) => {
      const daysOverdue = calculateDaysOverdue(bill.due_date);
      const bucket = getAgingBucket(daysOverdue);

      return {
        bill_id: bill._id,
        bill_number: bill.bill_number,
        vendor_name: bill.vendor_id?.name || bill.vendor_id?.vendor_name || "N/A",
        bill_date: bill.bill_date,
        due_date: bill.due_date,
        amount: bill.total_amount,
        balance_due: bill.balance_due,
        days_overdue: daysOverdue,
        aging_bucket: bucket,
      };
    });

    // Calculate summary by bucket
    const summary = {
      current: { count: 0, amount: 0 },
      "1-30": { count: 0, amount: 0 },
      "31-60": { count: 0, amount: 0 },
      "61-90": { count: 0, amount: 0 },
      "90+": { count: 0, amount: 0 },
    };

    list.forEach((bill) => {
      summary[bill.aging_bucket].count++;
      summary[bill.aging_bucket].amount += Number(bill.balance_due || 0);
    });

    const totalAP = Object.values(summary).reduce(
      (sum, bucket) => sum + bucket.amount,
      0
    );

    // Add percentages
    Object.keys(summary).forEach((bucket) => {
      summary[bucket].percentage =
        totalAP > 0 ? (summary[bucket].amount / totalAP) * 100 : 0;
      summary[bucket].amount = Math.round(summary[bucket].amount * 100) / 100;
      summary[bucket].percentage = Math.round(summary[bucket].percentage * 100) / 100;
    });

    return {
      list: list.sort((a, b) => b.days_overdue - a.days_overdue),
      summary,
      total: {
        count: list.length,
        amount: Math.round(totalAP * 100) / 100,
      },
    };
  } catch (error) {
    console.error("Error generating AP aging report:", error);
    // Fallback to Transaction model
    const transactions = await Transaction.find({
      companyId,
      type: "expense",
      status: { $ne: "paid" },
    })
      .sort({ date: 1 })
      .lean();

    const list = transactions.map((tx) => {
      const dueDate = tx.dueDate || tx.date;
      const daysOverdue = calculateDaysOverdue(dueDate);
      const bucket = getAgingBucket(daysOverdue);

      return {
        transaction_id: tx._id,
        bill_number: tx.description || "N/A",
        vendor_name: tx.counterparty || "N/A",
        bill_date: tx.date,
        due_date: dueDate,
        amount: tx.amount,
        balance_due: tx.amount,
        days_overdue: daysOverdue,
        aging_bucket: bucket,
      };
    });

    const summary = {
      current: { count: 0, amount: 0 },
      "1-30": { count: 0, amount: 0 },
      "31-60": { count: 0, amount: 0 },
      "61-90": { count: 0, amount: 0 },
      "90+": { count: 0, amount: 0 },
    };

    list.forEach((tx) => {
      summary[tx.aging_bucket].count++;
      summary[tx.aging_bucket].amount += Number(tx.balance_due || 0);
    });

    const totalAP = Object.values(summary).reduce(
      (sum, bucket) => sum + bucket.amount,
      0
    );

    Object.keys(summary).forEach((bucket) => {
      summary[bucket].percentage =
        totalAP > 0 ? (summary[bucket].amount / totalAP) * 100 : 0;
      summary[bucket].amount = Math.round(summary[bucket].amount * 100) / 100;
      summary[bucket].percentage = Math.round(summary[bucket].percentage * 100) / 100;
    });

    return {
      list: list.sort((a, b) => b.days_overdue - a.days_overdue),
      summary,
      total: {
        count: list.length,
        amount: Math.round(totalAP * 100) / 100,
      },
    };
  }
}

module.exports = {
  calculateDaysOverdue,
  getAgingBucket,
  getARAgingReport,
  getAPAgingReport,
};
