const TransactionLine = require("../models/TransactionLine");
const Account = require("../models/Account");
const Transaction = require("../models/Transaction");

/**
 * Step 1: Get Revenue
 * Query transaction_lines joining accounts where account_type = 'revenue'
 * Use credit_amount - debit_amount for revenue
 */
async function getRevenue(companyId, startDate, endDate) {
  try {
    const transactionLines = await TransactionLine.aggregate([
      {
        $lookup: {
          from: "transactions",
          localField: "transaction_id",
          foreignField: "_id",
          as: "transaction",
        },
      },
      {
        $unwind: "$transaction",
      },
      {
        $lookup: {
          from: "accounts",
          localField: "account_id",
          foreignField: "_id",
          as: "account",
        },
      },
      {
        $unwind: "$account",
      },
      {
        $match: {
          "transaction.companyId": companyId,
          "transaction.date": { $gte: startDate, $lte: endDate },
          "transaction.status": "posted",
          "account.account_type": "revenue",
          "account.is_active": true,
        },
      },
      {
        $group: {
          _id: null,
          total: {
            $sum: { $subtract: ["$credit_amount", "$debit_amount"] },
          },
        },
      },
    ]);

    // Fallback to Transaction model if no TransactionLines exist
    if (transactionLines.length === 0) {
      const transactions = await Transaction.find({
        companyId,
        type: "income",
        date: { $gte: startDate, $lte: endDate },
        status: "posted",
      }).lean();

      return transactions.reduce((sum, tx) => sum + Number(tx.amount || 0), 0);
    }

    return transactionLines[0]?.total || 0;
  } catch (error) {
    console.error("Error calculating revenue:", error);
    // Fallback to Transaction model
    const transactions = await Transaction.find({
      companyId,
      type: "income",
      date: { $gte: startDate, $lte: endDate },
      status: "posted",
    }).lean();

    return transactions.reduce((sum, tx) => sum + Number(tx.amount || 0), 0);
  }
}

/**
 * Step 2: Get COGS
 * Query transaction_lines joining accounts where account_type = 'cogs'
 * Use debit_amount - credit_amount for COGS
 */
async function getCOGS(companyId, startDate, endDate) {
  try {
    const transactionLines = await TransactionLine.aggregate([
      {
        $lookup: {
          from: "transactions",
          localField: "transaction_id",
          foreignField: "_id",
          as: "transaction",
        },
      },
      {
        $unwind: "$transaction",
      },
      {
        $lookup: {
          from: "accounts",
          localField: "account_id",
          foreignField: "_id",
          as: "account",
        },
      },
      {
        $unwind: "$account",
      },
      {
        $match: {
          "transaction.companyId": companyId,
          "transaction.date": { $gte: startDate, $lte: endDate },
          "transaction.status": "posted",
          "account.account_type": "cogs",
          "account.is_active": true,
        },
      },
      {
        $group: {
          _id: null,
          total: {
            $sum: { $subtract: ["$debit_amount", "$credit_amount"] },
          },
        },
      },
    ]);

    // Fallback to Transaction model if no TransactionLines exist
    if (transactionLines.length === 0) {
      const transactions = await Transaction.find({
        companyId,
        type: "expense",
        category: { $regex: /cogs|cost_of_goods|inventory/i },
        date: { $gte: startDate, $lte: endDate },
        status: "posted",
      }).lean();

      return transactions.reduce((sum, tx) => sum + Number(tx.amount || 0), 0);
    }

    return transactionLines[0]?.total || 0;
  } catch (error) {
    console.error("Error calculating COGS:", error);
    // Fallback to Transaction model
    const transactions = await Transaction.find({
      companyId,
      type: "expense",
      category: { $regex: /cogs|cost_of_goods|inventory/i },
      date: { $gte: startDate, $lte: endDate },
      status: "posted",
    }).lean();

    return transactions.reduce((sum, tx) => sum + Number(tx.amount || 0), 0);
  }
}

/**
 * Step 3: Calculate Gross Profit
 */
function calculateGrossProfit(revenue, cogs) {
  return revenue - cogs;
}

/**
 * Step 4: Calculate Gross Margin %
 */
function calculateGrossMargin(revenue, grossProfit) {
  if (revenue === 0) return 0;
  return (grossProfit / revenue) * 100;
}

/**
 * Step 5: Get Operating Expenses
 * Exclude interest and tax expenses
 * Filter by account_type = 'expense' AND NOT interest/tax accounts
 */
async function getOperatingExpenses(companyId, startDate, endDate) {
  try {
    const transactionLines = await TransactionLine.aggregate([
      {
        $lookup: {
          from: "transactions",
          localField: "transaction_id",
          foreignField: "_id",
          as: "transaction",
        },
      },
      {
        $unwind: "$transaction",
      },
      {
        $lookup: {
          from: "accounts",
          localField: "account_id",
          foreignField: "_id",
          as: "account",
        },
      },
      {
        $unwind: "$account",
      },
      {
        $match: {
          "transaction.companyId": companyId,
          "transaction.date": { $gte: startDate, $lte: endDate },
          "transaction.status": "posted",
          "account.account_type": "expense",
          "account.is_active": true,
          $or: [
            { "account.account_name": { $not: { $regex: /interest|tax/i } } },
            { "account.expense_category": { $nin: ["financing", "tax"] } },
          ],
        },
      },
      {
        $group: {
          _id: null,
          total: {
            $sum: { $subtract: ["$debit_amount", "$credit_amount"] },
          },
        },
      },
    ]);

    // Fallback to Transaction model if no TransactionLines exist
    if (transactionLines.length === 0) {
      const transactions = await Transaction.find({
        companyId,
        type: "expense",
        date: { $gte: startDate, $lte: endDate },
        status: "posted",
        category: {
          $not: { $regex: /interest|tax|cogs|cost_of_goods|inventory/i },
        },
      }).lean();

      return transactions.reduce((sum, tx) => sum + Number(tx.amount || 0), 0);
    }

    return transactionLines[0]?.total || 0;
  } catch (error) {
    console.error("Error calculating operating expenses:", error);
    // Fallback to Transaction model
    const transactions = await Transaction.find({
      companyId,
      type: "expense",
      date: { $gte: startDate, $lte: endDate },
      status: "posted",
      category: {
        $not: { $regex: /interest|tax|cogs|cost_of_goods|inventory/i },
      },
    }).lean();

    return transactions.reduce((sum, tx) => sum + Number(tx.amount || 0), 0);
  }
}

/**
 * Step 6: Calculate Operating Profit (EBIT)
 */
function calculateOperatingProfit(grossProfit, operatingExpenses) {
  return grossProfit - operatingExpenses;
}

/**
 * Step 7: Calculate Operating Margin %
 */
function calculateOperatingMargin(revenue, operatingProfit) {
  if (revenue === 0) return 0;
  return (operatingProfit / revenue) * 100;
}

/**
 * Step 8: Get Interest Expense
 * Filter accounts with account_name ILIKE '%interest%' or expense_category = 'financing'
 */
async function getInterestExpense(companyId, startDate, endDate) {
  try {
    const transactionLines = await TransactionLine.aggregate([
      {
        $lookup: {
          from: "transactions",
          localField: "transaction_id",
          foreignField: "_id",
          as: "transaction",
        },
      },
      {
        $unwind: "$transaction",
      },
      {
        $lookup: {
          from: "accounts",
          localField: "account_id",
          foreignField: "_id",
          as: "account",
        },
      },
      {
        $unwind: "$account",
      },
      {
        $match: {
          "transaction.companyId": companyId,
          "transaction.date": { $gte: startDate, $lte: endDate },
          "transaction.status": "posted",
          "account.account_type": "expense",
          "account.is_active": true,
          $or: [
            { "account.account_name": { $regex: /interest/i } },
            { "account.expense_category": "financing" },
          ],
        },
      },
      {
        $group: {
          _id: null,
          total: {
            $sum: { $subtract: ["$debit_amount", "$credit_amount"] },
          },
        },
      },
    ]);

    // Fallback to Transaction model if no TransactionLines exist
    if (transactionLines.length === 0) {
      const transactions = await Transaction.find({
        companyId,
        type: "expense",
        date: { $gte: startDate, $lte: endDate },
        status: "posted",
        $or: [
          { category: { $regex: /interest/i } },
          { description: { $regex: /interest/i } },
        ],
      }).lean();

      return transactions.reduce((sum, tx) => sum + Number(tx.amount || 0), 0);
    }

    return transactionLines[0]?.total || 0;
  } catch (error) {
    console.error("Error calculating interest expense:", error);
    // Fallback to Transaction model
    const transactions = await Transaction.find({
      companyId,
      type: "expense",
      date: { $gte: startDate, $lte: endDate },
      status: "posted",
      $or: [
        { category: { $regex: /interest/i } },
        { description: { $regex: /interest/i } },
      ],
    }).lean();

    return transactions.reduce((sum, tx) => sum + Number(tx.amount || 0), 0);
  }
}

/**
 * Step 9: Calculate Profit Before Tax (PBT/EBT)
 */
function calculateProfitBeforeTax(operatingProfit, interestExpense) {
  return operatingProfit - interestExpense;
}

/**
 * Step 10: Get Income Tax Expense
 * Filter accounts with account_name ILIKE '%tax%' or expense_category = 'tax'
 * Exclude sales tax, payroll tax, property tax (these are operating expenses)
 */
async function getIncomeTax(companyId, startDate, endDate) {
  try {
    const transactionLines = await TransactionLine.aggregate([
      {
        $lookup: {
          from: "transactions",
          localField: "transaction_id",
          foreignField: "_id",
          as: "transaction",
        },
      },
      {
        $unwind: "$transaction",
      },
      {
        $lookup: {
          from: "accounts",
          localField: "account_id",
          foreignField: "_id",
          as: "account",
        },
      },
      {
        $unwind: "$account",
      },
      {
        $match: {
          "transaction.companyId": companyId,
          "transaction.date": { $gte: startDate, $lte: endDate },
          "transaction.status": "posted",
          "account.account_type": "expense",
          "account.is_active": true,
          $or: [
            { "account.account_name": { $regex: /income.*tax|corporate.*tax|federal.*tax|state.*tax/i } },
            { "account.expense_category": "tax" },
          ],
          "account.account_name": {
            $not: { $regex: /sales.*tax|payroll.*tax|property.*tax/i },
          },
        },
      },
      {
        $group: {
          _id: null,
          total: {
            $sum: { $subtract: ["$debit_amount", "$credit_amount"] },
          },
        },
      },
    ]);

    // Fallback to Transaction model if no TransactionLines exist
    if (transactionLines.length === 0) {
      const transactions = await Transaction.find({
        companyId,
        type: "expense",
        date: { $gte: startDate, $lte: endDate },
        status: "posted",
        $or: [
          { category: { $regex: /income.*tax|corporate.*tax|federal.*tax|state.*tax/i } },
          { description: { $regex: /income.*tax|corporate.*tax|federal.*tax|state.*tax/i } },
        ],
        category: {
          $not: { $regex: /sales.*tax|payroll.*tax|property.*tax/i },
        },
      }).lean();

      return transactions.reduce((sum, tx) => sum + Number(tx.amount || 0), 0);
    }

    return transactionLines[0]?.total || 0;
  } catch (error) {
    console.error("Error calculating income tax:", error);
    // Fallback to Transaction model
    const transactions = await Transaction.find({
      companyId,
      type: "expense",
      date: { $gte: startDate, $lte: endDate },
      status: "posted",
      $or: [
        { category: { $regex: /income.*tax|corporate.*tax|federal.*tax|state.*tax/i } },
        { description: { $regex: /income.*tax|corporate.*tax|federal.*tax|state.*tax/i } },
      ],
      category: {
        $not: { $regex: /sales.*tax|payroll.*tax|property.*tax/i },
      },
    }).lean();

    return transactions.reduce((sum, tx) => sum + Number(tx.amount || 0), 0);
  }
}

/**
 * Step 11: Calculate Net Profit After Tax (PAT/Net Income)
 */
function calculateNetProfitAfterTax(profitBeforeTax, incomeTax) {
  return profitBeforeTax - incomeTax;
}

/**
 * Step 12: Calculate Net Profit Margin %
 */
function calculateNetProfitMargin(revenue, netProfitAfterTax) {
  if (revenue === 0) return 0;
  return (netProfitAfterTax / revenue) * 100;
}

/**
 * Step 13: Calculate Tax Burden %
 * CRITICAL FIX: Uses profitBeforeTax, not revenue
 * Return 0 if profitBeforeTax <= 0
 */
function calculateTaxBurden(profitBeforeTax, incomeTax) {
  if (profitBeforeTax <= 0) return 0;
  return (incomeTax / profitBeforeTax) * 100;
}

/**
 * Step 14: Calculate Current Ratio
 * Get current assets (cash, bank, receivables, inventory, prepaid)
 * Get current liabilities (payables, short-term loans, accrued expenses)
 * Return null if current_liabilities === 0 (not 0 or Infinity)
 */
async function calculateCurrentRatio(companyId) {
  try {
    // Get current assets
    const currentAssetsAccounts = await Account.find({
      companyId,
      account_type: "asset",
      is_active: true,
      $or: [
        { is_cash_account: true },
        { is_bank_account: true },
        { account_name: { $regex: /current|receivable|inventory|prepaid/i } },
        { account_subtype: "current" },
      ],
    }).lean();

    const currentAssets = currentAssetsAccounts.reduce(
      (sum, acc) => sum + Number(acc.current_balance || 0),
      0
    );

    // Get current liabilities
    const currentLiabilitiesAccounts = await Account.find({
      companyId,
      account_type: "liability",
      is_active: true,
      $or: [
        { account_name: { $regex: /current|payable|short|accrued/i } },
        { account_subtype: "current" },
      ],
    }).lean();

    const currentLiabilities = currentLiabilitiesAccounts.reduce(
      (sum, acc) => sum + Number(acc.current_balance || 0),
      0
    );

    // Return null if current_liabilities === 0 (not 0 or Infinity)
    if (currentLiabilities === 0) {
      return null;
    }

    return currentAssets / currentLiabilities;
  } catch (error) {
    console.error("Error calculating current ratio:", error);
    return null;
  }
}

/**
 * Calculate all KPIs in one function
 */
async function calculateAllKPIs(companyId, startDate, endDate) {
  const revenue = await getRevenue(companyId, startDate, endDate);
  const cogs = await getCOGS(companyId, startDate, endDate);
  const grossProfit = calculateGrossProfit(revenue, cogs);
  const grossMargin = calculateGrossMargin(revenue, grossProfit);

  const operatingExpenses = await getOperatingExpenses(companyId, startDate, endDate);
  const operatingProfit = calculateOperatingProfit(grossProfit, operatingExpenses);
  const operatingMargin = calculateOperatingMargin(revenue, operatingProfit);

  const interestExpense = await getInterestExpense(companyId, startDate, endDate);
  const profitBeforeTax = calculateProfitBeforeTax(operatingProfit, interestExpense);

  const incomeTax = await getIncomeTax(companyId, startDate, endDate);
  const netProfitAfterTax = calculateNetProfitAfterTax(profitBeforeTax, incomeTax);
  const netProfitMargin = calculateNetProfitMargin(revenue, netProfitAfterTax);
  const taxBurden = calculateTaxBurden(profitBeforeTax, incomeTax);

  const currentRatio = await calculateCurrentRatio(companyId);

  // Get current assets and liabilities for snapshot
  const currentAssetsAccounts = await Account.find({
    companyId,
    account_type: "asset",
    is_active: true,
    $or: [
      { is_cash_account: true },
      { is_bank_account: true },
      { account_name: { $regex: /current|receivable|inventory|prepaid/i } },
      { account_subtype: "current" },
    ],
  }).lean();

  const currentAssets = currentAssetsAccounts.reduce(
    (sum, acc) => sum + Number(acc.current_balance || 0),
    0
  );

  const currentLiabilitiesAccounts = await Account.find({
    companyId,
    account_type: "liability",
    is_active: true,
    $or: [
      { account_name: { $regex: /current|payable|short|accrued/i } },
      { account_subtype: "current" },
    ],
  }).lean();

  const currentLiabilities = currentLiabilitiesAccounts.reduce(
    (sum, acc) => sum + Number(acc.current_balance || 0),
    0
  );

  return {
    revenue: Math.round(revenue * 100) / 100,
    cogs: Math.round(cogs * 100) / 100,
    operating_expenses: Math.round(operatingExpenses * 100) / 100,
    interest_expense: Math.round(interestExpense * 100) / 100,
    income_tax: Math.round(incomeTax * 100) / 100,
    grossProfit: Math.round(grossProfit * 100) / 100,
    operating_profit: Math.round(operatingProfit * 100) / 100,
    profit_before_tax: Math.round(profitBeforeTax * 100) / 100,
    net_profit_after_tax: Math.round(netProfitAfterTax * 100) / 100,
    grossMargin: Math.round(grossMargin * 100) / 100,
    operating_margin: Math.round(operatingMargin * 100) / 100,
    net_profit_margin: Math.round(netProfitMargin * 100) / 100,
    taxBurden: Math.round(taxBurden * 100) / 100,
    current_assets: Math.round(currentAssets * 100) / 100,
    current_liabilities: Math.round(currentLiabilities * 100) / 100,
    current_ratio: currentRatio !== null ? Math.round(currentRatio * 100) / 100 : null,
  };
}

module.exports = {
  getRevenue,
  getCOGS,
  calculateGrossProfit,
  calculateGrossMargin,
  getOperatingExpenses,
  calculateOperatingProfit,
  calculateOperatingMargin,
  getInterestExpense,
  calculateProfitBeforeTax,
  getIncomeTax,
  calculateNetProfitAfterTax,
  calculateNetProfitMargin,
  calculateTaxBurden,
  calculateCurrentRatio,
  calculateAllKPIs,
};
