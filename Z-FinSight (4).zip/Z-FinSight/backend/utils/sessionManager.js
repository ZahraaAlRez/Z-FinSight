/**
 * Session Manager
 * Track active user sessions and enforce session limits
 * 
 * Features:
 * - Track active sessions per user
 * - Limit concurrent sessions
 * - Track login location (IP, device)
 * - Session expiry handling
 */

const mongoose = require('mongoose');

// ============================================
// Session Schema
// ============================================
const sessionSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true,
  },
  adminId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Admin',
  },
  companyId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Company',
  },
  
  // Token info
  tokenId: {
    type: String,
    required: true,
    unique: true,
    index: true,
  },
  
  // Session details
  ipAddress: String,
  userAgent: String,
  device: String, // 'mobile', 'tablet', 'desktop'
  browser: String,
  os: String,
  location: {
    country: String,
    city: String,
  },
  
  // Timing
  createdAt: {
    type: Date,
    default: Date.now,
    index: true,
  },
  lastActivity: {
    type: Date,
    default: Date.now,
  },
  expiresAt: {
    type: Date,
    required: true,
    index: true,
  },
  
  // Status
  isActive: {
    type: Boolean,
    default: true,
    index: true,
  },
});

// Index for auto-cleanup of expired sessions
sessionSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

// Indexes for queries
sessionSchema.index({ userId: 1, isActive: 1 });
sessionSchema.index({ companyId: 1, isActive: 1 });

const Session = mongoose.model('Session', sessionSchema);

// ============================================
// Session Management Functions
// ============================================

/**
 * Create new session
 * @param {Object} data - Session data
 * @returns {Promise<Object>} Created session
 */
async function createSession(data) {
  try {
    const session = new Session({
      userId: data.userId,
      adminId: data.adminId || null,
      companyId: data.companyId || null,
      tokenId: data.tokenId,
      ipAddress: data.ipAddress || null,
      userAgent: data.userAgent || null,
      device: detectDevice(data.userAgent),
      browser: detectBrowser(data.userAgent),
      os: detectOS(data.userAgent),
      location: data.location || {},
      expiresAt: data.expiresAt,
      isActive: true,
    });

    await session.save();
    return session;
  } catch (err) {
    console.error('Create session error:', err);
    throw err;
  }
}

/**
 * Get active sessions for a user
 * @param {string} userId - User ID
 * @returns {Promise<Array>} Active sessions
 */
async function getActiveSessions(userId) {
  return await Session.find({
    userId,
    isActive: true,
    expiresAt: { $gt: new Date() },
  }).sort({ lastActivity: -1 });
}

/**
 * Update session activity
 * @param {string} tokenId - Token ID
 * @returns {Promise<Object>} Updated session
 */
async function updateSessionActivity(tokenId) {
  return await Session.findOneAndUpdate(
    { tokenId, isActive: true },
    { lastActivity: new Date() },
    { new: true }
  );
}

/**
 * Invalidate session (logout)
 * @param {string} tokenId - Token ID
 * @returns {Promise<Object>} Updated session
 */
async function invalidateSession(tokenId) {
  return await Session.findOneAndUpdate(
    { tokenId },
    { isActive: false },
    { new: true }
  );
}

/**
 * Invalidate all sessions for a user
 * @param {string} userId - User ID
 * @returns {Promise<number>} Number of sessions invalidated
 */
async function invalidateAllUserSessions(userId) {
  const result = await Session.updateMany(
    { userId, isActive: true },
    { isActive: false }
  );
  
  return result.modifiedCount;
}

/**
 * Enforce session limit per user
 * @param {string} userId - User ID
 * @param {number} maxSessions - Maximum allowed sessions
 * @returns {Promise<void>}
 */
async function enforceSessionLimit(userId, maxSessions = 5) {
  const sessions = await getActiveSessions(userId);
  
  if (sessions.length >= maxSessions) {
    // Invalidate oldest sessions
    const sessionsToInvalidate = sessions.slice(maxSessions - 1);
    
    for (const session of sessionsToInvalidate) {
      await invalidateSession(session.tokenId);
    }
  }
}

/**
 * Clean up expired sessions (can be run as cron job)
 * @returns {Promise<number>} Number of sessions cleaned
 */
async function cleanupExpiredSessions() {
  const result = await Session.deleteMany({
    $or: [
      { expiresAt: { $lt: new Date() } },
      { isActive: false, createdAt: { $lt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) } } // 30 days old inactive
    ]
  });
  
  return result.deletedCount;
}

/**
 * Get session statistics
 * @param {Object} filters - Query filters
 * @returns {Promise<Object>} Statistics
 */
async function getSessionStats(filters = {}) {
  const query = { isActive: true, expiresAt: { $gt: new Date() } };
  
  if (filters.companyId) query.companyId = filters.companyId;
  
  const stats = await Session.aggregate([
    { $match: query },
    {
      $group: {
        _id: null,
        totalSessions: { $sum: 1 },
        uniqueUsers: { $addToSet: '$userId' },
        byDevice: {
          $push: '$device'
        }
      }
    },
    {
      $project: {
        totalSessions: 1,
        uniqueUsers: { $size: '$uniqueUsers' },
        deviceBreakdown: {
          mobile: {
            $size: {
              $filter: {
                input: '$byDevice',
                cond: { $eq: ['$$this', 'mobile'] }
              }
            }
          },
          desktop: {
            $size: {
              $filter: {
                input: '$byDevice',
                cond: { $eq: ['$$this', 'desktop'] }
              }
            }
          },
          tablet: {
            $size: {
              $filter: {
                input: '$byDevice',
                cond: { $eq: ['$$this', 'tablet'] }
              }
            }
          }
        }
      }
    }
  ]);

  return stats[0] || {
    totalSessions: 0,
    uniqueUsers: 0,
    deviceBreakdown: { mobile: 0, desktop: 0, tablet: 0 }
  };
}

// ============================================
// Helper Functions (Device Detection)
// ============================================

function detectDevice(userAgent) {
  if (!userAgent) return 'unknown';
  
  const ua = userAgent.toLowerCase();
  
  if (/(tablet|ipad|playbook|silk)|(android(?!.*mobi))/i.test(ua)) {
    return 'tablet';
  }
  if (/Mobile|Android|iP(hone|od)|IEMobile|BlackBerry|Kindle|Silk-Accelerated|(hpw|web)OS|Opera M(obi|ini)/.test(ua)) {
    return 'mobile';
  }
  return 'desktop';
}

function detectBrowser(userAgent) {
  if (!userAgent) return 'unknown';
  
  const ua = userAgent.toLowerCase();
  
  if (ua.includes('chrome') && !ua.includes('edg')) return 'Chrome';
  if (ua.includes('safari') && !ua.includes('chrome')) return 'Safari';
  if (ua.includes('firefox')) return 'Firefox';
  if (ua.includes('edg')) return 'Edge';
  if (ua.includes('opera') || ua.includes('opr')) return 'Opera';
  
  return 'unknown';
}

function detectOS(userAgent) {
  if (!userAgent) return 'unknown';
  
  const ua = userAgent.toLowerCase();
  
  if (ua.includes('win')) return 'Windows';
  if (ua.includes('mac')) return 'macOS';
  if (ua.includes('linux')) return 'Linux';
  if (ua.includes('android')) return 'Android';
  if (ua.includes('ios') || ua.includes('iphone') || ua.includes('ipad')) return 'iOS';
  
  return 'unknown';
}

// ============================================
// Express Middleware
// ============================================

/**
 * Middleware to track session activity
 */
function trackSessionActivity() {
  return async (req, res, next) => {
    if (req.user && req.user.tokenId) {
      // Update activity in background
      updateSessionActivity(req.user.tokenId).catch(err => {
        console.error('Session activity update error:', err);
      });
    }
    next();
  };
}

module.exports = {
  Session,
  createSession,
  getActiveSessions,
  updateSessionActivity,
  invalidateSession,
  invalidateAllUserSessions,
  enforceSessionLimit,
  cleanupExpiredSessions,
  getSessionStats,
  trackSessionActivity,
};