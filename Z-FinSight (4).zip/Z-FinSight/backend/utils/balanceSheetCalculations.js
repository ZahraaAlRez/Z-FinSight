const Account = require("../models/Account");

/**
 * Get all accounts grouped by type and classification
 */
async function getBalanceSheetAccounts(companyId) {
  const accounts = await Account.find({
    companyId,
    is_active: true,
    account_type: { $in: ["asset", "liability", "equity"] },
  }).lean();

  const assets = {
    current: [],
    non_current: [],
  };

  const liabilities = {
    current: [],
    non_current: [],
  };

  const equity = [];

  accounts.forEach((acc) => {
    const accountData = {
      account_id: acc._id,
      account_name: acc.account_name,
      current_balance: Number(acc.current_balance || 0),
    };

    if (acc.account_type === "asset") {
      const isCurrent =
        acc.is_cash_account ||
        acc.is_bank_account ||
        acc.account_name.match(/current|receivable|inventory|prepaid/i) ||
        acc.account_subtype === "current";

      if (isCurrent) {
        assets.current.push(accountData);
      } else {
        assets.non_current.push(accountData);
      }
    } else if (acc.account_type === "liability") {
      const isCurrent =
        acc.account_name.match(/current|payable|short|accrued/i) ||
        acc.account_subtype === "current";

      if (isCurrent) {
        liabilities.current.push(accountData);
      } else {
        liabilities.non_current.push(accountData);
      }
    } else if (acc.account_type === "equity") {
      equity.push(accountData);
    }
  });

  return { assets, liabilities, equity };
}

/**
 * Calculate totals for each section
 */
function calculateSectionTotals(section) {
  return section.reduce((sum, acc) => sum + acc.current_balance, 0);
}

/**
 * Generate complete Balance Sheet
 * CRITICAL: Must validate Assets = Liabilities + Equity
 */
async function generateBalanceSheet(companyId) {
  try {
    const { assets, liabilities, equity } = await getBalanceSheetAccounts(companyId);

    // Calculate totals
    const currentAssetsTotal = calculateSectionTotals(assets.current);
    const nonCurrentAssetsTotal = calculateSectionTotals(assets.non_current);
    const totalAssets = currentAssetsTotal + nonCurrentAssetsTotal;

    const currentLiabilitiesTotal = calculateSectionTotals(liabilities.current);
    const nonCurrentLiabilitiesTotal = calculateSectionTotals(liabilities.non_current);
    const totalLiabilities = currentLiabilitiesTotal + nonCurrentLiabilitiesTotal;

    const totalEquity = calculateSectionTotals(equity);

    // CRITICAL VALIDATION: Assets must equal Liabilities + Equity
    const totalLiabilitiesAndEquity = totalLiabilities + totalEquity;
    const difference = Math.abs(totalAssets - totalLiabilitiesAndEquity);

    if (difference > 0.01) {
      // Rounding tolerance
      throw new Error(
        `Balance Sheet does not balance! Assets (${totalAssets.toFixed(2)}) ≠ Liabilities + Equity (${totalLiabilitiesAndEquity.toFixed(2)}). Difference: ${difference.toFixed(2)}`
      );
    }

    return {
      assets: {
        current: {
          items: assets.current.map((acc) => ({
            ...acc,
            current_balance: Math.round(acc.current_balance * 100) / 100,
          })),
          total: Math.round(currentAssetsTotal * 100) / 100,
        },
        non_current: {
          items: assets.non_current.map((acc) => ({
            ...acc,
            current_balance: Math.round(acc.current_balance * 100) / 100,
          })),
          total: Math.round(nonCurrentAssetsTotal * 100) / 100,
        },
        total: Math.round(totalAssets * 100) / 100,
      },
      liabilities: {
        current: {
          items: liabilities.current.map((acc) => ({
            ...acc,
            current_balance: Math.round(acc.current_balance * 100) / 100,
          })),
          total: Math.round(currentLiabilitiesTotal * 100) / 100,
        },
        non_current: {
          items: liabilities.non_current.map((acc) => ({
            ...acc,
            current_balance: Math.round(acc.current_balance * 100) / 100,
          })),
          total: Math.round(nonCurrentLiabilitiesTotal * 100) / 100,
        },
        total: Math.round(totalLiabilities * 100) / 100,
      },
      equity: {
        items: equity.map((acc) => ({
          ...acc,
          current_balance: Math.round(acc.current_balance * 100) / 100,
        })),
        total: Math.round(totalEquity * 100) / 100,
      },
      total_liabilities_and_equity: Math.round(totalLiabilitiesAndEquity * 100) / 100,
      balance_check: {
        balanced: true,
        difference: 0,
      },
    };
  } catch (error) {
    console.error("Error generating balance sheet:", error);
    throw error;
  }
}

module.exports = {
  getBalanceSheetAccounts,
  calculateSectionTotals,
  generateBalanceSheet,
};
