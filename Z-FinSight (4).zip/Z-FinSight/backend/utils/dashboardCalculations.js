const Transaction = require("../models/Transaction");
const Invoice = require("../models/Invoice");
const Bill = require("../models/Bill");
const BankAccount = require("../models/BankAccount");
const BankLine = require("../models/BankLine");
const Account = require("../models/Account");
const TransactionLine = require("../models/TransactionLine");

/**
 * 1. Uncategorized Transactions Count
 * Count all transactions that are not properly categorized or are still in draft
 */
async function getUncategorizedTransactionsCount(companyId, startDate, endDate) {
  try {
    // Try with TransactionLine model first
    const uncategorized = await TransactionLine.aggregate([
      {
        $lookup: {
          from: "transactions",
          localField: "transaction_id",
          foreignField: "_id",
          as: "transaction",
        },
      },
      {
        $unwind: "$transaction",
      },
      {
        $lookup: {
          from: "accounts",
          localField: "account_id",
          foreignField: "_id",
          as: "account",
        },
      },
      {
        $match: {
          "transaction.companyId": companyId,
          "transaction.date": { $gte: startDate, $lte: endDate },
          "transaction.status": "posted",
          $or: [
            { account: { $size: 0 } },
            { "account.account_id": null },
          ],
        },
      },
      {
        $group: {
          _id: "$transaction_id",
        },
      },
      {
        $count: "count",
      },
    ]);

    // Fallback to Transaction model
    const count = await Transaction.countDocuments({
      companyId,
      date: { $gte: startDate, $lte: endDate },
      status: "posted",
      $or: [
        { category: { $in: ["Uncategorized", "", null] } },
        { status: "draft" },
      ],
    });

    return uncategorized[0]?.count || count || 0;
  } catch (error) {
    console.error("Error counting uncategorized transactions:", error);
    // Fallback to Transaction model
    return await Transaction.countDocuments({
      companyId,
      date: { $gte: startDate, $lte: endDate },
      status: "posted",
      $or: [
        { category: { $in: ["Uncategorized", "", null] } },
        { status: "draft" },
      ],
    });
  }
}

/**
 * 2. Overdue Invoices Count (Accounts Receivable)
 * Count all customer invoices that are past their due date and still have an outstanding balance
 */
async function getOverdueInvoicesCount(companyId) {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const count = await Invoice.countDocuments({
      companyId,
      invoice_type: "sales",
      due_date: { $lt: today },
      balance_due: { $gt: 0 },
      status: { $nin: ["paid", "cancelled"] },
    });

    return count;
  } catch (error) {
    console.error("Error counting overdue invoices:", error);
    // Fallback to Transaction model
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    return await Transaction.countDocuments({
      companyId,
      type: "income",
      status: { $ne: "paid" },
      date: { $lt: today },
    });
  }
}

/**
 * 3. Bills Due Count (Accounts Payable)
 * Count all vendor bills that are due soon or already overdue
 */
async function getBillsDueCount(companyId) {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const sevenDaysFromNow = new Date(today);
    sevenDaysFromNow.setDate(sevenDaysFromNow.getDate() + 7);

    // Bills due soon (next 7 days)
    const billsDueSoon = await Bill.countDocuments({
      companyId,
      bill_type: "purchase",
      due_date: { $gte: today, $lte: sevenDaysFromNow },
      balance_due: { $gt: 0 },
      status: { $nin: ["paid", "cancelled"] },
    });

    // Bills overdue
    const billsOverdue = await Bill.countDocuments({
      companyId,
      bill_type: "purchase",
      due_date: { $lt: today },
      balance_due: { $gt: 0 },
      status: { $nin: ["paid", "cancelled"] },
    });

    return billsDueSoon + billsOverdue;
  } catch (error) {
    console.error("Error counting bills due:", error);
    // Fallback to Transaction model
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const sevenDaysFromNow = new Date(today);
    sevenDaysFromNow.setDate(sevenDaysFromNow.getDate() + 7);

    const billsDueSoon = await Transaction.countDocuments({
      companyId,
      type: "expense",
      status: { $ne: "paid" },
      date: { $gte: today, $lte: sevenDaysFromNow },
    });

    const billsOverdue = await Transaction.countDocuments({
      companyId,
      type: "expense",
      status: { $ne: "paid" },
      date: { $lt: today },
    });

    return billsDueSoon + billsOverdue;
  }
}

/**
 * 4. To Reconcile Count
 * Count bank accounts that need reconciliation or have unmatched statement lines
 */
async function getToReconcileCount(companyId) {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const thirtyDaysAgo = new Date(today);
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    // Option A: By Bank Account
    const accountsToReconcile = await BankAccount.countDocuments({
      companyId,
      is_active: true,
      $or: [
        { last_reconciled_date: null },
        { last_reconciled_date: { $lt: thirtyDaysAgo } },
      ],
    });

    // Option B: By Statement Lines
    const unmatchedLines = await BankLine.countDocuments({
      companyId,
      matched: false,
    });

    // Return the higher count (more comprehensive)
    return Math.max(accountsToReconcile, unmatchedLines);
  } catch (error) {
    console.error("Error counting accounts to reconcile:", error);
    // Fallback to BankLine only
    return await BankLine.countDocuments({
      companyId,
      matched: false,
    });
  }
}

/**
 * 5. Bank Balance
 * Current balance of all active bank accounts
 */
async function getBankBalance(companyId) {
  try {
    // Try BankAccount model first
    const bankAccounts = await BankAccount.find({
      companyId,
      is_active: true,
      account_type: { $in: ["checking", "savings"] },
    }).lean();

    if (bankAccounts.length > 0) {
      return bankAccounts.reduce(
        (sum, acc) => sum + Number(acc.current_balance || 0),
        0
      );
    }

    // Fallback to Account model
    const accounts = await Account.find({
      companyId,
      is_bank_account: true,
      is_active: true,
    }).lean();

    return accounts.reduce(
      (sum, acc) => sum + Number(acc.current_balance || 0),
      0
    );
  } catch (error) {
    console.error("Error calculating bank balance:", error);
    return 0;
  }
}

/**
 * 6. Cash on Hand
 * Current balance of all cash accounts (petty cash, cash drawer, etc.)
 */
async function getCashOnHand(companyId) {
  try {
    const cashAccounts = await Account.find({
      companyId,
      is_cash_account: true,
      is_active: true,
    }).lean();

    return cashAccounts.reduce(
      (sum, acc) => sum + Number(acc.current_balance || 0),
      0
    );
  } catch (error) {
    console.error("Error calculating cash on hand:", error);
    return 0;
  }
}

/**
 * 7. Cash Flow Trend (Last 30 Days)
 * Daily net cash movement over the past 30 days
 */
async function getCashFlowTrend(companyId) {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const thirtyDaysAgo = new Date(today);
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    // Try with TransactionLine model first
    const dailyCashFlow = await TransactionLine.aggregate([
      {
        $lookup: {
          from: "transactions",
          localField: "transaction_id",
          foreignField: "_id",
          as: "transaction",
        },
      },
      {
        $unwind: "$transaction",
      },
      {
        $lookup: {
          from: "accounts",
          localField: "account_id",
          foreignField: "_id",
          as: "account",
        },
      },
      {
        $unwind: "$account",
      },
      {
        $match: {
          "transaction.companyId": companyId,
          "transaction.date": { $gte: thirtyDaysAgo, $lte: today },
          "transaction.status": "posted",
          "account.account_type": "asset",
          $or: [
            { "account.is_cash_account": true },
            { "account.is_bank_account": true },
          ],
        },
      },
      {
        $group: {
          _id: {
            $dateToString: { format: "%Y-%m-%d", date: "$transaction.date" },
          },
          daily_cash_change: {
            $sum: { $subtract: ["$debit_amount", "$credit_amount"] },
          },
        },
      },
      {
        $sort: { _id: 1 },
      },
    ]);

    // Fallback to Transaction model
    if (dailyCashFlow.length === 0) {
      const transactions = await Transaction.find({
        companyId,
        date: { $gte: thirtyDaysAgo, $lte: today },
        status: "posted",
        method: { $in: ["cash", "bank"] },
      })
        .sort({ date: 1 })
        .lean();

      const dailyMap = {};
      transactions.forEach((tx) => {
        const dateStr = tx.date.toISOString().split("T")[0];
        if (!dailyMap[dateStr]) {
          dailyMap[dateStr] = 0;
        }
        if (tx.type === "income") {
          dailyMap[dateStr] += Number(tx.amount || 0);
        } else {
          dailyMap[dateStr] -= Number(tx.amount || 0);
        }
      });

      return Object.entries(dailyMap)
        .map(([date, change]) => ({
          date,
          daily_cash_change: change,
        }))
        .sort((a, b) => a.date.localeCompare(b.date));
    }

    // Calculate cumulative balance
    let runningBalance = 0;
    const trendData = dailyCashFlow.map((day) => {
      runningBalance += day.daily_cash_change;
      return {
        date: day._id,
        balance: Math.round(runningBalance * 100) / 100,
        daily_cash_change: Math.round(day.daily_cash_change * 100) / 100,
      };
    });

    return trendData;
  } catch (error) {
    console.error("Error calculating cash flow trend:", error);
    return [];
  }
}

/**
 * Get all overview dashboard metrics
 */
async function getOverviewDashboardMetrics(companyId, startDate, endDate) {
  const [
    uncategorizedCount,
    overdueInvoices,
    billsDue,
    toReconcileCount,
    bankBalance,
    cashOnHand,
    cashFlowTrend,
  ] = await Promise.all([
    getUncategorizedTransactionsCount(companyId, startDate, endDate),
    getOverdueInvoicesCount(companyId),
    getBillsDueCount(companyId),
    getToReconcileCount(companyId),
    getBankBalance(companyId),
    getCashOnHand(companyId),
    getCashFlowTrend(companyId),
  ]);

  return {
    uncategorized: uncategorizedCount,
    overdueInvoices,
    billsDue,
    toReconcileCount,
    bankBalance: Math.round(bankBalance * 100) / 100,
    cashOnHand: Math.round(cashOnHand * 100) / 100,
    cashFlowTrend,
  };
}

module.exports = {
  getUncategorizedTransactionsCount,
  getOverdueInvoicesCount,
  getBillsDueCount,
  getToReconcileCount,
  getBankBalance,
  getCashOnHand,
  getCashFlowTrend,
  getOverviewDashboardMetrics,
};
