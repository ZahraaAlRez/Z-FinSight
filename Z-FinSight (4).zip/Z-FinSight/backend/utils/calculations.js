const { startOfPeriod, endOfPeriod } = require("./dates");

function categorizeExpenseBucket(tx) {
  const cat = (tx.category || "").toLowerCase();
  // You can tune these rules anytime:
  if (cat.includes("cogs") || cat.includes("cost_of_goods") || cat.includes("inventory")) return "cogs";
  if (cat.includes("tax")) return "taxes";
  return "opex";
}

function computeProfitabilityFromTransactions(txs) {
  let revenue = 0, cogs = 0, opex = 0, taxes = 0;
  let currency = "USD";

  for (const tx of txs) {
    currency = tx.currency || currency;
    const t = (tx.type || "").toLowerCase();
    const amt = Number(tx.amount || 0);

    if (t === "revenue" || t === "income") revenue += amt;
    else if (t === "expense") {
      const b = categorizeExpenseBucket(tx);
      if (b === "cogs") cogs += amt;
      else if (b === "taxes") taxes += amt;
      else opex += amt;
    } else if (t === "invoice") {
      // invoices count as revenue (even if unpaid) for P&L view; adjust if you want cash basis
      revenue += amt;
    } else if (t === "bill") {
      const b = categorizeExpenseBucket(tx);
      if (b === "cogs") cogs += amt;
      else if (b === "taxes") taxes += amt;
      else opex += amt;
    }
  }

  const grossProfit = revenue - cogs;
  const afterTaxProfit = grossProfit - opex - taxes;
  const grossMargin = revenue > 0 ? grossProfit / revenue : 0;
  const netMargin = revenue > 0 ? afterTaxProfit / revenue : 0;
  const taxBurden = revenue > 0 ? taxes / revenue : 0;

  return { currency, revenue, cogs, opex, taxes, grossProfit, afterTaxProfit, grossMargin, netMargin, taxBurden };
}

function computeARAPaging(txs, kind) {
  // kind: "ar" (invoices) or "ap" (bills)
  const now = new Date();
  const buckets = { "0-30": 0, "31-60": 0, "61-90": 0, "90+": 0 };
  const list = [];

  for (const tx of txs) {
    const t = (tx.type || "").toLowerCase();
    if (kind === "ar" && t !== "invoice") continue;
    if (kind === "ap" && t !== "bill") continue;

    const st = (tx.status || "open").toLowerCase();
    if (st === "paid") continue;

    const due = tx.dueDate ? new Date(tx.dueDate) : new Date(tx.date);
    const days = Math.floor((now - due) / 86400000);
    const amt = Number(tx.amount || 0);

    if (days <= 30) buckets["0-30"] += amt;
    else if (days <= 60) buckets["31-60"] += amt;
    else if (days <= 90) buckets["61-90"] += amt;
    else buckets["90+"] += amt;

    list.push({
      id: String(tx._id),
      description: tx.description || "",
      amount: amt,
      dueDate: due,
      daysPastDue: days
    });
  }

  return { buckets, list: list.sort((a,b)=>b.daysPastDue-a.daysPastDue) };
}

function computeCashFlow(txs) {
  // Simple MVP cash basis:
  // revenue + payments in = inflow
  // expense + payments out = outflow
  let inflow = 0, outflow = 0;
  for (const tx of txs) {
    const t = (tx.type || "").toLowerCase();
    const amt = Number(tx.amount || 0);
    if (t === "revenue" || t === "income") inflow += amt;
    else if (t === "expense") outflow += amt;
    else if (t === "payment") {
      // if payment has category/description includes "in" or "salary"? keep simple:
      if ((tx.description || "").toLowerCase().includes("in")) inflow += amt;
      else outflow += amt;
    }
  }
  return { inflow, outflow, netCash: inflow - outflow };
}

function computeExpensesByCategory(txs) {
  const map = {};
  for (const tx of txs) {
    const t = (tx.type || "").toLowerCase();
    if (t !== "expense" && t !== "bill") continue;
    const cat = (tx.category || "Uncategorized").trim() || "Uncategorized";
    map[cat] = (map[cat] || 0) + Number(tx.amount || 0);
  }
  const items = Object.entries(map)
    .map(([category, total]) => ({ category, total }))
    .sort((a,b)=>b.total-a.total);
  return items;
}

function computeBalanceSheetMVP({ bankBalance, cashOnHand, arTotal, apTotal }) {
  const currentAssets = bankBalance + cashOnHand + arTotal;
  const currentLiabilities = apTotal;
  const equity = currentAssets - currentLiabilities;
  const liquidity = currentLiabilities > 0 ? currentAssets / currentLiabilities : null;

  return {
    assets: { bank: bankBalance, cash: cashOnHand, accountsReceivable: arTotal, total: currentAssets },
    liabilities: { accountsPayable: apTotal, total: currentLiabilities },
    equity,
    liquidity
  };
}

function periodFilter(period) {
  const from = startOfPeriod(period);
  const to = endOfPeriod(period);
  return { from, to };
}

module.exports = {
  computeProfitabilityFromTransactions,
  computeARAPaging,
  computeCashFlow,
  computeExpensesByCategory,
  computeBalanceSheetMVP,
  periodFilter
};
