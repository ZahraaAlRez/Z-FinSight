// ============================================
// 🌐 LANGUAGE HELPER - Extract language from request
// Z-FinSight Backend
// ============================================
// Extracts language preference from:
// 1. Query parameter: ?lang=ar|en
// 2. Accept-Language header
// 3. Defaults to "en"

/**
 * Extract language from request
 * @param {Object} req - Express request object
 * @returns {string} - Language code ("ar" or "en")
 */
function extractLanguage(req) {
  // Priority 1: Query parameter
  if (req.query && req.query.lang) {
    const lang = req.query.lang.toLowerCase().trim();
    if (lang === 'ar' || lang === 'en') {
      return lang;
    }
  }

  // Priority 2: Accept-Language header
  if (req.headers && req.headers['accept-language']) {
    const acceptLang = req.headers['accept-language'].toLowerCase();
    
    // Check for Arabic
    if (acceptLang.includes('ar')) {
      return 'ar';
    }
    
    // Check for English
    if (acceptLang.includes('en')) {
      return 'en';
    }
  }

  // Priority 3: Default to English
  return 'en';
}

/**
 * Express middleware to add language to request object
 * Adds req.language = "ar" | "en"
 */
function languageMiddleware(req, res, next) {
  req.language = extractLanguage(req);
  next();
}

module.exports = {
  extractLanguage,
  languageMiddleware
};

