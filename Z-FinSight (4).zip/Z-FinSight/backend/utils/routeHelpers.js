// utils/routeHelpers.js

function getRole(req) {
  const u = req.user || {};
  // your token standardizes roles as array in requireAuth
  const roles = Array.isArray(u.roles) ? u.roles : [];
  const firstRole = roles[0] || u.role || u.userRole || "";
  return String(firstRole).toLowerCase();
}

// Use this ONLY if you want role checks inside route handlers.
// Prefer middleware requireRoles([...]) from authGuard.
function requireRole(allowed = []) {
  const set = allowed.map((x) => String(x).toLowerCase());
  return (req, res, next) => {
    const role = getRole(req);
    if (!set.includes(role)) {
      return res.status(403).json({ success: false, message: "Forbidden" });
    }
    next();
  };
}

// Finance tenant scoping:
// ✅ Prefer req.userCompanyId set by requireCompanyScope (authGuard)
// Fallback to req.user.companyId if scope middleware not used yet.
function pickCompanyId(req) {
  return (
    req.userCompanyId ||
    (req.user && req.user.companyId) ||
    null
  );
}

module.exports = {
  getRole,
  requireRole,
  pickCompanyId,
};
