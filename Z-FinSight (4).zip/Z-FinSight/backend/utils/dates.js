function toPeriod(dateObj) {
  const d = new Date(dateObj);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  return `${y}-${m}`;
}
function startOfPeriod(period) {
  if (period === "current" || !period) {
    const now = new Date();
    return new Date(Date.UTC(now.getFullYear(), now.getMonth(), 1, 0, 0, 0));
  }
  const [y, m] = period.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, 1, 0, 0, 0));
}
function endOfPeriod(period) {
  if (period === "current" || !period) {
    const now = new Date();
    return new Date(Date.UTC(now.getFullYear(), now.getMonth() + 1, 1, 0, 0, 0)); // exclusive
  }
  const [y, m] = period.split("-").map(Number);
  return new Date(Date.UTC(y, m, 1, 0, 0, 0)); // exclusive
}
function parseDateLoose(v) {
  if (!v) return null;
  if (v instanceof Date) return v;
  const s = String(v).trim();
  // Excel serial
  const n = Number(s);
  if (Number.isFinite(n) && n > 20000 && n < 60000) {
    // Excel date serial -> JS date
    const epoch = new Date(Date.UTC(1899, 11, 30));
    return new Date(epoch.getTime() + n * 86400000);
  }
  const d = new Date(s);
  if (!isNaN(d.getTime())) return d;
  return null;
}
module.exports = { toPeriod, startOfPeriod, endOfPeriod, parseDateLoose };
