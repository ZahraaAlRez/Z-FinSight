/**
 * Audit Logger
 * Tracks all user actions for security and compliance
 * 
 * Usage:
 * const { logAudit, AUDIT_ACTIONS } = require('./auditLogger');
 * 
 * await logAudit({
 *   userId: req.user.userId,
 *   companyId: req.user.companyId,
 *   action: AUDIT_ACTIONS.EXPENSE_CREATE,
 *   entityType: 'expense',
 *   entityId: expense._id,
 *   changes: { amount: 1000, description: 'Office supplies' },
 *   ipAddress: req.ip,
 *   userAgent: req.headers['user-agent'],
 * });
 */

const mongoose = require('mongoose');

// ============================================
// Audit Actions Constants
// ============================================
const AUDIT_ACTIONS = {
  // Authentication
  LOGIN: 'LOGIN',
  LOGOUT: 'LOGOUT',
  LOGIN_FAILED: 'LOGIN_FAILED',
  TOKEN_REFRESH: 'TOKEN_REFRESH',
  PASSWORD_CHANGE: 'PASSWORD_CHANGE',
  PASSWORD_RESET: 'PASSWORD_RESET',
  
  // User Management
  USER_CREATE: 'USER_CREATE',
  USER_UPDATE: 'USER_UPDATE',
  USER_DELETE: 'USER_DELETE',
  USER_VIEW: 'USER_VIEW',
  
  // Financial Data
  EXPENSE_CREATE: 'EXPENSE_CREATE',
  EXPENSE_UPDATE: 'EXPENSE_UPDATE',
  EXPENSE_DELETE: 'EXPENSE_DELETE',
  EXPENSE_VIEW: 'EXPENSE_VIEW',
  
  REVENUE_CREATE: 'REVENUE_CREATE',
  REVENUE_UPDATE: 'REVENUE_UPDATE',
  REVENUE_DELETE: 'REVENUE_DELETE',
  REVENUE_VIEW: 'REVENUE_VIEW',
  
  CASHFLOW_CREATE: 'CASHFLOW_CREATE',
  CASHFLOW_UPDATE: 'CASHFLOW_UPDATE',
  CASHFLOW_DELETE: 'CASHFLOW_DELETE',
  CASHFLOW_VIEW: 'CASHFLOW_VIEW',
  
  LOAN_CREATE: 'LOAN_CREATE',
  LOAN_UPDATE: 'LOAN_UPDATE',
  LOAN_DELETE: 'LOAN_DELETE',
  LOAN_VIEW: 'LOAN_VIEW',
  
  PAYROLL_CREATE: 'PAYROLL_CREATE',
  PAYROLL_UPDATE: 'PAYROLL_UPDATE',
  PAYROLL_DELETE: 'PAYROLL_DELETE',
  PAYROLL_VIEW: 'PAYROLL_VIEW',
  
  // Reports & Export
  REPORT_GENERATE: 'REPORT_GENERATE',
  REPORT_EXPORT: 'REPORT_EXPORT',
  DATA_EXPORT: 'DATA_EXPORT',
  
  // Company Management
  COMPANY_CREATE: 'COMPANY_CREATE',
  COMPANY_UPDATE: 'COMPANY_UPDATE',
  COMPANY_DELETE: 'COMPANY_DELETE',
  COMPANY_VIEW: 'COMPANY_VIEW',
  
  // Settings
  SETTINGS_UPDATE: 'SETTINGS_UPDATE',
  SETTINGS_VIEW: 'SETTINGS_VIEW',
};

// ============================================
// Audit Log Schema
// ============================================
const auditLogSchema = new mongoose.Schema({
  // Who
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    index: true,
  },
  adminId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Admin',
  },
  username: String,
  
  // Where
  companyId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Company',
    index: true,
  },
  companyCode: String,
  
  // What
  action: {
    type: String,
    required: true,
    enum: Object.values(AUDIT_ACTIONS),
    index: true,
  },
  entityType: {
    type: String,
    enum: ['user', 'company', 'expense', 'revenue', 'cashflow', 'loan', 'payroll', 'report', 'settings', 'other'],
  },
  entityId: {
    type: mongoose.Schema.Types.ObjectId,
  },
  
  // Details
  changes: mongoose.Schema.Types.Mixed, // Before/after data
  metadata: mongoose.Schema.Types.Mixed, // Additional context
  
  // Network Info
  ipAddress: String,
  userAgent: String,
  
  // Timing
  timestamp: {
    type: Date,
    default: Date.now,
    index: true,
  },
  
  // Status
  success: {
    type: Boolean,
    default: true,
  },
  errorMessage: String,
}, {
  timestamps: false, // We use custom timestamp field
});

// Indexes for efficient querying
auditLogSchema.index({ timestamp: -1 }); // Most recent first
auditLogSchema.index({ userId: 1, timestamp: -1 });
auditLogSchema.index({ companyId: 1, timestamp: -1 });
auditLogSchema.index({ action: 1, timestamp: -1 });

const AuditLog = mongoose.model('AuditLog', auditLogSchema);

// ============================================
// Audit Logger Functions
// ============================================

/**
 * Log an audit entry
 * @param {Object} data - Audit data
 * @returns {Promise<Object>} Created audit log
 */
async function logAudit(data) {
  try {
    const auditEntry = new AuditLog({
      userId: data.userId || null,
      adminId: data.adminId || null,
      username: data.username || null,
      companyId: data.companyId || null,
      companyCode: data.companyCode || null,
      action: data.action,
      entityType: data.entityType || 'other',
      entityId: data.entityId || null,
      changes: data.changes || null,
      metadata: data.metadata || null,
      ipAddress: data.ipAddress || null,
      userAgent: data.userAgent || null,
      success: data.success !== undefined ? data.success : true,
      errorMessage: data.errorMessage || null,
      timestamp: data.timestamp || new Date(),
    });

    await auditEntry.save();
    return auditEntry;
  } catch (err) {
    // Don't throw errors from audit logger - just log them
    console.error('Audit logging failed:', err);
    return null;
  }
}

/**
 * Express middleware to automatically log actions
 * @param {string} action - Action type
 * @param {Object} options - Additional options
 * @returns {Function} Express middleware
 */
function auditMiddleware(action, options = {}) {
  return async (req, res, next) => {
    // Store original send function
    const originalSend = res.send;

    // Override send to capture response
    res.send = function(data) {
      // Log audit after response is sent
      setImmediate(async () => {
        try {
          const success = res.statusCode >= 200 && res.statusCode < 300;
          
          await logAudit({
            userId: req.user?.userId || null,
            adminId: req.user?.adminId || null,
            username: req.user?.username || req.body?.username || null,
            companyId: req.user?.companyId || req.userCompanyId || null,
            companyCode: req.user?.companyCode || req.userCompanyCode || null,
            action,
            entityType: options.entityType || null,
            entityId: req.params?.id || null,
            changes: options.captureBody ? req.body : null,
            metadata: options.metadata || null,
            ipAddress: req.ip || req.connection?.remoteAddress || null,
            userAgent: req.headers['user-agent'] || null,
            success,
            errorMessage: success ? null : (typeof data === 'string' ? data : JSON.stringify(data)),
          });
        } catch (err) {
          console.error('Audit middleware error:', err);
        }
      });

      // Call original send
      return originalSend.call(this, data);
    };

    next();
  };
}

/**
 * Get audit logs with filters
 * @param {Object} filters - Query filters
 * @returns {Promise<Array>} Audit logs
 */
async function getAuditLogs(filters = {}) {
  const query = {};

  if (filters.userId) query.userId = filters.userId;
  if (filters.companyId) query.companyId = filters.companyId;
  if (filters.action) query.action = filters.action;
  if (filters.entityType) query.entityType = filters.entityType;
  if (filters.startDate || filters.endDate) {
    query.timestamp = {};
    if (filters.startDate) query.timestamp.$gte = new Date(filters.startDate);
    if (filters.endDate) query.timestamp.$lte = new Date(filters.endDate);
  }

  const limit = Math.min(filters.limit || 100, 1000);
  const skip = filters.skip || 0;

  return await AuditLog.find(query)
    .sort({ timestamp: -1 })
    .limit(limit)
    .skip(skip)
    .lean();
}

/**
 * Get audit statistics
 * @param {Object} filters - Query filters
 * @returns {Promise<Object>} Statistics
 */
async function getAuditStats(filters = {}) {
  const query = {};

  if (filters.companyId) query.companyId = filters.companyId;
  if (filters.startDate || filters.endDate) {
    query.timestamp = {};
    if (filters.startDate) query.timestamp.$gte = new Date(filters.startDate);
    if (filters.endDate) query.timestamp.$lte = new Date(filters.endDate);
  }

  const stats = await AuditLog.aggregate([
    { $match: query },
    {
      $group: {
        _id: '$action',
        count: { $sum: 1 },
        successCount: {
          $sum: { $cond: ['$success', 1, 0] }
        },
        failureCount: {
          $sum: { $cond: ['$success', 0, 1] }
        }
      }
    },
    { $sort: { count: -1 } }
  ]);

  return stats;
}

// ============================================
// Express Route (to add to your app)
// ============================================

/**
 * Example Express route for audit logs
 * 
 * router.get('/api/audit/logs', 
 *   requireAuth, 
 *   requireRoles(['admin']), 
 *   async (req, res) => {
 *     try {
 *       const logs = await getAuditLogs({
 *         companyId: req.user.companyId,
 *         startDate: req.query.startDate,
 *         endDate: req.query.endDate,
 *         limit: req.query.limit,
 *       });
 * 
 *       res.json({
 *         success: true,
 *         logs,
 *       });
 *     } catch (err) {
 *       res.status(500).json({
 *         success: false,
 *         message: 'Failed to fetch audit logs',
 *       });
 *     }
 *   }
 * );
 */

module.exports = {
  AUDIT_ACTIONS,
  AuditLog,
  logAudit,
  auditMiddleware,
  getAuditLogs,
  getAuditStats,
};