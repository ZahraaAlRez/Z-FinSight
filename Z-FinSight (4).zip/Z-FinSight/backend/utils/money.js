function n0(x) {
  const v = Number(x);
  return Number.isFinite(v) ? v : 0;
}
function abs2(x) {
  const v = n0(x);
  return Math.abs(v);
}
module.exports = { n0, abs2 };
