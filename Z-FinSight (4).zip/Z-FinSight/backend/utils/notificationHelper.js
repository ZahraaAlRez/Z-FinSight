// backend/utils/notificationHelpers.js

const Notification = require("../models/Notification");

/**
 * Helper functions to create common system notifications
 */

// ============================================
// Transaction-related notifications
// ============================================

async function notifyOverdueInvoice(companyId, invoice) {
  try {
    await Notification.createSystemNotification({
      companyId,
      type: "warning",
      title: "Invoice Overdue",
      message: `Invoice #${invoice.invoiceNumber || invoice._id} is ${getDaysOverdue(invoice.dueDate)} days overdue (${formatMoney(invoice.amount)}).`,
      link: `/transactions/${invoice._id}`,
      priority: "high",
      relatedModel: "Transaction",
      relatedId: invoice._id,
      expiresAt: null // Don't auto-expire
    });
  } catch (err) {
    console.error("Failed to create overdue invoice notification:", err);
  }
}

async function notifyBillDue(companyId, bill, daysUntilDue = 3) {
  try {
    await Notification.createSystemNotification({
      companyId,
      type: "warning",
      title: "Bill Due Soon",
      message: `Bill #${bill.billNumber || bill._id} is due in ${daysUntilDue} days (${formatMoney(bill.amount)}).`,
      link: `/transactions/${bill._id}`,
      priority: "medium",
      relatedModel: "Transaction",
      relatedId: bill._id,
      expiresAt: new Date(bill.dueDate) // Expire after due date
    });
  } catch (err) {
    console.error("Failed to create bill due notification:", err);
  }
}

async function notifyLargeTransaction(companyId, transaction, threshold = 10000) {
  try {
    if (transaction.amount < threshold) return;
    
    await Notification.createSystemNotification({
      companyId,
      type: "info",
      title: "Large Transaction Detected",
      message: `${transaction.type === 'income' ? 'Income' : 'Expense'} of ${formatMoney(transaction.amount)} was recorded.`,
      link: `/transactions/${transaction._id}`,
      priority: "medium",
      relatedModel: "Transaction",
      relatedId: transaction._id,
      expiresAt: getExpiry(7) // Expire after 7 days
    });
  } catch (err) {
    console.error("Failed to create large transaction notification:", err);
  }
}

// ============================================
// Reconciliation notifications
// ============================================

async function notifyUnreconciledTransactions(companyId, count) {
  try {
    if (count === 0) return;
    
    await Notification.createSystemNotification({
      companyId,
      type: "task",
      title: "Reconciliation Pending",
      message: `You have ${count} unreconciled transaction${count > 1 ? 's' : ''} waiting for review.`,
      link: "/reconcile",
      priority: "medium",
      expiresAt: getExpiry(30) // Expire after 30 days
    });
  } catch (err) {
    console.error("Failed to create reconciliation notification:", err);
  }
}

async function notifyReconciliationComplete(companyId, matched, total) {
  try {
    await Notification.createSystemNotification({
      companyId,
      type: "success",
      title: "Reconciliation Complete",
      message: `Bank reconciliation completed: ${matched}/${total} transactions matched.`,
      link: "/reconcile",
      priority: "low",
      expiresAt: getExpiry(7)
    });
  } catch (err) {
    console.error("Failed to create reconciliation complete notification:", err);
  }
}

// ============================================
// KPI/Report notifications
// ============================================

async function notifyKPIPublished(companyId, period, userId = null) {
  try {
    await Notification.createSystemNotification({
      companyId,
      userId,
      type: "success",
      title: "KPI Snapshot Published",
      message: `Financial KPIs for ${period} have been published and are now available.`,
      link: "/overview",
      priority: "low",
      expiresAt: getExpiry(7)
    });
  } catch (err) {
    console.error("Failed to create KPI published notification:", err);
  }
}

async function notifyLowCashBalance(companyId, balance, threshold = 5000) {
  try {
    if (balance >= threshold) return;
    
    await Notification.createSystemNotification({
      companyId,
      type: "warning",
      title: "Low Cash Balance",
      message: `Your cash balance is low (${formatMoney(balance)}). Consider reviewing upcoming expenses.`,
      link: "/overview",
      priority: "high",
      expiresAt: getExpiry(3)
    });
  } catch (err) {
    console.error("Failed to create low cash notification:", err);
  }
}

// ============================================
// User/System notifications
// ============================================

async function notifyNewUser(companyId, userName, role) {
  try {
    await Notification.createSystemNotification({
      companyId,
      type: "info",
      title: "New User Added",
      message: `${userName} has been added to your team as ${role}.`,
      link: "/settings",
      priority: "low",
      expiresAt: getExpiry(7)
    });
  } catch (err) {
    console.error("Failed to create new user notification:", err);
  }
}

async function notifySystemUpdate(companyId, updateMessage) {
  try {
    await Notification.createSystemNotification({
      companyId,
      type: "info",
      title: "System Update",
      message: updateMessage,
      link: null,
      priority: "low",
      expiresAt: getExpiry(14)
    });
  } catch (err) {
    console.error("Failed to create system update notification:", err);
  }
}

// ============================================
// Helper utilities
// ============================================

function getDaysOverdue(dueDate) {
  const now = new Date();
  const due = new Date(dueDate);
  const diffMs = now - due;
  return Math.floor(diffMs / (1000 * 60 * 60 * 24));
}

function formatMoney(amount, currency = "USD") {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: currency
  }).format(amount);
}

function getExpiry(days) {
  const date = new Date();
  date.setDate(date.getDate() + days);
  return date;
}

// ============================================
// Bulk notification creation
// ============================================

async function createMonthEndReminders(companyId) {
  try {
    // Check if it's near month end (last 5 days)
    const now = new Date();
    const lastDayOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    const daysUntilMonthEnd = Math.ceil((lastDayOfMonth - now) / (1000 * 60 * 60 * 24));
    
    if (daysUntilMonthEnd > 5) return;
    
    await Notification.createSystemNotification({
      companyId,
      type: "task",
      title: "Month-End Closing Approaching",
      message: `${daysUntilMonthEnd} days until month-end. Review uncategorized transactions and pending reconciliations.`,
      link: "/transactions",
      priority: "high",
      expiresAt: lastDayOfMonth
    });
  } catch (err) {
    console.error("Failed to create month-end reminder:", err);
  }
}

// ============================================
// Exports
// ============================================

module.exports = {
  // Transaction notifications
  notifyOverdueInvoice,
  notifyBillDue,
  notifyLargeTransaction,
  
  // Reconciliation notifications
  notifyUnreconciledTransactions,
  notifyReconciliationComplete,
  
  // KPI/Report notifications
  notifyKPIPublished,
  notifyLowCashBalance,
  
  // User/System notifications
  notifyNewUser,
  notifySystemUpdate,
  
  // Bulk operations
  createMonthEndReminders,
};