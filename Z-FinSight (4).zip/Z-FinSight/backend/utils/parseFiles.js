const XLSX = require("xlsx");
const { parse } = require("csv-parse/sync");
const { parseDateLoose } = require("./dates");
const { n0 } = require("./money");

function normalizeHeader(h) {
  return String(h || "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "_")
    .replace(/[^\w_]/g, "");
}

function mapRowToTransaction(row, companyId, uploadId) {
  // Supported common columns:
  // date, description, memo, amount, type, category, currency, status, due_date, direction
  const get = (k) => row[k] ?? row[normalizeHeader(k)];

  const rawDate = get("date") || get("transaction_date") || get("posting_date");
  const date = parseDateLoose(rawDate) || new Date();

  let amount = n0(get("amount") || get("value") || get("total"));
  const rawType = String(get("type") || "").toLowerCase();
  const rawDir = String(get("direction") || "").toLowerCase();

  // If sheet uses negative for expense/out, convert to positive and derive type
  let type = rawType;
  if (!type) {
    if (rawDir === "out" || amount < 0) type = "expense";
    else type = "revenue";
  }
  if (amount < 0) amount = Math.abs(amount);

  const currency = String(get("currency") || "USD").trim().toUpperCase();
  const category = String(get("category") || "").trim();
  const description = String(get("description") || get("memo") || get("details") || "").trim();

  const status = String(get("status") || "open").trim().toLowerCase();
  const dueDate = parseDateLoose(get("due_date") || get("due") || "");

  // invoice/bill detection
  if (String(get("invoice") || "").toLowerCase() === "yes") type = "invoice";
  if (String(get("bill") || "").toLowerCase() === "yes") type = "bill";

  return {
    companyId,
    uploadId,
    source: "import",
    type,
    date,
    amount,
    currency,
    category,
    description,
    status,
    dueDate: dueDate || undefined
  };
}

function parseXlsxToRows(buffer) {
  const wb = XLSX.read(buffer, { type: "buffer" });
  const sheetName = wb.SheetNames[0];
  const ws = wb.Sheets[sheetName];
  const json = XLSX.utils.sheet_to_json(ws, { defval: "" });
  // normalize headers
  return json.map((r) => {
    const out = {};
    Object.keys(r).forEach((k) => (out[normalizeHeader(k)] = r[k]));
    return out;
  });
}

function parseCsvToRows(buffer) {
  const text = buffer.toString("utf8");
  const records = parse(text, {
    columns: true,
    skip_empty_lines: true,
    trim: true
  });
  return records.map((r) => {
    const out = {};
    Object.keys(r).forEach((k) => (out[normalizeHeader(k)] = r[k]));
    return out;
  });
}

module.exports = {
  parseXlsxToRows,
  parseCsvToRows,
  mapRowToTransaction
};
