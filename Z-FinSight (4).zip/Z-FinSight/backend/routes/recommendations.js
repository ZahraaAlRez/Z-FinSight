// backend/routes/recommendations.js
const express = require("express");
const Recommendation = require("../models/Recommendation"); // Make sure this model exists

const {
  requireAuth,
  requireRoles,
  requireCompanyScope,
} = require("../middleware/authGuard");

const router = express.Router();

// Helper function to get company public code from JWT token
async function getCompanyPublicCode(req) {
  const companyCode = req.userCompanyCode;
  if (companyCode) return companyCode;
  
  const companyDbId = req.userCompanyId;
  if (companyDbId) {
    const Company = require("../models/Company");
    const company = await Company.findById(companyDbId).lean();
    if (company) {
      return company.companyId; // Public code
    }
  }
  return null;
}

// ============================================
// GET /api/recommendations - List recommendations
// ============================================
router.get(
  "/",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager", "financial", "external"]),
  async (req, res) => {
    try {
      // ✅ SECURITY: Use companyId from JWT token only
      // Recommendation model uses public company code (String), not MongoDB ObjectId
      const companyDbId = req.userCompanyId; // MongoDB ObjectId
      const companyCode = req.userCompanyCode; // Public code like "CMP_001"
      
      if (!companyDbId && !companyCode) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      // Recommendation model uses public company code (String)
      // If we have companyCode, use it; otherwise fetch it from Company model
      let companyId = companyCode;
      if (!companyId && companyDbId) {
        const Company = require("../models/Company");
        const company = await Company.findById(companyDbId).lean();
        if (company) {
          companyId = company.companyId; // Public code
        }
      }
      
      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "Could not resolve company code",
        });
      }

      // Query params
      const type = req.query.type; // "internal" or "external"
      const status = req.query.status;
      const priority = req.query.priority;
      const category = req.query.category;
      const sourceType = req.query.sourceType;
      const limit = Math.min(parseInt(req.query.limit || "50", 10), 200);
      const page = Math.max(parseInt(req.query.page || "1", 10), 1);
      const skip = (page - 1) * limit;

      // Build query
      const query = { companyId };
      if (type) query.type = type;
      if (status) query.status = status;
      if (priority) query.priority = priority;
      if (category) query.category = category;
      if (sourceType) query.sourceType = sourceType;

      // Execute query with priority-based sorting
      // Critical/High first, then by creation date
      const priorityOrder = { Critical: 1, High: 2, Medium: 3, Low: 4 };
      const [items, total] = await Promise.all([
        Recommendation.find(query)
          .sort({ 
            priority: 1, // Custom sort by priority enum order
            createdAt: -1 
          })
          .skip(skip)
          .limit(limit)
          .lean(),
        Recommendation.countDocuments(query),
      ]);
      
      // Sort items by priority (Critical > High > Medium > Low)
      items.sort((a, b) => {
        const aPriority = priorityOrder[a.priority] || 99;
        const bPriority = priorityOrder[b.priority] || 99;
        if (aPriority !== bPriority) return aPriority - bPriority;
        return new Date(b.createdAt) - new Date(a.createdAt);
      });

      res.json({
        success: true,
        items,
        total,
        page,
        limit,
      });
    } catch (err) {
      console.error("recommendations list error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// ============================================
// POST /api/recommendations - Create a new recommendation
// ============================================
router.post(
  "/",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager"]),
  async (req, res) => {
    try {
      // ✅ SECURITY: Use companyId from JWT token only
      const companyDbId = req.userCompanyId;
      const companyCode = req.userCompanyCode;
      
      if (!companyDbId && !companyCode) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      // Get public company code
      let companyId = companyCode;
      if (!companyId && companyDbId) {
        const Company = require("../models/Company");
        const company = await Company.findById(companyDbId).lean();
        if (company) {
          companyId = company.companyId;
        }
      }
      
      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "Could not resolve company code",
        });
      }

      const { type, title, summary, priority, category, sourceType } = req.body || {};

      if (!title || !title.trim()) {
        return res.status(400).json({
          success: false,
          message: "title is required",
        });
      }

      // Map priority to enum values (accept lowercase)
      const priorityMap = {
        low: "Low",
        medium: "Medium",
        high: "High",
        critical: "Critical"
      };
      const normalizedPriority = priorityMap[priority?.toLowerCase()] || priority || "Medium";

      // Map type to enum values
      const normalizedType = type === "internal" ? "internal" : (type === "external" ? "external" : "internal");

      // Create recommendation
      const recommendation = await Recommendation.create({
        companyId,
        type: normalizedType,
        sourceType: sourceType || "financial",
        sourceTitle: "Manual Entry",
        category: category || "Financial Planning",
        priority: normalizedPriority,
        impact: normalizedPriority === "Critical" || normalizedPriority === "High" ? "High" : "Medium",
        title: title.trim(),
        insight: summary?.trim() || "",
        recommendations: summary?.trim() ? [summary.trim()] : [],
        opportunities: [],
        risks: [],
        status: "new",
        aiAnalysis: {
          confidence: 100, // Manual entry is 100% confidence
          reasoning: "Manually created by user"
        }
      });

      res.json({
        success: true,
        item: recommendation
      });
    } catch (err) {
      console.error("create recommendation error:", err);
      res.status(500).json({ 
        success: false, 
        message: "Server error",
        error: err.message 
      });
    }
  }
);

// ============================================
// GET /api/recommendations/stats - Get recommendation statistics
// ============================================
router.get(
  "/stats",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager", "financial"]),
  async (req, res) => {
    try {
      // ✅ Use companyId from JWT token
      const companyDbId = req.userCompanyId;
      const companyCode = req.userCompanyCode;
      
      if (!companyDbId && !companyCode) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      // Get public company code
      let companyId = companyCode;
      if (!companyId && companyDbId) {
        const Company = require("../models/Company");
        const company = await Company.findById(companyDbId).lean();
        if (company) {
          companyId = company.companyId;
        }
      }
      
      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "Could not resolve company code",
        });
      }

      // Use model's static method for stats
      const stats = await Recommendation.getStats(companyId);
      
      // Additional stats
      const [total, bySourceType] = await Promise.all([
        Recommendation.countDocuments({ companyId }),
        Recommendation.aggregate([
          { $match: { companyId } },
          {
            $group: {
              _id: '$sourceType',
              count: { $sum: 1 }
            }
          }
        ])
      ]);
      
      const byCategory = await Recommendation.aggregate([
        { $match: { companyId } },
        {
          $group: {
            _id: '$category',
            count: { $sum: 1 }
          }
        },
        { $sort: { count: -1 } }
      ]);

      res.json({
        success: true,
        stats: {
          total,
          byStatus: stats.byStatus || {},
          byPriority: stats.byPriority || {},
          bySourceType: bySourceType.reduce((acc, stat) => {
            acc[stat._id] = stat.count;
            return acc;
          }, {}),
          byCategory: byCategory.reduce((acc, stat) => {
            acc[stat._id] = stat.count;
            return acc;
          }, {}),
        },
      });
    } catch (err) {
      console.error("recommendations stats error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// ============================================
// GET /api/recommendations/:id - Get single recommendation
// ============================================
router.get(
  "/:id",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager", "financial", "external"]),
  async (req, res) => {
    try {
      const companyDbId = req.userCompanyId;
      const companyCode = req.userCompanyCode;
      
      if (!companyDbId && !companyCode) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      // Get public company code
      let companyId = companyCode;
      if (!companyId && companyDbId) {
        const Company = require("../models/Company");
        const company = await Company.findById(companyDbId).lean();
        if (company) {
          companyId = company.companyId;
        }
      }
      
      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "Could not resolve company code",
        });
      }

      const id = req.params.id;

      const item = await Recommendation.findOne({
        _id: id,
        companyId, // ✅ Must match user's company (public code)
      }).lean();

      if (!item) {
        return res.status(404).json({
          success: false,
          message: "Recommendation not found",
        });
      }

      res.json({
        success: true,
        item,
      });
    } catch (err) {
      console.error("recommendation get error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// ============================================
// POST /api/recommendations/generate/news - Generate recommendations from news
// ============================================
router.post(
  "/generate/news",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin"]),
  async (req, res) => {
    try {
      const companyDbId = req.userCompanyId;
      const companyCode = req.userCompanyCode;

      if (!companyDbId && !companyCode) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      // Get public company code and company object
      let companyId = companyCode;
      let company = null;
      if (companyDbId) {
        const Company = require("../models/Company");
        company = await Company.findById(companyDbId).lean();
        if (company) {
          companyId = company.companyId;
        }
      }
      
      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "Could not resolve company code",
        });
      }

      // TODO: Implement news-based recommendation generation
      // This would typically:
      // 1. Fetch recent financial news
      // 2. Analyze relevance to company
      // 3. Create recommendations

      res.json({
        success: true,
        message: "News recommendations generation not yet implemented",
        generated: 0,
      });
    } catch (err) {
      console.error("generate news recommendations error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// ============================================
// POST /api/recommendations/generate/bulk - Generate bulk recommendations
// ============================================
router.post(
  "/generate/bulk",
  requireAuth,
  requireCompanyScope,
  requireRoles(["admin"]),
  async (req, res) => {
    try {
      const companyDbId = req.userCompanyId;
      const companyCode = req.userCompanyCode;

      if (!companyDbId && !companyCode) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      // Get public company code
      let companyId = companyCode;
      if (!companyId && companyDbId) {
        const Company = require("../models/Company");
        const company = await Company.findById(companyDbId).lean();
        if (company) {
          companyId = company.companyId;
        }
      }
      
      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "Could not resolve company code",
        });
      }

      // TODO: Implement bulk recommendation generation
      // This would typically analyze company data and create multiple recommendations

      res.json({
        success: true,
        message: "Bulk recommendations generation not yet implemented",
        generated: 0,
      });
    } catch (err) {
      console.error("generate bulk recommendations error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// ============================================
// PATCH /api/recommendations/:id/status - Update recommendation status
// ============================================
router.patch(
  "/:id/status",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager"]),
  async (req, res) => {
    try {
      const companyDbId = req.userCompanyId;
      const companyCode = req.userCompanyCode;
      const id = req.params.id;
      const { status } = req.body || {};

      if (!companyDbId && !companyCode) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      if (!status) {
        return res.status(400).json({
          success: false,
          message: "status is required",
        });
      }

      // Get public company code
      let companyId = companyCode;
      if (!companyId && companyDbId) {
        const Company = require("../models/Company");
        const company = await Company.findById(companyDbId).lean();
        if (company) {
          companyId = company.companyId;
        }
      }
      
      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "Could not resolve company code",
        });
      }

      // Build update object with timestamps
      const update = { status };
      if (status === 'viewed' && !req.body.viewedAt) {
        update.viewedAt = new Date();
      } else if (status === 'implemented' && !req.body.implementedAt) {
        update.implementedAt = new Date();
      } else if (status === 'dismissed' && !req.body.dismissedAt) {
        update.dismissedAt = new Date();
      }

      // Update only if belongs to user's company
      const item = await Recommendation.findOneAndUpdate(
        { _id: id, companyId },
        update,
        { new: true }
      ).lean();

      if (!item) {
        return res.status(404).json({
          success: false,
          message: "Recommendation not found",
        });
      }

      res.json({
        success: true,
        item,
      });
    } catch (err) {
      console.error("recommendation status update error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// ============================================
// PATCH /api/recommendations/:id/notes - Update recommendation notes
// ============================================
router.patch(
  "/:id/notes",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager", "financial"]),
  async (req, res) => {
    try {
      const companyDbId = req.userCompanyId;
      const companyCode = req.userCompanyCode;
      const id = req.params.id;
      const { notes } = req.body || {};

      if (!companyDbId && !companyCode) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      // Get public company code
      let companyId = companyCode;
      if (!companyId && companyDbId) {
        const Company = require("../models/Company");
        const company = await Company.findById(companyDbId).lean();
        if (company) {
          companyId = company.companyId;
        }
      }
      
      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "Could not resolve company code",
        });
      }

      // Update only if belongs to user's company
      const item = await Recommendation.findOneAndUpdate(
        { _id: id, companyId },
        { notes },
        { new: true }
      ).lean();

      if (!item) {
        return res.status(404).json({
          success: false,
          message: "Recommendation not found",
        });
      }

      res.json({
        success: true,
        item,
      });
    } catch (err) {
      console.error("recommendation notes update error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// ============================================
// PATCH /api/recommendations/:id/feedback - Add feedback to recommendation
// ============================================
router.patch(
  "/:id/feedback",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager", "financial", "external"]),
  async (req, res) => {
    try {
      const companyDbId = req.userCompanyId;
      const companyCode = req.userCompanyCode;
      const id = req.params.id;
      const { feedback } = req.body || {};

      if (!companyDbId && !companyCode) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      // Get public company code
      let companyId = companyCode;
      if (!companyId && companyDbId) {
        const Company = require("../models/Company");
        const company = await Company.findById(companyDbId).lean();
        if (company) {
          companyId = company.companyId;
        }
      }
      
      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "Could not resolve company code",
        });
      }

      // Update only if belongs to user's company
      const item = await Recommendation.findOneAndUpdate(
        { _id: id, companyId },
        { feedback },
        { new: true }
      ).lean();

      if (!item) {
        return res.status(404).json({
          success: false,
          message: "Recommendation not found",
        });
      }

      res.json({
        success: true,
        item,
      });
    } catch (err) {
      console.error("recommendation feedback update error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// ============================================
// DELETE /api/recommendations/:id - Delete recommendation
// ============================================
router.delete(
  "/:id",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin"]),
  async (req, res) => {
    try {
      const companyDbId = req.userCompanyId;
      const companyCode = req.userCompanyCode;
      const id = req.params.id;

      if (!companyDbId && !companyCode) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      // Get public company code
      let companyId = companyCode;
      if (!companyId && companyDbId) {
        const Company = require("../models/Company");
        const company = await Company.findById(companyDbId).lean();
        if (company) {
          companyId = company.companyId;
        }
      }
      
      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "Could not resolve company code",
        });
      }

      // Delete only if belongs to user's company
      const deleted = await Recommendation.findOneAndDelete({
        _id: id,
        companyId,
      }).lean();

      if (!deleted) {
        return res.status(404).json({
          success: false,
          message: "Recommendation not found",
        });
      }

      res.json({
        success: true,
      });
    } catch (err) {
      console.error("recommendation delete error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// ============================================
// DELETE /api/recommendations/cleanup/:companyId - Cleanup old recommendations (ADMIN ONLY)
// ============================================
router.delete(
  "/cleanup/:companyId",
  requireAuth,
  requireCompanyScope,
  requireRoles(["admin"]),
  async (req, res) => {
    try {
      // ✅ Use companyId from JWT, ignore URL param
      const companyDbId = req.userCompanyId;
      const companyCode = req.userCompanyCode;

      if (!companyDbId && !companyCode) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      // Get public company code
      let companyId = companyCode;
      if (!companyId && companyDbId) {
        const Company = require("../models/Company");
        const company = await Company.findById(companyDbId).lean();
        if (company) {
          companyId = company.companyId;
        }
      }
      
      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "Could not resolve company code",
        });
      }

      // Delete old recommendations (e.g., older than 90 days)
      const ninetyDaysAgo = new Date();
      ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);

      const result = await Recommendation.deleteMany({
        companyId,
        createdAt: { $lte: ninetyDaysAgo },
      });

      res.json({
        success: true,
        deleted: result.deletedCount,
      });
    } catch (err) {
      console.error("recommendations cleanup error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

module.exports = router;