const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");

// Import all models to ensure they're registered
const Company = require("../models/Company");
const Admin = require("../models/Admin");
const User = require("../models/User");
const VerificationCode = require("../models/VerificationCode");
const Recommendation = require("../models/Recommendation");
const NewsItem = require("../models/NewsItem");
const TopCompaniesSnapshot = require("../models/TopCompaniesSnapshot");
const FxRateSnapshot = require("../models/FxRateSnapshot");

// Collections to reset (using lowercase plural names as MongoDB stores them)
const COLLECTIONS_TO_RESET = [
  "companies",
  "admins",
  "users",
  "verificationcodes",
  "recommendations",
  "newsitems",
  "topcompaniessnapshots",
  "fxratesnapshots",
];

// ============================================
// POST /api/dev/reset - DEV-only reset endpoint
// ============================================
router.post("/reset", async (req, res) => {
  try {
    // 1) Check environment: only allow in non-production
    if (process.env.NODE_ENV === "production") {
      return res.status(403).json({
        success: false,
        message: "Reset endpoint is disabled in production",
      });
    }

    // 2) Check secret header
    const resetKey = req.headers["x-dev-reset-key"];
    if (resetKey !== "zfinsight-reset-2026") {
      return res.status(401).json({
        success: false,
        message: "Invalid or missing reset key",
      });
    }

    // 3) Get database instance
    const db = mongoose.connection.db;
    if (!db) {
      return res.status(500).json({
        success: false,
        message: "Database connection not available",
      });
    }

    // 4) Get collection counts before deletion
    console.log("📋 DEV Reset: Checking collections...");
    const beforeCounts = {};
    for (const collectionName of COLLECTIONS_TO_RESET) {
      try {
        const collection = db.collection(collectionName);
        const count = await collection.countDocuments();
        beforeCounts[collectionName] = count;
      } catch (err) {
        beforeCounts[collectionName] = 0;
      }
    }

    const totalBefore = Object.values(beforeCounts).reduce((sum, count) => sum + count, 0);
    console.log(`📊 Total documents to delete: ${totalBefore}`);

    // 5) Delete all documents from each collection
    const results = {};
    let totalDeleted = 0;

    for (const collectionName of COLLECTIONS_TO_RESET) {
      try {
        const collection = db.collection(collectionName);
        const count = beforeCounts[collectionName] || 0;
        
        if (count > 0) {
          const deleteResult = await collection.deleteMany({});
          const deletedCount = deleteResult.deletedCount || 0;
          results[collectionName] = deletedCount;
          totalDeleted += deletedCount;
          console.log(`   ✔ ${collectionName}: ${deletedCount} documents deleted`);
        } else {
          results[collectionName] = 0;
        }
      } catch (err) {
        results[collectionName] = "error";
        console.warn(`   ⚠  ${collectionName}: error - ${err.message}`);
      }
    }

    console.log("✅ DEV Reset completed:");
    console.log(`   Total documents deleted: ${totalDeleted}`);
    console.log(`   ✔ Users cleared: ${results.users || 0}`);
    console.log(`   ✔ Companies cleared: ${results.companies || 0}`);
    console.log("   System reset completed - Next company will be CMP_001");

    // 6) The company counter will automatically reset to CMP_001
    // because the pre-save hook in Company model finds the last companyId
    // and when no companies exist, it will default to CMP_001

    return res.json({
      success: true,
      message: "DB reset complete",
      details: {
        totalDeleted,
        collections: results,
      },
    });
  } catch (err) {
    console.error("❌ DEV Reset error:", err);
    return res.status(500).json({
      success: false,
      message: "Reset failed",
      error: err.message,
    });
  }
});

module.exports = router;
