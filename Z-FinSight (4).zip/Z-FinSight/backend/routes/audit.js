const express = require("express");
const {
  requireAuth,
  requireRoles,
  requireAdmin,
} = require("../middleware/authGuard");
const { getAuditLogs } = require("../utils/auditLogger");

const router = express.Router();

// ============================================
// GET /api/audit/logs - Get audit logs (admin only)
// ============================================
router.get(
  "/logs",
  requireAuth,
  requireRoles(["admin"]), // Allow company admins too
  async (req, res) => {
    try {
      const {
        action,
        entityType,
        startDate,
        endDate,
        userId,
        companyId,
        limit = 100,
        page = 1,
      } = req.query;

      const filters = {};
      
      // If user is not system admin, only show logs for their company
      const isSystemAdmin = req.user.isAdmin && req.user.adminId;
      if (!isSystemAdmin && req.userCompanyId) {
        filters.companyId = req.userCompanyId;
      } else if (companyId) {
        filters.companyId = companyId;
      }
      
      if (action) filters.action = action;
      if (entityType) filters.entityType = entityType;
      if (userId) filters.userId = userId;
      if (startDate) filters.startDate = new Date(startDate);
      if (endDate) filters.endDate = new Date(endDate);

      const pageNum = Math.max(parseInt(page, 10), 1);
      const limitNum = Math.min(parseInt(limit, 10), 500);
      const skip = (pageNum - 1) * limitNum;

      const logs = await getAuditLogs({
        ...filters,
        limit: limitNum,
        skip: skip,
      });
      
      // Get total count for pagination
      const AuditLog = require("../utils/auditLogger").AuditLog;
      const countQuery = {};
      if (filters.userId) countQuery.userId = filters.userId;
      if (filters.companyId) countQuery.companyId = filters.companyId;
      if (filters.action) countQuery.action = filters.action;
      if (filters.entityType) countQuery.entityType = filters.entityType;
      if (filters.startDate || filters.endDate) {
        countQuery.timestamp = {};
        if (filters.startDate) countQuery.timestamp.$gte = new Date(filters.startDate);
        if (filters.endDate) countQuery.timestamp.$lte = new Date(filters.endDate);
      }
      const total = await AuditLog.countDocuments(countQuery);

      res.json({
        success: true,
        logs: logs || [],
        total: total,
        page: pageNum,
        limit: limitNum,
      });
    } catch (err) {
      console.error("audit logs error:", err);
      res.status(500).json({
        success: false,
        message: "Server error",
      });
    }
  }
);

module.exports = router;
