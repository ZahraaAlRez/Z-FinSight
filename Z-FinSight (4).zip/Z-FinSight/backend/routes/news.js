const express = require("express");
const router = express.Router();

const Company = require("../models/Company");
// ✅ FIXED: Changed from Newstem to NewsItem
const NewsItem = require("../models/NewsItem");
const { extractLanguage } = require("../utils/langHelper");
const newsProvider = require("../services/newsProvider");
const {
  requireAuth,
  requireCompanyScope,
  requireRoles,
} = require("../middleware/authGuard");

function pickCompanyId(req) {
  return (req.query.companyId || req.params.companyId || "").trim();
}

// GET /api/news?companyId=CMP_007&limit=20&lang=ar|en
router.get("/", async (req, res) => {
  try {
    const companyPublicId = pickCompanyId(req);
    const limit = Math.min(parseInt(req.query.limit || "20", 10), 100);

    if (!companyPublicId) {
      return res.status(400).json({ ok: false, message: "companyId is required" });
    }

    const company = await Company.findOne({ companyId: companyPublicId });
    if (!company) {
      return res.status(404).json({ ok: false, message: "Company not found" });
    }

    // ✅ Extract language preference
    const language = extractLanguage(req);
    
    // If company has stored language and no explicit lang param, use company's preference
    const effectiveLang = req.query.lang ? language : (company.language || language);

    // Get news for this company AND news from other companies in the system
    const allCompanies = await Company.find({ isActive: true }).select('companyId').lean();
    const allCompanyIds = allCompanies.map(c => c.companyId);
    
    // Get news from all companies
    let items = await NewsItem.find({ 
      companyId: { $in: allCompanyIds }
    })
      .sort({ publishedAt: -1, createdAt: -1 })
      .limit(limit * 2) // Get more to allow sorting
      .lean();
    
    // Prioritize current company's news by sorting
    items.sort((a, b) => {
      // Current company's news first
      if (a.companyId === companyPublicId && b.companyId !== companyPublicId) return -1;
      if (a.companyId !== companyPublicId && b.companyId === companyPublicId) return 1;
      // Then by date
      return new Date(b.publishedAt || b.createdAt) - new Date(a.publishedAt || a.createdAt);
    });
    
    // Limit to requested amount
    items = items.slice(0, limit);

    // ✅ Translate items if needed (for mock data or if stored content needs translation)
    const translatedItems = await Promise.all(
      items.map(async (item) => {
        // If item was stored in English and user wants Arabic, translate
        // For now, we return as-is since real news providers handle language
        // But we can add translation logic here if needed
        return item;
      })
    );

    const lastUpdated =
      items.length > 0
        ? (items[0].fetchedAt || items[0].updatedAt || items[0].createdAt || null)
        : null;

    return res.json({
      ok: true,
      data: translatedItems,
      meta: {
        companyId: companyPublicId,
        source: items.length ? "cache" : "empty",
        lastUpdated,
        language: effectiveLang, // ✅ Include language in response
      },
    });
  } catch (err) {
    console.error("❌ /api/news error:", err);
    return res.status(500).json({ ok: false, message: "Server error" });
  }
});

// GET /api/news/sentiment - Get sentiment trend over time
router.get(
  "/sentiment",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager", "financial"]),
  async (req, res) => {
    try {
      // Get companyId (public code)
      let companyId = req.userCompanyCode;
      
      if (!companyId && req.userCompanyId) {
        const company = await Company.findById(req.userCompanyId).select("companyId").lean();
        if (company) {
          companyId = company.companyId;
        }
      }

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      // Get range parameter (7d, 30d, 90d)
      const range = req.query.range || "30d";
      const days = parseInt(range.replace("d", ""), 10) || 30;
      const maxDays = Math.min(days, 90); // Cap at 90 days

      // Calculate date range
      const now = new Date();
      const startDate = new Date(now);
      startDate.setDate(startDate.getDate() - maxDays);
      startDate.setHours(0, 0, 0, 0);

      // Determine aggregation interval
      // 7d: daily, 30d: weekly, 90d: weekly
      const isDaily = maxDays <= 7;

      // Get news items in range
      const newsItems = await NewsItem.find({
        companyId,
        publishedAt: { $gte: startDate }
      })
        .select("sentiment publishedAt")
        .sort({ publishedAt: 1 })
        .lean();

      if (newsItems.length === 0) {
        return res.json({
          success: true,
          data: [],
          range
        });
      }

      // Map sentiment string to numeric score
      const sentimentToScore = (sentiment) => {
        const s = String(sentiment || "neutral").toLowerCase();
        if (s === "positive") return 1;
        if (s === "negative") return -1;
        return 0; // neutral
      };

      // Group by date (daily or weekly)
      const groupedData = {};

      newsItems.forEach(item => {
        const date = new Date(item.publishedAt || item.createdAt);
        let periodKey;

        if (isDaily) {
          // Daily aggregation
          periodKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
        } else {
          // Weekly aggregation - get week start (Monday)
          const weekStart = new Date(date);
          const dayOfWeek = weekStart.getDay();
          const diff = weekStart.getDate() - dayOfWeek + (dayOfWeek === 0 ? -6 : 1); // Adjust to Monday
          weekStart.setDate(diff);
          periodKey = `${weekStart.getFullYear()}-${String(weekStart.getMonth() + 1).padStart(2, "0")}-${String(weekStart.getDate()).padStart(2, "0")}`;
        }

        if (!groupedData[periodKey]) {
          groupedData[periodKey] = {
            date: periodKey,
            scores: [],
            count: 0
          };
        }

        const score = sentimentToScore(item.sentiment);
        groupedData[periodKey].scores.push(score);
        groupedData[periodKey].count++;
      });

      // Calculate average score per period
      const timeseries = Object.keys(groupedData)
        .sort()
        .map(period => {
          const periodData = groupedData[period];
          const avgScore = periodData.scores.length > 0
            ? periodData.scores.reduce((sum, s) => sum + s, 0) / periodData.scores.length
            : 0;

          return {
            date: periodData.date,
            score: Math.round(avgScore * 100) / 100, // Round to 2 decimals
            count: periodData.count
          };
        });

      res.json({
        success: true,
        data: timeseries,
        range
      });
    } catch (err) {
      console.error("news sentiment error:", err);
      res.status(500).json({
        success: false,
        message: "Server error",
        error: err.message
      });
    }
  }
);

module.exports = router;