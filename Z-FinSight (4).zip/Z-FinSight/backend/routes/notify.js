const express = require("express");
const nodemailer = require("nodemailer");

const router = express.Router();

function requireEnv(name) {
  if (!process.env[name]) throw new Error(`${name} is missing in .env`);
  return process.env[name];
}

function buildTransporter() {
  const host = requireEnv("SMTP_HOST");
  const port = Number(requireEnv("SMTP_PORT"));
  const user = requireEnv("SMTP_USER");
  const pass = requireEnv("SMTP_PASS");

  return nodemailer.createTransport({
    host,
    port,
    secure: port === 465,
    auth: { user, pass },
  });
}

// POST /api/notify/credentials
// body: { toEmail, fullName, companyId, username, password, roles, department }
router.post("/credentials", async (req, res) => {
  try {
    const {
      toEmail,
      fullName,
      companyId,
      username,
      password,
      roles,
      department,
    } = req.body;

    if (!toEmail || !username || !password) {
      return res.status(400).json({ success: false, message: "Missing required fields" });
    }

    const transporter = buildTransporter();
    const from = process.env.SMTP_FROM || process.env.SMTP_USER;

    const roleText = Array.isArray(roles) ? roles.join(", ") : String(roles || "");
    const subject = `Your Z-FinSight Account Credentials`;

    const text =
`Hello ${fullName || ""},

Your account has been created successfully.

Company ID: ${companyId || ""}
Username: ${username}
Temporary Password: ${password}
Department: ${department || ""}
Role(s): ${roleText}

Please login and change your password on first use.

Best regards,
Z-FinSight Team`;

    await transporter.sendMail({
      from,
      to: toEmail,
      subject,
      text,
    });

    return res.json({ success: true, message: "Email sent" });
  } catch (err) {
    console.error("Send credentials error:", err);
    return res.status(500).json({ success: false, message: "Server error", error: err.message });
  }
});

module.exports = router;
