const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");
const nodemailer = require("nodemailer");

const Admin = require("../models/Admin");
const User = require("../models/User");
const Company = require("../models/Company");
const { requireAuth } = require("../middleware/authGuard");
const { validate, userLoginSchema, changePasswordSchema } = require("../middleware/validators");

const router = express.Router();

/* =====================================================
   HELPERS
===================================================== */
const sha256 = (val) =>
  crypto.createHash("sha256").update(val).digest("hex");

const buildResetLink = (token) => {
  const FRONTEND =
    process.env.FRONTEND_URL || "http://127.0.0.1:5500";
  return `${FRONTEND}/reset-password.html?token=${encodeURIComponent(token)}`;
};

const mailer = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.GMAIL_USER,
    pass: process.env.GMAIL_APP_PASSWORD,
  },
});

/* =====================================================
   ADMIN LOGIN (DEPRECATED - Use /user-login with admin role)
   TODO: Remove this endpoint in future version
===================================================== */
router.post("/login", async (req, res) => {
  try {
    const { identifier, password } = req.body;
    if (!identifier || !password)
      return res.status(400).json({ success: false, message: "Missing fields" });

    const id = identifier.toLowerCase().trim();
    const admin = await Admin.findOne({
      $or: [{ username: id }, { email: id }],
    });

    if (!admin) return res.status(401).json({ success: false, message: "Invalid credentials" });

    const ok = await bcrypt.compare(password, admin.passwordHash);
    if (!ok) return res.status(401).json({ success: false, message: "Invalid credentials" });

    if (!admin.isVerified)
      return res.status(403).json({ success: false, message: "Email not verified" });

    const company = await Company.findById(admin.companyId);
    if (!company || !company.isActive)
      return res.status(403).json({ success: false, message: "Company inactive" });

    // Use standardized JWT payload format
    const token = jwt.sign(
      {
        adminId: admin._id.toString(),
        roles: admin.roles || ["admin"],
        companyId: admin.companyId.toString(),
        companyCode: company.companyId, // Public company code
        mustChangePassword: false,
        isAdmin: true, // Legacy flag for backward compatibility
      },
      process.env.JWT_SECRET,
      { expiresIn: "12h" } // Enforce 12h expiration
    );

    res.json({ 
      success: true, 
      token,
      user: {
        userId: admin._id.toString(),
        roles: admin.roles || ["admin"],
        companyId: admin.companyId.toString(),
        companyCode: company.companyId,
        mustChangePassword: false,
      }
    });
  } catch (e) {
    res.status(500).json({ success: false, message: "Server error" });
  }
});

/* =====================================================
   USER LOGIN
===================================================== */
router.post("/user-login", validate(userLoginSchema), async (req, res) => {
  try {
    // Accept identifier, username, or email (for compatibility)
    const { identifier, username, email, password } = req.body;
    
    // Determine which field to use (priority: identifier > username > email)
    const loginField = identifier || username || email;

    // Trim and lowercase the login identifier
    const normalizedLogin = String(loginField).trim().toLowerCase();

    // Find user by email OR username
    const u = await User.findOne({
      $or: [
        { email: normalizedLogin },
        { username: normalizedLogin }
      ]
    }).populate(
      "companyId",
      "companyName isActive"
    );

    if (!u || !u.isActive) {
      return res.status(401).json({ success: false, message: "Invalid credentials" });
    }

    // Compare password with passwordHash
    const ok = await bcrypt.compare(String(password).trim(), u.passwordHash);
    if (!ok) {
      return res.status(401).json({ success: false, message: "Invalid credentials" });
    }

    // Get company code from populated company
    const companyCode = u.companyId?.companyId || null; // companyId is the string like "CMP_001"

    // Create JWT token with standardized payload
    const tokenPayload = {
      userId: u._id.toString(),
      roles: u.roles,
      companyId: u.companyId._id.toString(), // MongoDB ObjectId as string
      companyCode: companyCode, // Public company code like "CMP_001"
      mustChangePassword: u.mustChangePassword,
    };
    
    // Add externalType for external users
    if (u.roles && u.roles.includes('external') && u.externalType) {
      tokenPayload.externalType = u.externalType;
    }
    
    const token = jwt.sign(
      tokenPayload,
      process.env.JWT_SECRET,
      { expiresIn: "12h" } // Enforce 12h expiration
    );

    res.json({
      success: true,
      token,
      user: {
        userId: u._id.toString(),
        username: u.username,
        roles: u.roles,
        companyId: u.companyId._id.toString(),
        companyCode: companyCode,
        mustChangePassword: u.mustChangePassword,
        externalType: u.externalType || null,
      },
    });
  } catch (e) {
    console.error("User login error:", e);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

/* =====================================================
   FORGOT PASSWORD
===================================================== */
router.post("/forgot-password", async (req, res) => {
  try {
    const email = req.body.email?.toLowerCase().trim();
    if (!email) return res.json({ success: true });

    const user = await User.findOne({ email });
    if (!user) return res.json({ success: true });

    const rawToken = crypto.randomBytes(32).toString("hex");

    user.resetPasswordTokenHash = sha256(rawToken);
    user.resetPasswordExpires = new Date(Date.now() + 10 * 60 * 1000);
    await user.save();

    const link = buildResetLink(rawToken);

    await mailer.sendMail({
      from: `"Z-FinSight" <${process.env.GMAIL_USER}>`,
      to: user.email,
      subject: "Reset your password",
      html: `
        <p>You requested a password reset.</p>
        <p>This link is valid for <b>10 minutes</b>.</p>
        <a href="${link}">Reset Password</a>
      `,
    });

    res.json({ success: true });
  } catch (e) {
    res.json({ success: true });
  }
});

/* =====================================================
   CHANGE PASSWORD (for users with temporary passwords)
===================================================== */
router.post("/change-password", validate(changePasswordSchema), async (req, res) => {
  try {
    // Accept identifier, username, or email (for compatibility)
    const { identifier, username, email, oldPassword, newPassword } = req.body;

    // Determine which field to use (priority: identifier > username > email)
    const loginField = identifier || username || email;

    // Trim all inputs
    const normalizedLogin = String(loginField).trim().toLowerCase();
    const trimmedOldPassword = String(oldPassword).trim();
    const trimmedNewPassword = String(newPassword).trim();

    // Find user by email OR username
    const user = await User.findOne({
      $or: [
        { email: normalizedLogin },
        { username: normalizedLogin }
      ]
    }).populate("companyId", "companyName isActive");

    if (!user) {
      return res.status(401).json({ 
        success: false, 
        message: "User not found" 
      });
    }

    // Verify old password using passwordHash
    const isOldPasswordValid = await bcrypt.compare(trimmedOldPassword, user.passwordHash);
    if (!isOldPasswordValid) {
      return res.status(401).json({ 
        success: false, 
        message: "Current password is incorrect" 
      });
    }

    // Update passwordHash and set mustChangePassword to false
    user.passwordHash = await bcrypt.hash(trimmedNewPassword, 10);
    user.mustChangePassword = false;
    await user.save();

    // Return standardized response
    res.json({ 
      success: true, 
      message: "Password changed successfully",
      user: {
        userId: user._id.toString(),
        username: user.username,
        roles: user.roles,
        companyId: user.companyId._id.toString(),
        companyCode: user.companyId.companyId,
        mustChangePassword: false,
      }
    });
  } catch (e) {
    console.error("Change password error:", e);
    res.status(500).json({ 
      success: false, 
      message: "Server error" 
    });
  }
});

/* =====================================================
   RESET PASSWORD
===================================================== */
router.post("/reset-password", async (req, res) => {
  try {
    const { token, newPassword, confirmNewPassword } = req.body;

    // Validation
    if (!token) {
      return res.status(400).json({ 
        success: false, 
        message: "Reset token is required" 
      });
    }

    if (!newPassword || newPassword.length < 6) {
      return res.status(400).json({ 
        success: false, 
        message: "Password must be at least 6 characters" 
      });
    }

    if (newPassword !== confirmNewPassword) {
      return res.status(400).json({ 
        success: false, 
        message: "Passwords do not match" 
      });
    }

    // Hash the token to match stored hash
    const tokenHash = sha256(token);

    // Find user with matching token hash
    const user = await User.findOne({
      resetPasswordTokenHash: tokenHash,
    });

    if (!user) {
      return res.status(400).json({ 
        success: false, 
        message: "Invalid or expired reset token" 
      });
    }

    // Check if token has expired
    if (!user.resetPasswordExpires || user.resetPasswordExpires < new Date()) {
      // Clear expired token
      user.resetPasswordTokenHash = null;
      user.resetPasswordExpires = null;
      await user.save();
      
      return res.status(400).json({ 
        success: false, 
        message: "Reset token has expired. Please request a new password reset." 
      });
    }

    // Update password
    user.passwordHash = await bcrypt.hash(newPassword, 10);
    user.mustChangePassword = false;
    user.resetPasswordTokenHash = null;
    user.resetPasswordExpires = null;

    await user.save();

    console.log(`✅ Password reset successful for user: ${user.email}`);

    res.json({ 
      success: true,
      message: "Password reset successfully" 
    });
  } catch (e) {
    console.error("❌ Reset password error:", e);
    res.status(500).json({ 
      success: false,
      message: "Server error. Please try again later." 
    });
  }
});

/* =====================================================
   GET /api/auth/me - Get current user info
===================================================== */
router.get("/me", requireAuth, async (req, res) => {
  try {
    // req.user is set by requireAuth middleware from JWT
    const { userId, roles, companyId, companyCode, mustChangePassword } = req.user;

    res.json({
      success: true,
      user: {
        userId,
        roles,
        companyId,
        companyCode,
        mustChangePassword: mustChangePassword || false,
      },
    });
  } catch (e) {
    console.error("Get me error:", e);
    res.status(500).json({ success: false, message: "Server error" });
  }
});

module.exports = router;
