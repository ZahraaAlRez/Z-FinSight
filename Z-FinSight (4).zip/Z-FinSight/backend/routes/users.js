// backend/routes/users.js
const express = require("express");
const bcrypt = require("bcryptjs");
const User = require("../models/User"); // Make sure this model exists

const {
  requireAuth,
  requireRoles,
  requireCompanyScope,
} = require("../middleware/authGuard");

const router = express.Router();

// ============================================
// POST /api/users - Create new user
// ============================================
router.post(
  "/",
  requireAuth,
  requireCompanyScope,
  requireRoles(["admin"]),
  async (req, res) => {
    try {
      // ✅ SECURITY: Use companyId from JWT token only
      const companyId = req.userCompanyId;

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      const {
        email,
        password,
        fullName,
        username,
        roles,
        department,
      } = req.body || {};

      // Validation
      if (!email || !password || !fullName || !department) {
        return res.status(400).json({
          success: false,
          message: "email, password, fullName, and department are required",
        });
      }

      // Check if user already exists
      const existing = await User.findOne({ email });
      if (existing) {
        return res.status(400).json({
          success: false,
          message: "User with this email already exists",
        });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);

      // Create user - ALWAYS use companyId from JWT
      const newUser = await User.create({
        email,
        passwordHash: hashedPassword,
        fullName,
        username: username || email.split("@")[0],
        roles: roles || ["accountant"],
        department: department || "General",
        companyId, // ✅ From JWT token only
      });

      // Return user without password
      const userResponse = newUser.toObject();
      delete userResponse.passwordHash;

      res.status(201).json({
        success: true,
        user: userResponse,
      });
    } catch (err) {
      console.error("user creation error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// ============================================
// GET /api/users/:companyId - List users (DEPRECATED - use GET / instead)
// ============================================
// ⚠️ This endpoint uses companyId from URL - should be updated to use GET /
router.get(
  "/:companyId",
  requireAuth,
  requireCompanyScope,
  requireRoles(["admin", "manager"]),
  async (req, res) => {
    try {
      // ✅ SECURITY: Use companyId from JWT, ignore URL param
      const companyId = req.userCompanyId;

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      // Get all users for this company
      const users = await User.find({ companyId })
        .select("-passwordHash") // Don't send passwords
        .sort({ createdAt: -1 })
        .lean();

      res.json({
        success: true,
        items: users,
        total: users.length,
      });
    } catch (err) {
      console.error("users list error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// ============================================
// GET /api/users - List users (RECOMMENDED)
// ============================================
router.get(
  "/",
  requireAuth,
  requireCompanyScope,
  requireRoles(["admin", "manager", "accountant"]),
  async (req, res) => {
    try {
      // ✅ SECURITY: Use companyId from JWT only
      const companyId = req.userCompanyId;

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      // Query params
      const limit = Math.min(parseInt(req.query.limit || "100", 10), 500);
      const page = Math.max(parseInt(req.query.page || "1", 10), 1);
      const skip = (page - 1) * limit;

      // Get users for this company only
      const [users, total] = await Promise.all([
        User.find({ companyId })
          .select("-passwordHash") // Don't send passwords
          .sort({ createdAt: -1 })
          .skip(skip)
          .limit(limit)
          .lean(),
        User.countDocuments({ companyId }),
      ]);

      res.json({
        success: true,
        items: users,
        total,
        page,
        limit,
      });
    } catch (err) {
      console.error("users list error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// ============================================
// POST /api/users/change-password - Change user password
// ============================================
router.post(
  "/change-password",
  requireAuth,
  requireCompanyScope,
  async (req, res) => {
    try {
      const userId = req.user.userId;
      const companyId = req.userCompanyId;
      const { currentPassword, newPassword } = req.body || {};

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      if (!currentPassword || !newPassword) {
        return res.status(400).json({
          success: false,
          message: "currentPassword and newPassword are required",
        });
      }

      // Find user - must be from same company
      const user = await User.findOne({
        _id: userId,
        companyId, // ✅ Company isolation
      });

      if (!user) {
        return res.status(404).json({
          success: false,
          message: "User not found",
        });
      }

      // Verify current password
      const isMatch = await bcrypt.compare(currentPassword, user.passwordHash);
      if (!isMatch) {
        return res.status(401).json({
          success: false,
          message: "Current password is incorrect",
        });
      }

      // Hash new password
      const hashedPassword = await bcrypt.hash(newPassword, 10);

      // Update password
      user.passwordHash = hashedPassword;
      await user.save();

      res.json({
        success: true,
        message: "Password changed successfully",
      });
    } catch (err) {
      console.error("change password error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// ============================================
// DELETE /api/users/:userId - Delete user
// ============================================
router.delete(
  "/:userId",
  requireAuth,
  requireCompanyScope,
  requireRoles(["admin"]),
  async (req, res) => {
    try {
      const companyId = req.userCompanyId;
      const userId = req.params.userId;

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      // Prevent deleting yourself
      if (userId === req.user.userId) {
        return res.status(400).json({
          success: false,
          message: "Cannot delete your own account",
        });
      }

      // Delete only if user belongs to same company
      const deleted = await User.findOneAndDelete({
        _id: userId,
        companyId, // ✅ Company isolation
      });

      if (!deleted) {
        return res.status(404).json({
          success: false,
          message: "User not found or already deleted",
        });
      }

      res.json({
        success: true,
        message: "User deleted successfully",
      });
    } catch (err) {
      console.error("user delete error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// ============================================
// PATCH /api/users/:userId - Update user
// ============================================
router.patch(
  "/:userId",
  requireAuth,
  requireCompanyScope,
  requireRoles(["admin"]),
  async (req, res) => {
    try {
      const companyId = req.userCompanyId;
      const userId = req.params.userId;
      const { fullName, username, roles, isActive, department } = req.body || {};

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      // Build update object
      const update = {};
      if (fullName !== undefined) update.fullName = fullName;
      if (username !== undefined) update.username = username;
      if (roles !== undefined) update.roles = roles;
      if (isActive !== undefined) update.isActive = isActive;
      if (department !== undefined) update.department = department;

      // Update only if user belongs to same company
      const updated = await User.findOneAndUpdate(
        { _id: userId, companyId },
        update,
        { new: true }
      )
        .select("-passwordHash")
        .lean();

      if (!updated) {
        return res.status(404).json({
          success: false,
          message: "User not found",
        });
      }

      res.json({
        success: true,
        user: updated,
      });
    } catch (err) {
      console.error("user update error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// ============================================
// GET /api/users/:userId - Get single user
// ============================================
router.get(
  "/:userId/details",
  requireAuth,
  requireCompanyScope,
  requireRoles(["admin", "manager", "accountant"]),
  async (req, res) => {
    try {
      const companyId = req.userCompanyId;
      const userId = req.params.userId;

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      // Get user only if belongs to same company
      const user = await User.findOne({
        _id: userId,
        companyId, // ✅ Company isolation
      })
        .select("-passwordHash")
        .lean();

      if (!user) {
        return res.status(404).json({
          success: false,
          message: "User not found",
        });
      }

      res.json({
        success: true,
        user,
      });
    } catch (err) {
      console.error("user details error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

module.exports = router;