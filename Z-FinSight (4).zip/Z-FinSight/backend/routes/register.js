const express = require("express");
const bcrypt = require("bcryptjs");
const nodemailer = require("nodemailer");

const Company = require("../models/Company");
const Admin = require("../models/Admin");
const User = require("../models/User");
const VerificationCode = require("../models/VerificationCode");

const router = express.Router();

// ============================================
// Helper: Create Gmail Transporter
// ============================================
function createGmailTransporter() {
  if (!process.env.GMAIL_USER || !process.env.GMAIL_APP_PASSWORD) {
    throw new Error("Missing GMAIL_USER / GMAIL_APP_PASSWORD in .env");
  }
  return nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: process.env.GMAIL_USER,
      pass: process.env.GMAIL_APP_PASSWORD,
    },
  });
}

// ============================================
// POST /api/register/company
// Register a new company
// ============================================
router.post("/company", async (req, res) => {
  try {
    const {
      companyName,
      industry,
      industryOther,
      country,
      countryOther,
      currencies,
      companyEmail,
      language,
    } = req.body;

    // Determine response language
    const lang = language || req.headers["accept-language"] || "en";
    const isArabic = String(lang).toLowerCase().includes("ar");

    // Validation
    if (!companyName || companyName.trim().length < 2) {
      return res.status(400).json({
        success: false,
        message: isArabic
          ? "يجب أن يكون اسم الشركة حرفين على الأقل"
          : "Company name must be at least 2 characters",
      });
    }

    if (!industry) {
      return res.status(400).json({
        success: false,
        message: isArabic ? "المجال مطلوب" : "Industry is required",
      });
    }

    if (
      industry === "other" &&
      (!industryOther || industryOther.trim().length < 2)
    ) {
      return res.status(400).json({
        success: false,
        message: isArabic ? "يرجى تحديد مجال عملك" : "Please specify your industry",
      });
    }

    if (!country) {
      return res.status(400).json({
        success: false,
        message: isArabic ? "البلد مطلوب" : "Country is required",
      });
    }

    if (
      country === "other" &&
      (!countryOther || countryOther.trim().length < 2)
    ) {
      return res.status(400).json({
        success: false,
        message: isArabic ? "يرجى تحديد بلدك" : "Please specify your country",
      });
    }

    if (!currencies || !Array.isArray(currencies) || currencies.length === 0) {
      return res.status(400).json({
        success: false,
        message: isArabic
          ? "عملة واحدة على الأقل مطلوبة"
          : "At least one currency is required",
      });
    }

    // Validate language
    const validatedLanguage =
      language && (language === "ar" || language === "en")
        ? language.toLowerCase().trim()
        : "en";

    // Create company (companyId generated in Company.js pre-save)
    const company = new Company({
      companyName: companyName.trim(),
      industry,
      industryOther: industry === "other" ? industryOther.trim() : "",
      country,
      countryOther: country === "other" ? countryOther.trim() : "",
      currencies,
      companyEmail: companyEmail ? companyEmail.trim() : "",
      language: validatedLanguage,
      isActive: false,
      isVerified: false,
    });

    // ✅ Retry save if duplicate companyId happens (rare, but safe)
    let savedCompany = null;
    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        savedCompany = await company.save();
        break;
      } catch (err) {
        // duplicate key (companyId)
        if (err && err.code === 11000 && err.keyPattern && err.keyPattern.companyId) {
          console.warn(
            `⚠️ Duplicate companyId on attempt ${attempt}. Retrying...`
          );
          // clear companyId so pre-save generates a new one
          company.companyId = undefined;
          continue;
        }
        throw err;
      }
    }

    if (!savedCompany) {
      return res.status(409).json({
        success: false,
        message: isArabic
          ? "تعذّر إنشاء Company ID فريد. حاول مرة ثانية."
          : "Could not generate a unique Company ID. Please try again.",
      });
    }

    console.log(
      "✅ Company created:",
      savedCompany.companyId,
      "(inactive, unverified)"
    );

    // Send verification email if companyEmail provided
    let emailSent = false;
    if (companyEmail && companyEmail.trim()) {
      try {
        const normalizedEmail = companyEmail.toLowerCase().trim();

        // Generate OTP
        const otpCode = Math.floor(100000 + Math.random() * 900000).toString();

        // Delete old codes
        await VerificationCode.deleteMany({ email: normalizedEmail });

        // Save new code
        const verification = new VerificationCode({
          email: normalizedEmail,
          code: otpCode,
        });
        await verification.save();

        console.log("✅ Verification code generated:", otpCode);

        // Send email
        const transporter = createGmailTransporter();

        const emailContent = isArabic
          ? {
              subject: "التحقق من البريد الإلكتروني - تسجيل شركة Z-FinSight",
              greeting: `مرحباً <strong>${companyName}</strong>،`,
              instruction:
                "يرجى استخدام رمز التحقق التالي لإكمال تسجيل شركتك:",
              expiryNote: "هذا الرمز صالح لمدة <strong>10 دقائق</strong>",
              securityNote:
                "<strong>ملاحظة أمنية:</strong> إذا لم تطلب هذا الرمز، يرجى تجاهل هذا البريد الإلكتروني.",
              regards: "مع أطيب التحيات،<br/><strong>فريق Z-FinSight</strong>",
            }
          : {
              subject: "Email Verification - Z-FinSight Company Registration",
              greeting: `Hi <strong>${companyName}</strong>,`,
              instruction:
                "Please use the following verification code to complete your company registration:",
              expiryNote: "This code will expire in <strong>10 minutes</strong>",
              securityNote:
                "<strong>Security Note:</strong> If you didn't request this code, please ignore this email.",
              regards: "Best regards,<br/><strong>Z-FinSight Team</strong>",
            };

        await transporter.sendMail({
          from: process.env.GMAIL_USER,
          to: normalizedEmail,
          subject: emailContent.subject,
          html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; direction: ${
              isArabic ? "rtl" : "ltr"
            };">
              <h2 style="color: #1e293b; text-align: center;">Z-FinSight</h2>
              <p style="font-size: 16px; color: #334155;">${
                emailContent.greeting
              }</p>
              <p style="font-size: 15px; color: #334155;">${
                emailContent.instruction
              }</p>

              <div style="background: #0f172a; color: #fff; padding: 18px; border-radius: 10px; text-align: center; margin: 18px 0;">
                <div style="font-size: 28px; letter-spacing: 6px; font-weight: 700;">
                  ${otpCode}
                </div>
              </div>

              <p style="color: #64748b; font-size: 14px; text-align: center;">
                ${emailContent.expiryNote}
              </p>

              <div style="background: #fef3c7; padding: 15px; border-radius: 8px; border-${
                isArabic ? "right" : "left"
              }: 4px solid #f59e0b;">
                <p style="margin: 0; color: #92400e; font-size: 14px;">
                  ${emailContent.securityNote}
                </p>
              </div>

              <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #e2e8f0; text-align: center;">
                <p style="margin: 0; color: #64748b; font-size: 13px;">
                  ${emailContent.regards}
                </p>
              </div>
            </div>
          `,
        });

        emailSent = true;
        console.log("✅ Verification email sent to:", normalizedEmail);
      } catch (emailErr) {
        console.error("⚠️ Error sending verification email:", emailErr.message);
        emailSent = false;
      }
    }

    return res.status(201).json({
      success: true,
      message: emailSent
        ? isArabic
          ? "تم تسجيل الشركة بنجاح. تم إرسال رمز التحقق إلى البريد الإلكتروني."
          : "Company registered successfully. Verification code sent to email."
        : isArabic
        ? "تم تسجيل الشركة بنجاح"
        : "Company registered successfully",
      data: {
        companyId: savedCompany.companyId,
        companyDbId: savedCompany._id,
        companyName: savedCompany.companyName,
        companyEmail: savedCompany.companyEmail || "",
        emailSent: emailSent,
        isActive: false,
        isVerified: false,
      },
    });
  } catch (err) {
    console.error("❌ Error registering company:", err);

    // ✅ Duplicate key handling (generic)
    if (err && err.code === 11000) {
      return res.status(409).json({
        success: false,
        message:
          (req.body.language || "").toLowerCase() === "ar"
            ? "يوجد بيانات مكررة (Duplicate). يرجى المحاولة مجددًا."
            : "Duplicate data detected. Please try again.",
      });
    }

    return res.status(500).json({
      success: false,
      message: req.body.language === "ar" ? "خطأ في الخادم" : "Server error",
    });
  }
});

// ============================================
// POST /api/register/verify - Verify email with OTP
// ============================================
router.post("/verify", async (req, res) => {
  try {
    const { email, otpCode, companyId } = req.body || {};

    // Determine response language
    const lang = req.body.language || req.headers["accept-language"] || "en";
    const isArabic = String(lang).toLowerCase().includes("ar");

    // Validation
    if (!email || !otpCode) {
      return res.status(400).json({
        success: false,
        message: isArabic
          ? "البريد الإلكتروني ورمز التحقق مطلوبان"
          : "Email and OTP code are required",
      });
    }

    const normalizedEmail = email.toLowerCase().trim();

    // Find verification code
    const verification = await VerificationCode.findOne({
      email: normalizedEmail,
      code: String(otpCode).trim(),
    });

    if (!verification) {
      return res.status(400).json({
        success: false,
        message: isArabic
          ? "رمز التحقق غير صحيح أو منتهي الصلاحية"
          : "Invalid or expired verification code",
      });
    }

    // Check if code is expired
    if (verification.expiresAt < new Date()) {
      await VerificationCode.deleteOne({ _id: verification._id });
      return res.status(400).json({
        success: false,
        message: isArabic
          ? "رمز التحقق منتهي الصلاحية"
          : "Verification code has expired",
      });
    }

    // Find company by email or companyId
    let company;
    if (companyId) {
      company = await Company.findOne({ companyId });
    } else {
      company = await Company.findOne({ companyEmail: normalizedEmail });
    }

    if (!company) {
      return res.status(404).json({
        success: false,
        message: isArabic ? "الشركة غير موجودة" : "Company not found",
      });
    }

    // Mark company as verified
    company.isVerified = true;
    company.isActive = true; // Activate company upon verification
    await company.save();

    // Delete used verification code
    await VerificationCode.deleteOne({ _id: verification._id });

    console.log(
      `✅ Company verified: ${company.companyId} (${company.companyName})`
    );

    return res.json({
      success: true,
      message: isArabic
        ? "تم التحقق من البريد الإلكتروني بنجاح"
        : "Email verified successfully",
      data: {
        companyId: company.companyId,
        companyName: company.companyName,
        isVerified: company.isVerified,
        isActive: company.isActive,
      },
    });
  } catch (err) {
    console.error("❌ Email verification error:", err);
    const isArabic = String(
      req.body.language || req.headers["accept-language"] || "en"
    )
      .toLowerCase()
      .includes("ar");
    return res.status(500).json({
      success: false,
      message: isArabic ? "خطأ في الخادم" : "Server error",
      error: err.message,
    });
  }
});

// ============================================
// POST /api/register/resend-otp - Resend verification OTP
// ============================================
router.post("/resend-otp", async (req, res) => {
  try {
    const { email } = req.body || {};

    // Determine response language
    const lang = req.body.language || req.headers["accept-language"] || "en";
    const isArabic = String(lang).toLowerCase().includes("ar");

    if (!email) {
      return res.status(400).json({
        success: false,
        message: isArabic ? "البريد الإلكتروني مطلوب" : "Email is required",
      });
    }

    const normalizedEmail = email.toLowerCase().trim();

    // Find company
    const company = await Company.findOne({ companyEmail: normalizedEmail });
    if (!company) {
      return res.status(404).json({
        success: false,
        message: isArabic ? "الشركة غير موجودة" : "Company not found",
      });
    }

    // Generate new OTP
    const otpCode = Math.floor(100000 + Math.random() * 900000).toString();

    // Delete old codes
    await VerificationCode.deleteMany({ email: normalizedEmail });

    // Save new code
    const verification = new VerificationCode({
      email: normalizedEmail,
      code: otpCode,
    });
    await verification.save();

    // Send email (reuse the email sending logic from company registration)
    const { createGmailTransporter } = require("../utils/emailHelper");
    const transporter = createGmailTransporter();

    const emailContent = isArabic
      ? {
          subject: `رمز التحقق الجديد - ${company.companyName}`,
          title: "🔄 رمز التحقق الجديد",
          intro: "لقد طلبت رمز تحقق جديد:",
          codeLabel: "رمز التحقق:",
          note: "هذا الرمز صالح لمدة 10 دقائق فقط.",
          footer: `© ${new Date().getFullYear()} Z-FinSight. جميع الحقوق محفوظة.`,
        }
      : {
          subject: `New Verification Code - ${company.companyName}`,
          title: "🔄 New Verification Code",
          intro: "You requested a new verification code:",
          codeLabel: "Verification Code:",
          note: "This code is valid for 10 minutes only.",
          footer: `© ${new Date().getFullYear()} Z-FinSight. All rights reserved.`,
        };

    const htmlContent = `
      <!DOCTYPE html>
      <html dir="${isArabic ? "rtl" : "ltr"}">
      <head>
        <meta charset="UTF-8">
        <style>
          body { font-family: Arial, sans-serif; padding: 20px; background: #f4f4f4; }
          .container { max-width: 600px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; }
          h1 { color: #0f172a; }
          .code { font-size: 32px; font-weight: bold; color: #06d6a0; text-align: center; padding: 20px; background: #f0fdfa; border-radius: 8px; margin: 20px 0; }
          .note { color: #64748b; font-size: 14px; margin-top: 20px; }
        </style>
      </head>
      <body>
        <div class="container">
          <h1>${emailContent.title}</h1>
          <p>${emailContent.intro}</p>
          <div class="code">${otpCode}</div>
          <p class="note">${emailContent.note}</p>
          <p style="margin-top: 30px; font-size: 12px; color: #94a3b8;">${emailContent.footer}</p>
        </div>
      </body>
      </html>
    `;

    await transporter.sendMail({
      from: `"Z-FinSight" <${process.env.GMAIL_USER}>`,
      to: normalizedEmail,
      subject: emailContent.subject,
      html: htmlContent,
    });

    console.log(`✅ Verification code resent to: ${normalizedEmail}`);

    return res.json({
      success: true,
      message: isArabic
        ? "تم إرسال رمز التحقق بنجاح"
        : "Verification code sent successfully",
    });
  } catch (err) {
    console.error("❌ Resend OTP error:", err);
    const isArabic = String(
      req.body.language || req.headers["accept-language"] || "en"
    )
      .toLowerCase()
      .includes("ar");
    return res.status(500).json({
      success: false,
      message: isArabic ? "خطأ في الخادم" : "Server error",
      error: err.message,
    });
  }
});

// ============================================
// POST /api/register/users - Add users during registration (no auth required)
// ============================================
router.post("/users", async (req, res) => {
  try {
    console.log("✅ POST /api/register/users called - No auth required");
    console.log("Request body:", JSON.stringify(req.body, null, 2));
    
    const {
      companyId, // This is the public companyId like "CMP_001"
      fullName,
      username,
      email,
      department,
      roles: rolesRaw,
      password,
    } = req.body || {};
    
    // Map frontend role names to backend enum values
    const roleMapping = {
      "analyst": "financial_analyst",
      "financial": "financial_analyst",
      "financialanalyst": "financial_analyst",
    };
    
    // Normalize roles: map frontend names to backend enum values
    const roles = Array.isArray(rolesRaw) 
      ? rolesRaw.map(r => roleMapping[r.toLowerCase()] || r.toLowerCase())
      : [];

    // Determine response language
    const lang = req.body.language || req.headers["accept-language"] || "en";
    const isArabic = String(lang).toLowerCase().includes("ar");

    // Validation
    if (!companyId) {
      return res.status(400).json({
        success: false,
        message: isArabic ? "معرف الشركة مطلوب" : "Company ID is required",
      });
    }

    if (!fullName || !email || !department) {
      return res.status(400).json({
        success: false,
        message: isArabic
          ? "الاسم الكامل والبريد الإلكتروني والقسم مطلوبة"
          : "Full name, email, and department are required",
      });
    }

    // Find company by companyId (public ID like "CMP_001")
    const company = await Company.findOne({ companyId });
    if (!company) {
      return res.status(404).json({
        success: false,
        message: isArabic ? "الشركة غير موجودة" : "Company not found",
      });
    }

    // Check if company is verified (optional - you might want to allow adding users before verification)
    // For now, we'll allow it during registration flow

    // Check if user already exists
    const existing = await User.findOne({ email });
    if (existing) {
      return res.status(400).json({
        success: false,
        message: isArabic
          ? "المستخدم موجود بالفعل"
          : "User with this email already exists",
      });
    }

    // Generate password if not provided
    const userPassword = password || Math.random().toString(36).slice(-12) + Math.random().toString(36).slice(-12).toUpperCase() + "!@#";

    // Hash password (bcrypt is already required at top of file)
    const hashedPassword = await bcrypt.hash(userPassword, 10);

    // Validate roles against enum
    const validRoles = ["admin", "manager", "accountant", "financial_analyst", "external"];
    const normalizedRoles = roles && Array.isArray(roles) 
      ? roles.filter(r => validRoles.includes(r)) // Only keep valid roles
      : ["accountant"];
    
    if (normalizedRoles.length === 0) {
      return res.status(400).json({
        success: false,
        message: isArabic
          ? "يجب تحديد دور صحيح واحد على الأقل"
          : "At least one valid role is required",
      });
    }

    // Create user with company's MongoDB _id
    const newUser = await User.create({
      email: email.toLowerCase().trim(),
      passwordHash: hashedPassword,
      fullName: fullName.trim(),
      username: username || email.split("@")[0],
      roles: normalizedRoles,
      department: department.trim(),
      companyId: company._id, // Use MongoDB ObjectId
      mustChangePassword: true, // Force password change on first login
    });

    // Return user without password hash
    const userResponse = newUser.toObject();
    delete userResponse.passwordHash;

    console.log(`✅ User created during registration: ${newUser.email} for company ${companyId}`);

    return res.json({
      success: true,
      message: isArabic ? "تم إضافة المستخدم بنجاح" : "User added successfully",
      data: {
        userId: newUser._id.toString(),
        username: newUser.username,
        email: newUser.email,
        fullName: newUser.fullName,
        department: newUser.department,
        roles: newUser.roles,
        initialPassword: userPassword, // Return the generated password
      },
    });
  } catch (err) {
    console.error("❌ Add user during registration error:", err);
    const isArabic = String(
      req.body.language || req.headers["accept-language"] || "en"
    )
      .toLowerCase()
      .includes("ar");

    // Handle duplicate key errors
    if (err.code === 11000) {
      const field = Object.keys(err.keyPattern || {})[0];
      return res.status(400).json({
        success: false,
        message: isArabic
          ? `المستخدم موجود بالفعل (${field})`
          : `User already exists (${field})`,
      });
    }

    // More specific error messages
    let errorMessage = isArabic ? "خطأ في الخادم" : "Server error";
    
    if (err.name === "ValidationError") {
      errorMessage = isArabic 
        ? "خطأ في التحقق من البيانات" 
        : "Validation error: " + Object.values(err.errors || {}).map(e => e.message).join(", ");
    } else if (err.message) {
      errorMessage = err.message;
    }

    console.error("Error details:", {
      name: err.name,
      message: err.message,
      stack: err.stack,
      code: err.code
    });

    return res.status(500).json({
      success: false,
      message: errorMessage,
      error: process.env.NODE_ENV === "development" ? err.message : undefined,
    });
  }
});

// ============================================
// GET /api/register/users - Get users for a company during registration
// ============================================
router.get("/users", async (req, res) => {
  try {
    const { companyId } = req.query;

    if (!companyId) {
      return res.status(400).json({
        success: false,
        message: "Company ID is required",
      });
    }

    // Find company
    const company = await Company.findOne({ companyId });
    if (!company) {
      return res.status(404).json({
        success: false,
        message: "Company not found",
      });
    }

    // Get users for this company
    const users = await User.find({ companyId: company._id })
      .select("-passwordHash")
      .lean();

    return res.json({
      success: true,
      data: {
        companyId: company.companyId,
        companyName: company.companyName,
        users: users,
      },
    });
  } catch (err) {
    console.error("❌ Get users during registration error:", err);
    return res.status(500).json({
      success: false,
      message: "Server error",
      error: process.env.NODE_ENV === "development" ? err.message : undefined,
    });
  }
});

// ============================================
// DELETE /api/register/users/:userId - Delete user during registration
// ============================================
router.delete("/users/:userId", async (req, res) => {
  try {
    const { userId } = req.params;
    const { companyId } = req.query;

    if (!companyId) {
      return res.status(400).json({
        success: false,
        message: "Company ID is required",
      });
    }

    // Find company
    const company = await Company.findOne({ companyId });
    if (!company) {
      return res.status(404).json({
        success: false,
        message: "Company not found",
      });
    }

    // Delete user only if belongs to this company
    const deleted = await User.findOneAndDelete({
      _id: userId,
      companyId: company._id,
    });

    if (!deleted) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    return res.json({
      success: true,
      message: "User deleted successfully",
    });
  } catch (err) {
    console.error("❌ Delete user during registration error:", err);
    return res.status(500).json({
      success: false,
      message: "Server error",
      error: process.env.NODE_ENV === "development" ? err.message : undefined,
    });
  }
});

module.exports = router;
