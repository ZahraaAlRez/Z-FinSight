const express = require("express");
const Transaction = require("../models/Transaction");

const {
  requireAuth,
  requireRoles,
  requireCompanyScope,
} = require("../middleware/authGuard");

const router = express.Router();

// LIST
router.get(
  "/",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager"]),
  async (req, res) => {
    try {
      // ✅ SECURITY: Use companyId from JWT token only (set by requireCompanyScope)
      const companyId = req.userCompanyId;
      
      if (!companyId) {
        return res.status(400).json({ 
          success: false, 
          message: "companyId is required" 
        });
      }

      const limit = Math.min(parseInt(req.query.limit || "50", 10), 200);
      const page = Math.max(parseInt(req.query.page || "1", 10), 1);
      const skip = (page - 1) * limit;

      const q = { companyId };

      if (req.query.type) q.type = String(req.query.type);
      if (req.query.category) q.category = String(req.query.category);
      if (req.query.reconciled === "true") q.reconciled = true;
      if (req.query.reconciled === "false") q.reconciled = false;

      if (req.query.from || req.query.to) {
        q.date = {};
        if (req.query.from) q.date.$gte = new Date(req.query.from);
        if (req.query.to) q.date.$lte = new Date(req.query.to);
      }

      const [items, total] = await Promise.all([
        Transaction.find(q)
          .sort({ date: -1, createdAt: -1 })
          .skip(skip)
          .limit(limit)
          .lean(),
        Transaction.countDocuments(q),
      ]);

      res.json({ success: true, items, total, page, limit });
    } catch (err) {
      console.error("transactions list error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// CREATE
router.post(
  "/",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin"]),
  async (req, res) => {
    try {
      // ✅ SECURITY: Use companyId from JWT token only (set by requireCompanyScope)
      const companyId = req.userCompanyId;
      
      if (!companyId) {
        return res.status(400).json({ 
          success: false, 
          message: "companyId is required" 
        });
      }

      const {
        date,
        type,
        amount,
        currency,
        category,
        description,
        counterparty,
        method,
        status,
        attachments,
      } = req.body || {};

      if (!date || !type || amount === undefined) {
        return res.status(400).json({
          success: false,
          message: "date, type, amount are required",
        });
      }

      // Map type to valid enum values (accept common variations)
      let transactionType = String(type).toLowerCase();
      if (transactionType === "revenue" || transactionType === "income") {
        transactionType = "income";
      } else if (transactionType === "expense" || transactionType === "cost" || 
                 transactionType === "payment" || transactionType === "transfer") {
        transactionType = "expense";
      } else if (transactionType !== "income" && transactionType !== "expense") {
        return res.status(400).json({
          success: false,
          message: `Invalid type: ${type}. Must be 'income' or 'expense'. Accepted variations: revenue, payment, transfer, cost`,
        });
      }

      const tx = await Transaction.create({
        companyId,
        date: new Date(date),
        type: transactionType,
        amount: Number(amount),
        currency: currency || "USD",
        category: category || "Uncategorized",
        description: description || "",
        counterparty: counterparty || "",
        method: method || "bank",
        status: status || "posted",
        attachments: Array.isArray(attachments) ? attachments : [],
        createdBy:
          (req.user && (req.user.username || req.user.fullName || req.user.email)) ||
          "",
      });

      res.status(201).json({ success: true, item: tx });
    } catch (err) {
      console.error("transactions create error:", err);
      res.status(500).json({ 
        success: false, 
        message: err.message || "Server error",
        error: process.env.NODE_ENV === "development" ? err.stack : undefined
      });
    }
  }
);

// UPDATE
router.patch(
  "/:id",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin"]),
  async (req, res) => {
    try {
      // ✅ SECURITY: Use companyId from JWT token only (set by requireCompanyScope)
      const companyId = req.userCompanyId;
      const id = req.params.id;

      if (!companyId) {
        return res.status(400).json({ 
          success: false, 
          message: "companyId is required" 
        });
      }

      const updated = await Transaction.findOneAndUpdate(
        { _id: id, companyId },
        { $set: req.body || {} },
        { new: true }
      ).lean();

      if (!updated) {
        return res.status(404).json({ 
          success: false, 
          message: "Transaction not found" 
        });
      }

      res.json({ success: true, item: updated });
    } catch (err) {
      console.error("transactions update error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// DELETE
router.delete(
  "/:id",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin"]),
  async (req, res) => {
    try {
      // ✅ SECURITY: Use companyId from JWT token only (set by requireCompanyScope)
      const companyId = req.userCompanyId;
      const id = req.params.id;

      if (!companyId) {
        return res.status(400).json({ 
          success: false, 
          message: "companyId is required" 
        });
      }

      const deleted = await Transaction.findOneAndDelete({
        _id: id,
        companyId,
      }).lean();

      if (!deleted) {
        return res.status(404).json({ 
          success: false, 
          message: "Transaction not found" 
        });
      }

      res.json({ success: true });
    } catch (err) {
      console.error("transactions delete error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

module.exports = router;