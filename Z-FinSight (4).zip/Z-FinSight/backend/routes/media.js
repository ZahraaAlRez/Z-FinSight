const express = require("express");
const path = require("path");
const fs = require("fs");
const multer = require("multer");

const User = require("../models/User");

const router = express.Router();

const UPLOAD_DIR = path.join(__dirname, "..", "uploads", "avatars");
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname || ".png").toLowerCase();
    const safeExt = [".png", ".jpg", ".jpeg", ".webp"].includes(ext) ? ext : ".png";
    cb(null, `avatar_${Date.now()}_${Math.random().toString(16).slice(2)}${safeExt}`);
  },
});

function fileFilter(req, file, cb) {
  const ok = ["image/png", "image/jpeg", "image/webp"].includes(file.mimetype);
  cb(ok ? null : new Error("Only PNG/JPG/WEBP are allowed"), ok);
}

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 3 * 1024 * 1024 }, // 3MB
});

// POST /api/media/users/:username/avatar
router.post("/users/:username/avatar", upload.single("avatar"), async (req, res) => {
  try {
    const username = String(req.params.username || "").trim().toLowerCase();
    if (!username) return res.status(400).json({ success: false, message: "Missing username" });
    if (!req.file) return res.status(400).json({ success: false, message: "No file uploaded" });

    const user = await User.findOne({ username });
    if (!user) return res.status(404).json({ success: false, message: "User not found" });

    // Save URL in DB
    const publicUrl = `/uploads/avatars/${req.file.filename}`;
    user.avatarUrl = publicUrl;
    await user.save();

    return res.json({ success: true, message: "Avatar uploaded", avatarUrl: publicUrl });
  } catch (err) {
    console.error("Upload avatar error:", err);
    return res.status(500).json({ success: false, message: "Server error", error: err.message });
  }
});

module.exports = router;
