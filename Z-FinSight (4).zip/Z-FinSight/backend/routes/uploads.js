const router = require("express").Router();
const multer = require("multer");
const Upload = require("../models/Upload");
const Transaction = require("../models/Transaction");
const { requireAuth, requireRole } = require("../middleware/auth");
const { resolveCompanyId } = require("../middleware/validateCompany");
const { parseCsvToRows, parseXlsxToRows, mapRowToTransaction } = require("../utils/parseFiles");

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 25 * 1024 * 1024 } });

router.post("/", requireAuth, requireRole(["accountant","admin"]), upload.single("file"), async (req, res) => {
  const companyId = resolveCompanyId(req);
  if (!req.file) return res.status(400).json({ success: false, message: "Missing file" });

  const filename = (req.file.originalname || "").toLowerCase();
  const isExcel = filename.endsWith(".xlsx") || filename.endsWith(".xls");
  const isCsv = filename.endsWith(".csv");
  const kind = isExcel || isCsv ? "transactions" : "generic";

  const up = await Upload.create({
    companyId,
    kind,
    originalName: req.file.originalname,
    mimeType: req.file.mimetype,
    size: req.file.size,
    parseStatus: "pending"
  });

  try {
    let created = 0;

    if (isExcel || isCsv) {
      const rows = isExcel ? parseXlsxToRows(req.file.buffer) : parseCsvToRows(req.file.buffer);
      const docs = rows
        .map(r => mapRowToTransaction(r, companyId, up._id))
        .filter(x => x && x.amount > 0);

      if (docs.length) {
        const inserted = await Transaction.insertMany(docs, { ordered: false });
        created = inserted.length;
      }

      up.parseStatus = "parsed";
      up.meta = { createdTransactions: created, rows: docs.length };
      await up.save();

      return res.json({ status: "parsed", uploadId: up._id, createdTransactions: created });
    }

    // non-parsed file types (pdf/images) stored as metadata only in MVP
    up.parseStatus = "parsed";
    up.meta = { storedOnly: true };
    await up.save();

    return res.json({ status: "stored", uploadId: up._id });
  } catch (e) {
    up.parseStatus = "failed";
    up.parseError = e.message;
    await up.save();
    return res.status(400).json({ success: false, message: e.message });
  }
});

module.exports = router;
