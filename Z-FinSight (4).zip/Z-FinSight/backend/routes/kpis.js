const express = require("express");
const KpiSnapshot = require("../models/KpiSnapshot");
const { calculateAllKPIs } = require("../utils/accountingCalculations");
const { startOfPeriod, endOfPeriod } = require("../utils/dates");

const {
  requireAuth,
  requireRoles,
  requireCompanyScope,
} = require("../middleware/authGuard");

const router = express.Router();

// GET /api/kpis/calculate - Calculate all KPIs for given period
router.get(
  "/calculate",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager", "financial"]),
  async (req, res) => {
    try {
      const companyId = req.userCompanyId;

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      // Get date range from query params or use current period
      const period = req.query.period || "current";
      const startDate = req.query.startDate
        ? new Date(req.query.startDate)
        : startOfPeriod(period);
      const endDate = req.query.endDate
        ? new Date(req.query.endDate)
        : endOfPeriod(period);

      // Calculate all KPIs
      const kpis = await calculateAllKPIs(companyId, startDate, endDate);

      res.json({
        success: true,
        data: {
          ...kpis,
          period_start: startDate,
          period_end: endDate,
        },
      });
    } catch (err) {
      console.error("kpis calculate error:", err);
      res.status(500).json({
        success: false,
        message: "Server error",
        error: err.message,
      });
    }
  }
);

// GET latest KPI snapshot
router.get(
  "/latest",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager", "financial"]),
  async (req, res) => {
    try {
      // ✅ KpiSnapshot uses String companyId (like "CMP_001"), not MongoDB ObjectId
      // Use companyCode if available, otherwise fetch from Company model
      let companyId = req.userCompanyCode; // Public code like "CMP_001"
      
      if (!companyId && req.userCompanyId) {
        // Fetch company code from MongoDB ObjectId
        const Company = require("../models/Company");
        const company = await Company.findById(req.userCompanyId).select("companyId").lean();
        if (company) {
          companyId = company.companyId;
        }
      }

      if (!companyId) {
        console.error("kpis latest: No companyId found", { 
          userCompanyId: req.userCompanyId, 
          userCompanyCode: req.userCompanyCode 
        });
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      console.log("📊 Fetching KPIs for companyId:", companyId);

      // Get the latest current snapshot, or fallback to most recent
      const latest = await KpiSnapshot.findOne({ 
        companyId,
        is_current: true 
      })
        .sort({ createdAt: -1 })
        .lean();
      
      // If no current snapshot, get the most recent one
      const fallback = latest || await KpiSnapshot.findOne({ companyId })
        .sort({ createdAt: -1 })
        .lean();

      if (fallback) {
        console.log("✅ Found KPI snapshot:", {
          companyId: fallback.companyId,
          afterTaxProfit: fallback.afterTaxProfit || fallback.net_profit_after_tax,
          netMargin: fallback.netMargin || fallback.net_profit_margin,
          is_current: fallback.is_current,
          createdAt: fallback.createdAt
        });
      } else {
        console.log("ℹ️ No KPI snapshot found for companyId:", companyId);
      }

      res.json(fallback || {});
    } catch (err) {
      console.error("kpis latest error:", err);
      res.status(500).json({ success: false, message: "Server error", error: err.message });
    }
  }
);

// GET /api/kpis/timeseries - Get historical KPI data for charts
router.get(
  "/timeseries",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager", "financial"]),
  async (req, res) => {
    try {
      // Get companyId (public code)
      let companyId = req.userCompanyCode;
      
      if (!companyId && req.userCompanyId) {
        const Company = require("../models/Company");
        const company = await Company.findById(req.userCompanyId).select("companyId").lean();
        if (company) {
          companyId = company.companyId;
        }
      }

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      // Get parameters
      const metric = req.query.metric || "net_profit_after_tax";
      const periodParam = req.query.period || "12m";
      
      // Parse period (6m, 12m, 24m)
      const months = parseInt(periodParam.replace("m", ""), 10) || 12;
      const maxMonths = Math.min(months, 24); // Cap at 24 months

      // Calculate date range
      const now = new Date();
      const startDate = new Date(now.getFullYear(), now.getMonth() - maxMonths, 1);
      startDate.setHours(0, 0, 0, 0);

      // Get all snapshots in range
      const snapshots = await KpiSnapshot.find({
        companyId,
        createdAt: { $gte: startDate }
      })
        .sort({ createdAt: 1 })
        .lean();

      if (snapshots.length === 0) {
        return res.json({
          success: true,
          data: [],
          metric,
          period: periodParam
        });
      }

      // Map metric to field name
      const metricFieldMap = {
        net_profit_after_tax: (s) => s.net_profit_after_tax || s.afterTaxProfit || 0,
        net_profit_margin: (s) => s.net_profit_margin || s.netMargin || 0,
        gross_profit: (s) => s.grossProfit || 0,
        revenue: (s) => s.revenue || 0,
        operating_profit: (s) => s.operating_profit || 0,
        profit_before_tax: (s) => s.profit_before_tax || 0,
        tax_burden: (s) => s.taxBurden || 0,
        current_ratio: (s) => s.current_ratio || s.liquidity || null,
      };

      const getValue = metricFieldMap[metric] || metricFieldMap.net_profit_after_tax;

      // Group by month
      const monthlyData = {};
      
      snapshots.forEach(snapshot => {
        const date = new Date(snapshot.createdAt || snapshot.updatedAt);
        const periodKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
        
        if (!monthlyData[periodKey]) {
          monthlyData[periodKey] = {
            period: periodKey,
            value: null,
            count: 0,
            values: []
          };
        }
        
        const value = getValue(snapshot);
        if (value !== null && value !== undefined) {
          monthlyData[periodKey].values.push(value);
          monthlyData[periodKey].count++;
        }
      });

      // Calculate average or latest value per month
      const timeseries = Object.keys(monthlyData)
        .sort()
        .map(period => {
          const monthData = monthlyData[period];
          // Use latest value in month (most recent snapshot)
          const latestValue = monthData.values.length > 0 
            ? monthData.values[monthData.values.length - 1]
            : null;
          
          return {
            period: monthData.period,
            value: latestValue !== null ? Math.round(latestValue * 100) / 100 : null
          };
        })
        .filter(item => item.value !== null);

      res.json({
        success: true,
        data: timeseries,
        metric,
        period: periodParam
      });
    } catch (err) {
      console.error("kpis timeseries error:", err);
      res.status(500).json({
        success: false,
        message: "Server error",
        error: err.message
      });
    }
  }
);

// Publish KPI snapshot
router.post(
  "/publish",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin"]),
  async (req, res) => {
    try {
      // ✅ KpiSnapshot uses String companyId (like "CMP_001"), not MongoDB ObjectId
      let companyId = req.userCompanyCode; // Public code like "CMP_001"
      
      if (!companyId && req.userCompanyId) {
        // Fetch company code from MongoDB ObjectId
        const Company = require("../models/Company");
        const company = await Company.findById(req.userCompanyId).select("companyId").lean();
        if (company) {
          companyId = company.companyId;
        }
      }
      
      if (!companyId) {
        return res.status(400).json({ 
          success: false, 
          message: "companyId is required" 
        });
      }

      const payload = req.body || {};

      // Mark previous KPIs as not current
      await KpiSnapshot.updateMany(
        { companyId },
        { $set: { is_current: false } }
      );

      const doc = await KpiSnapshot.create({
        companyId,
        period: payload.period || "",
        revenue: Number(payload.revenue || 0),
        cogs: Number(payload.cogs || 0),
        operating_expenses: Number(payload.operating_expenses || payload.opex || 0),
        opex: Number(payload.opex || payload.operating_expenses || 0), // Legacy field
        interest_expense: Number(payload.interest_expense || 0),
        taxes: Number(payload.taxes || 0),
        income_tax: Number(payload.income_tax || payload.taxes || 0),
        grossProfit: Number(payload.grossProfit || 0),
        operating_profit: Number(payload.operating_profit || 0),
        profit_before_tax: Number(payload.profit_before_tax || 0),
        afterTaxProfit: Number(payload.afterTaxProfit || payload.net_profit_after_tax || 0),
        net_profit_after_tax: Number(payload.net_profit_after_tax || payload.afterTaxProfit || 0),
        grossMargin: Number(payload.grossMargin || 0),
        operating_margin: Number(payload.operating_margin || 0),
        netMargin: Number(payload.netMargin || payload.net_profit_margin || 0),
        net_profit_margin: Number(payload.net_profit_margin || payload.netMargin || 0),
        taxBurden: Number(payload.taxBurden || 0),
        current_assets: Number(payload.current_assets || 0),
        current_liabilities: Number(payload.current_liabilities || 0),
        current_ratio:
          payload.current_ratio === null || payload.current_ratio === undefined
            ? null
            : Number(payload.current_ratio),
        liquidity:
          payload.liquidity === null || payload.liquidity === undefined
            ? payload.current_ratio === null || payload.current_ratio === undefined
              ? null
              : Number(payload.current_ratio)
            : Number(payload.liquidity), // Legacy field
        is_current: true,
        createdBy:
          (req.user && (req.user.username || req.user.fullName || req.user.email)) ||
          "",
      });

      // TODO: Emit WebSocket event and create notifications (if WebSocket/notification system exists)
      // io.to(`company:${companyId}`).emit('kpis:published', { ... });
      // await createNotification({ ... });

      res.json({ success: true, item: doc });
    } catch (err) {
      console.error("kpis publish error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

module.exports = router;