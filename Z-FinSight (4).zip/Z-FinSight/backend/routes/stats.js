const express = require("express");
const Transaction = require("../models/Transaction");
const BankLine = require("../models/BankLine");
const { getOverviewDashboardMetrics } = require("../utils/dashboardCalculations");
const { startOfPeriod, endOfPeriod } = require("../utils/dates");

const {
  requireAuth,
  requireRoles,
  requireCompanyScope,
} = require("../middleware/authGuard");

const router = express.Router();

// GET /api/stats/overview - Dashboard overview statistics
router.get(
  "/overview",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager", "financial"]),
  async (req, res) => {
    try {
      const companyId = req.userCompanyId;

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      // Get date range from query or use current period
      const period = req.query.period || "current";
      const startDate = req.query.startDate
        ? new Date(req.query.startDate)
        : startOfPeriod(period);
      const endDate = req.query.endDate
        ? new Date(req.query.endDate)
        : endOfPeriod(period);

      // Get all 7 overview dashboard metrics
      const metrics = await getOverviewDashboardMetrics(companyId, startDate, endDate);

      // Additional legacy fields for backward compatibility
      const totalTransactions = await Transaction.countDocuments({ companyId });
      const reconciledCount = await Transaction.countDocuments({
        companyId,
        reconciled: true,
      });

      res.json({
        success: true,
        // New metrics from document
        uncategorized: metrics.uncategorized,
        overdueInvoices: metrics.overdueInvoices,
        billsDue: metrics.billsDue,
        toReconcileCount: metrics.toReconcileCount,
        bankBalance: metrics.bankBalance,
        cashOnHand: metrics.cashOnHand,
        cashFlowTrend: metrics.cashFlowTrend,
        // Legacy fields for backward compatibility
        totalTransactions,
        reconciledCount,
        currency: "USD", // Default currency
      });
    } catch (err) {
      console.error("stats overview error:", err);
      res.status(500).json({
        success: false,
        message: "Server error",
        error: err.message,
      });
    }
  }
);

// GET /api/stats/revenue-trend - Monthly revenue trend (optional standalone)
router.get(
  "/revenue-trend",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager", "financial"]),
  async (req, res) => {
    try {
      const companyId = req.userCompanyId;

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      // Get months parameter (default: 6)
      const months = Math.min(parseInt(req.query.months || "6", 10), 24);

      const now = new Date();
      const startDate = new Date(now.getFullYear(), now.getMonth() - (months - 1), 1);

      const monthlyData = await Transaction.aggregate([
        {
          $match: {
            companyId,
            type: "income",
            date: { $gte: startDate },
          },
        },
        {
          $group: {
            _id: {
              year: { $year: "$date" },
              month: { $month: "$date" },
            },
            revenue: { $sum: "$amount" },
          },
        },
        {
          $sort: { "_id.year": 1, "_id.month": 1 },
        },
      ]);

      const trend = monthlyData.map((m) => ({
        month: `${m._id.year}-${String(m._id.month).padStart(2, "0")}`,
        revenue: m.revenue,
      }));

      res.json({ success: true, trend });
    } catch (err) {
      console.error("stats revenue-trend error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// GET /api/stats/top-spenders - Top expense categories
router.get(
  "/top-spenders",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager", "financial"]),
  async (req, res) => {
    try {
      const companyId = req.userCompanyId;

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      const limit = Math.min(parseInt(req.query.limit || "5", 10), 20);

      const topSpenders = await Transaction.aggregate([
        {
          $match: {
            companyId,
            type: "expense",
          },
        },
        {
          $group: {
            _id: "$category",
            total: { $sum: "$amount" },
          },
        },
        {
          $sort: { total: -1 },
        },
        {
          $limit: limit,
        },
        {
          $project: {
            _id: 0,
            category: "$_id",
            amount: "$total",
          },
        },
      ]);

      res.json({ success: true, items: topSpenders });
    } catch (err) {
      console.error("stats top-spenders error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

module.exports = router;