const router = require("express").Router();
const multer = require("multer");
const { requireAuth, requireRoles, requireCompanyScope } = require("../middleware/authGuard");
const Upload = require("../models/Upload");
const BankLine = require("../models/BankLine");
const Transaction = require("../models/Transaction");
const { parseCsvToRows, parseXlsxToRows } = require("../utils/parseFiles");
const { parseDateLoose } = require("../utils/dates");
const { abs2 } = require("../utils/money");

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 25 * 1024 * 1024 } });

function mapRowToBankLine(row, companyId, uploadId) {
  const date = parseDateLoose(row.date || row.posting_date || row.transaction_date) || new Date();
  const desc = String(row.description || row.memo || row.details || "").trim();
  let amount = Number(row.amount || row.value || 0);
  const currency = String(row.currency || "USD").toUpperCase();

  let direction = "out";
  if (String(row.direction || "").toLowerCase() === "in") direction = "in";
  else if (String(row.direction || "").toLowerCase() === "out") direction = "out";
  else {
    // infer from sign
    if (amount >= 0) direction = "in";
    else direction = "out";
  }
  amount = Math.abs(amount);

  return { companyId, uploadId, date, description: desc, amount, direction, currency };
}

async function autoMatch(companyId, bankLines) {
  // match by amount + date ±1 day and transaction.reconciled=false
  const results = { matched: 0, total: bankLines.length };

  for (const bl of bankLines) {
    try {
      const d0 = new Date(bl.date);
      const d1 = new Date(d0.getTime() - 1 * 86400000);
      const d2 = new Date(d0.getTime() + 1 * 86400000);

      const tx = await Transaction.findOne({
        companyId,
        reconciled: false,
        amount: { $gte: bl.amount - 0.01, $lte: bl.amount + 0.01 },
        date: { $gte: d1, $lte: d2 }
      }).sort({ date: -1 });

      if (tx) {
        bl.matched = true;
        bl.matchedTransactionId = tx._id;
        await bl.save();

        tx.reconciled = true;
        tx.reconcileRef = String(bl._id);
        tx.status = tx.status === "paid" ? "paid" : "reconciled";
        await tx.save();

        results.matched += 1;
      }
    } catch (err) {
      console.error("Error matching bank line:", err);
      continue;
    }
  }

  return results;
}

// POST /api/reconcile/upload - Upload bank statement
router.post(
  "/upload", 
  requireAuth, 
  requireCompanyScope,
  requireRoles(["accountant", "admin"]), 
  upload.single("statement"), 
  async (req, res) => {
    try {
      // ✅ SECURITY: Use companyId from JWT token only (set by requireCompanyScope)
      const companyId = req.userCompanyId;
      
      if (!companyId) {
        return res.status(400).json({ 
          success: false, 
          message: "companyId is required" 
        });
      }

      if (!req.file) {
        return res.status(400).json({ 
          success: false, 
          message: "Missing statement file" 
        });
      }

      const up = await Upload.create({
        companyId,
        kind: "bank_statement",
        originalName: req.file.originalname,
        mimeType: req.file.mimetype,
        size: req.file.size,
        parseStatus: "pending"
      });

      const name = (req.file.originalname || "").toLowerCase();
      let rows = [];
      
      if (name.endsWith(".xlsx") || name.endsWith(".xls")) {
        rows = parseXlsxToRows(req.file.buffer);
      } else if (name.endsWith(".csv")) {
        rows = parseCsvToRows(req.file.buffer);
      } else {
        throw new Error("Unsupported bank statement file type");
      }

      const docs = rows.map(r => mapRowToBankLine(r, companyId, up._id));
      const inserted = await BankLine.insertMany(docs, { ordered: false });

      up.parseStatus = "parsed";
      up.meta = { bankLines: inserted.length };
      await up.save();

      const matchRes = await autoMatch(companyId, inserted);

      const toReconcile = await BankLine.countDocuments({ 
        companyId, 
        matched: false 
      });

      res.json({
        success: true,
        uploadId: up._id,
        parsedLines: inserted.length,
        matched: matchRes.matched,
        toReconcile
      });
    } catch (e) {
      console.error("Reconcile upload error:", e);
      
      if (req.file) {
        try {
          const up = await Upload.findOne({
            originalName: req.file.originalname,
            companyId: req.userCompanyId
          }).sort({ createdAt: -1 });
          
          if (up) {
            up.parseStatus = "failed";
            up.parseError = e.message;
            await up.save();
          }
        } catch (updateErr) {
          console.error("Error updating upload status:", updateErr);
        }
      }
      
      res.status(400).json({ 
        success: false, 
        message: e.message 
      });
    }
  }
);

// GET /api/reconcile - Get reconciliation status
router.get(
  "/",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager", "financial"]),
  async (req, res) => {
    try {
      // ✅ SECURITY: Use companyId from JWT token only (set by requireCompanyScope)
      const companyId = req.userCompanyId;
      
      if (!companyId) {
        return res.status(400).json({ 
          success: false, 
          message: "companyId is required" 
        });
      }

      const totalBankLines = await BankLine.countDocuments({ companyId });
      const matchedLines = await BankLine.countDocuments({ companyId, matched: true });
      const unmatchedLines = totalBankLines - matchedLines;

      res.json({
        success: true,
        data: {
          totalBankLines,
          matchedLines,
          unmatchedLines,
          matchRate: totalBankLines > 0 ? (matchedLines / totalBankLines * 100).toFixed(1) : 0
        }
      });
    } catch (error) {
      console.error("Reconcile status error:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch reconciliation status"
      });
    }
  }
);

module.exports = router;