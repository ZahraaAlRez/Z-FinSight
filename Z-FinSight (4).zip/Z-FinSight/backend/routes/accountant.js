const router = require("express").Router();
const Transaction = require("../models/Transaction");
const BankLine = require("../models/BankLine");
const {
  requireAuth,
  requireCompanyScope,
  requireRoles,
} = require("../middleware/authGuard");

// GET accountant dashboard summary
router.get(
  "/summary",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin"]),
  async (req, res) => {
    try {
      const companyId = req.userCompanyId;

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      const now = new Date();
      const currentMonth = now.toISOString().slice(0, 7); // YYYY-MM
      const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);

      // Parallel queries for better performance
      const [
        uncategorizedCount,
        overdueInvoices,
        billsDue,
        unmatchedBankLines,
        totalIncome,
        totalExpenses,
        reconciledTransactions,
      ] = await Promise.all([
        // Uncategorized transactions
        Transaction.countDocuments({
          companyId,
          category: { $in: ["Uncategorized", "", null] },
        }),

        // Overdue invoices (income transactions with status != "paid" and due date passed)
        Transaction.countDocuments({
          companyId,
          type: "income",
          status: { $ne: "paid" },
          date: { $lt: now },
        }),

        // Bills due (expense transactions with status != "paid" and due date approaching)
        Transaction.countDocuments({
          companyId,
          type: "expense",
          status: { $ne: "paid" },
          date: { $gte: now, $lte: new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000) }, // Next 7 days
        }),

        // Unmatched bank lines
        BankLine.countDocuments({
          companyId,
          matched: false,
        }),

        // Total income this month
        Transaction.aggregate([
          {
            $match: {
              companyId,
              type: "income",
              date: { $gte: startOfMonth, $lte: endOfMonth },
            },
          },
          {
            $group: {
              _id: null,
              total: { $sum: "$amount" },
            },
          },
        ]),

        // Total expenses this month
        Transaction.aggregate([
          {
            $match: {
              companyId,
              type: "expense",
              date: { $gte: startOfMonth, $lte: endOfMonth },
            },
          },
          {
            $group: {
              _id: null,
              total: { $sum: "$amount" },
            },
          },
        ]),

        // Reconciled transactions count
        Transaction.countDocuments({
          companyId,
          reconciled: true,
        }),
      ]);

      // Calculate bank balance (sum of all reconciled income - expenses)
      const bankBalanceResult = await Transaction.aggregate([
        {
          $match: {
            companyId,
            reconciled: true,
          },
        },
        {
          $group: {
            _id: null,
            income: {
              $sum: {
                $cond: [{ $eq: ["$type", "income"] }, "$amount", 0],
              },
            },
            expenses: {
              $sum: {
                $cond: [{ $eq: ["$type", "expense"] }, "$amount", 0],
              },
            },
          },
        },
      ]);

      const bankBalance =
        bankBalanceResult.length > 0
          ? (bankBalanceResult[0].income || 0) - (bankBalanceResult[0].expenses || 0)
          : 0;

      // Cash on hand (unreconciled income - expenses)
      const cashOnHandResult = await Transaction.aggregate([
        {
          $match: {
            companyId,
            reconciled: false,
          },
        },
        {
          $group: {
            _id: null,
            income: {
              $sum: {
                $cond: [{ $eq: ["$type", "income"] }, "$amount", 0],
              },
            },
            expenses: {
              $sum: {
                $cond: [{ $eq: ["$type", "expense"] }, "$amount", 0],
              },
            },
          },
        },
      ]);

      const cashOnHand =
        cashOnHandResult.length > 0
          ? (cashOnHandResult[0].income || 0) - (cashOnHandResult[0].expenses || 0)
          : 0;

      // Calculate liquidity (quick ratio approximation: cash / total expenses)
      const totalExpensesAmount =
        totalExpenses.length > 0 ? totalExpenses[0].total || 0 : 0;
      const liquidity =
        totalExpensesAmount > 0
          ? ((bankBalance + cashOnHand) / totalExpensesAmount) * 100
          : 0;

      const totalIncomeAmount =
        totalIncome.length > 0 ? totalIncome[0].total || 0 : 0;

      res.json({
        success: true,
        data: {
          period: currentMonth,
          currency: "USD", // TODO: Get from company settings
          uncategorized: uncategorizedCount,
          overdueInvoices,
          billsDue,
          toReconcile: unmatchedBankLines,
          bankBalance: Math.round(bankBalance * 100) / 100,
          cashOnHand: Math.round(cashOnHand * 100) / 100,
          liquidity: Math.round(liquidity * 100) / 100,
          totalIncome: Math.round(totalIncomeAmount * 100) / 100,
          totalExpenses: Math.round(totalExpensesAmount * 100) / 100,
          reconciledCount: reconciledTransactions,
          tasks: [
            {
              title: "Categorize new transactions",
              desc: "Review uncategorized lines.",
              count: uncategorizedCount,
              go: "transactions",
              color: "#10b981",
            },
            {
              title: "Follow up overdue invoices",
              desc: "Send reminders / check payments.",
              count: overdueInvoices,
              go: "reports",
              color: "#f97316",
            },
            {
              title: "Pay bills due",
              desc: "Avoid late fees.",
              count: billsDue,
              go: "reports",
              color: "#0ea5e9",
            },
            {
              title: "Reconcile bank lines",
              desc: "Match statement to transactions.",
              count: unmatchedBankLines,
              go: "reconcile",
              color: "#8b5cf6",
            },
          ],
        },
      });
    } catch (error) {
      console.error("Accountant summary error:", error);
      res.status(500).json({
        success: false,
        message: "Failed to fetch summary",
        error: process.env.NODE_ENV === "development" ? error.message : undefined,
      });
    }
  }
);

module.exports = router;