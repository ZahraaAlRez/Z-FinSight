// backend/routes/notifications.js
const express = require("express");
const Notification = require("../models/Notification");

const {
  requireAuth,
  requireRoles,
  requireCompanyScope,
} = require("../middleware/authGuard");

const router = express.Router();

// ============================================
// GET /api/notifications - List notifications
// ============================================
router.get(
  "/",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager", "financial", "external"]),
  async (req, res) => {
    try {
      // ✅ SECURITY: Use companyId from JWT token only
      const companyId = req.userCompanyId;
      const userId = req.user.userId;

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      // Query params
      const limit = Math.min(parseInt(req.query.limit || "50", 10), 200);
      const page = Math.max(parseInt(req.query.page || "1", 10), 1);
      const skip = (page - 1) * limit;
      const readFilter = req.query.read; // "true", "false", or undefined (all)

      // Build query
      const query = { companyId };
      
      // User-specific or company-wide notifications
      query.$or = [
        { userId: userId },  // Notifications for this specific user
        { userId: null }     // Company-wide notifications
      ];

      // Filter by read status
      if (readFilter === "true") query.read = true;
      if (readFilter === "false") query.read = false;

      // Execute query
      const [items, total, unread] = await Promise.all([
        Notification.find(query)
          .sort({ priority: -1, createdAt: -1 }) // Urgent first, then newest
          .skip(skip)
          .limit(limit)
          .lean(),
        Notification.countDocuments(query),
        Notification.getUnreadCount(companyId, userId)
      ]);

      res.json({
        success: true,
        items,
        total,
        unread,
        page,
        limit,
      });
    } catch (err) {
      console.error("notifications list error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// ============================================
// GET /api/notifications/unread - Get unread count
// ============================================
router.get(
  "/unread",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager", "financial", "external"]),
  async (req, res) => {
    try {
      const companyId = req.userCompanyId;
      const userId = req.user.userId;

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      const unread = await Notification.getUnreadCount(companyId, userId);

      res.json({
        success: true,
        unread,
      });
    } catch (err) {
      console.error("notifications unread error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// ============================================
// POST /api/notifications - Create notification
// ============================================
router.post(
  "/",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin"]),
  async (req, res) => {
    try {
      const companyId = req.userCompanyId;

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      const {
        userId,
        type,
        title,
        message,
        link,
        priority,
        relatedModel,
        relatedId,
        expiresAt
      } = req.body || {};

      if (!title || !message) {
        return res.status(400).json({
          success: false,
          message: "title and message are required",
        });
      }

      const notification = await Notification.create({
        companyId,
        userId: userId || null,
        type: type || "info",
        title,
        message,
        link: link || null,
        priority: priority || "medium",
        source: "manual",
        relatedModel: relatedModel || null,
        relatedId: relatedId || null,
        expiresAt: expiresAt ? new Date(expiresAt) : null,
        createdBy: req.user.username || req.user.fullName || req.user.email || "admin"
      });

      res.status(201).json({
        success: true,
        item: notification,
      });
    } catch (err) {
      console.error("notifications create error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// ============================================
// PATCH /api/notifications/:id/read - Mark as read
// ============================================
router.patch(
  "/:id/read",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager", "financial", "external"]),
  async (req, res) => {
    try {
      const companyId = req.userCompanyId;
      const id = req.params.id;

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      // Find and update
      const notification = await Notification.findOneAndUpdate(
        { _id: id, companyId },
        { 
          read: true, 
          readAt: new Date() 
        },
        { new: true }
      ).lean();

      if (!notification) {
        return res.status(404).json({
          success: false,
          message: "Notification not found",
        });
      }

      res.json({
        success: true,
        item: notification,
      });
    } catch (err) {
      console.error("notifications mark read error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// ============================================
// PATCH /api/notifications/read-all - Mark all as read
// ============================================
router.patch(
  "/read-all",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager", "financial", "external"]),
  async (req, res) => {
    try {
      const companyId = req.userCompanyId;
      const userId = req.user.userId;

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      // Mark all unread notifications as read
      const result = await Notification.updateMany(
        { 
          companyId, 
          read: false,
          $or: [{ userId }, { userId: null }]
        },
        { 
          read: true, 
          readAt: new Date() 
        }
      );

      res.json({
        success: true,
        updated: result.modifiedCount,
      });
    } catch (err) {
      console.error("notifications mark all read error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// ============================================
// DELETE /api/notifications/:id - Delete notification
// ============================================
router.delete(
  "/:id",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin"]),
  async (req, res) => {
    try {
      const companyId = req.userCompanyId;
      const id = req.params.id;

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      const deleted = await Notification.findOneAndDelete({
        _id: id,
        companyId,
      }).lean();

      if (!deleted) {
        return res.status(404).json({
          success: false,
          message: "Notification not found",
        });
      }

      res.json({
        success: true,
      });
    } catch (err) {
      console.error("notifications delete error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// ============================================
// DELETE /api/notifications/cleanup - Delete all read
// ============================================
router.delete(
  "/cleanup",
  requireAuth,
  requireCompanyScope,
  requireRoles(["admin"]),
  async (req, res) => {
    try {
      const companyId = req.userCompanyId;

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      // Delete all read notifications older than 30 days
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

      const result = await Notification.deleteMany({
        companyId,
        read: true,
        readAt: { $lte: thirtyDaysAgo }
      });

      res.json({
        success: true,
        deleted: result.deletedCount,
      });
    } catch (err) {
      console.error("notifications cleanup error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

module.exports = router;