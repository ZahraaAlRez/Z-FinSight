const express = require("express");
const router = express.Router();

const Company = require("../models/Company");
const TopCompaniesSnapshot = require("../models/TopCompaniesSnapshot");
const { extractLanguage } = require("../utils/langHelper");

function pickCompanyId(req) {
  return (req.query.companyId || req.params.companyId || "").trim();
}

// GET /api/top-companies?companyId=CMP_007&lang=ar|en
router.get("/", async (req, res) => {
  try {
    const companyPublicId = pickCompanyId(req);

    if (!companyPublicId) {
      return res.status(400).json({ ok: false, message: "companyId is required" });
    }

    const company = await Company.findOne({ companyId: companyPublicId });
    if (!company) {
      return res.status(404).json({ ok: false, message: "Company not found" });
    }

    // ✅ Extract language preference
    const language = extractLanguage(req);
    
    // If company has stored language and no explicit lang param, use company's preference
    const effectiveLang = req.query.lang ? language : (company.language || language);

    // Get actual companies from the system (excluding current company)
    let otherCompanies = [];
    try {
      otherCompanies = await Company.find({ 
        isActive: true,
        companyId: { $ne: companyPublicId } // Exclude current company
      })
        .select('companyId companyName industry country companyEmail')
        .sort({ companyName: 1 })
        .limit(20) // Top 20 companies
        .lean();
    } catch (queryErr) {
      console.error("Error querying companies:", queryErr);
      // Continue with empty array if query fails
      otherCompanies = [];
    }

    // Format companies data similar to TopCompaniesSnapshot structure
    const companies = (otherCompanies || []).map((comp, index) => {
      try {
        return {
          rank: index + 1,
          companyId: comp.companyId || '',
          name: comp.companyName || comp.name || 'Unknown',
          industry: comp.industry || '',
          country: comp.country || '',
          email: comp.companyEmail || '',
          // Add some dummy metrics for display
          revenue: Math.floor(Math.random() * 10000000) + 1000000, // Random revenue between 1M-10M
          growth: (Math.random() * 20 - 5).toFixed(1), // Random growth between -5% to 15%
        };
      } catch (mapErr) {
        console.error("Error mapping company:", mapErr, comp);
        return null;
      }
    }).filter(c => c !== null); // Remove any null entries

    const lastUpdated = new Date();

    // ✅ Prepare response (company names stay original, only UI labels would be translated)
    const responseData = { 
      companies,
      fetchedAt: lastUpdated,
      total: companies.length
    };

    return res.json({
      ok: true,
      data: responseData,
      meta: {
        companyId: companyPublicId,
        source: companies.length > 0 ? "database" : "empty",
        lastUpdated,
        language: effectiveLang, // ✅ Include language in response
      },
    });
  } catch (err) {
    console.error("❌ /api/top-companies error:", err);
    console.error("Error stack:", err.stack);
    return res.status(500).json({ 
      ok: false, 
      message: "Server error",
      error: process.env.NODE_ENV === "development" ? err.message : undefined
    });
  }
});

module.exports = router;