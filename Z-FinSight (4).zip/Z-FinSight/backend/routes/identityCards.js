const express = require("express");
const nodemailer = require("nodemailer");
const User = require("../models/User");
const Company = require("../models/Company");
const { requireAuth, requireActiveCompany } = require("../middleware/authGuard");
const { extractLanguage } = require("../utils/langHelper");

const router = express.Router();

// ============================================
// GET /api/identity-cards - Get Identity Cards
// ============================================
router.get("/", requireAuth, async (req, res) => {
  try {
    const { companyId } = req.query;

    // ✅ Validate companyId
    if (!companyId) {
      return res.status(400).json({
        success: false,
        message: "companyId is required",
      });
    }

    // ✅ Fetch company
    const company = await Company.findOne({ companyId });
    if (!company) {
      return res.status(404).json({
        success: false,
        message: "Company not found",
      });
    }

    // ✅ Extract language preference
    const language = extractLanguage(req);
    const effectiveLang = req.query.lang ? language : (company.language || language);

    // ✅ Fetch all users from this company
    const users = await User.find({
      companyId: company._id,
    }).select("-passwordHash");

    // ✅ Generate identity cards
    const identityCards = users.map((user) => ({
      companyName: company.companyName,
      companyId: company.companyId,
      user: {
        id: user._id,
        fullName: user.fullName,
        username: user.username,
        department: user.department || "",
        roles: user.roles || [],
        email: user.email,
        avatarUrl: user.avatarUrl || "",
      },
      canShare: true,
      canPrint: true,
    }));

    console.log(`✅ Retrieved ${identityCards.length} identity cards for company: ${companyId}`);

    return res.json({
      success: true,
      count: identityCards.length,
      data: identityCards,
      language: effectiveLang,
    });
  } catch (err) {
    console.error("❌ Get identity cards error:", err);
    res.status(500).json({
      success: false,
      message: "Server error",
      error: err.message,
    });
  }
});

// ============================================
// POST /api/identity-cards/share - Share via Email (Bilingual)
// ============================================
router.post("/share", requireAuth, async (req, res) => {
  try {
    const { email, cardData, lang } = req.body;

    // ✅ Determine language
    const language = lang || extractLanguage(req);
    const isArabic = language.includes('ar');

    // ✅ Validation
    if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
      return res.status(400).json({
        success: false,
        message: isArabic ? "البريد الإلكتروني غير صالح" : "Valid email is required",
      });
    }

    if (!cardData || !cardData.user || !cardData.companyName) {
      return res.status(400).json({
        success: false,
        message: isArabic ? "بيانات البطاقة مطلوبة" : "Valid cardData is required",
      });
    }

    // ✅ Create transporter
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.GMAIL_USER,
        pass: process.env.GMAIL_APP_PASSWORD,
      },
    });

    // ✅ Bilingual email content
    const emailContent = isArabic ? {
      subject: `بطاقة الهوية - ${cardData.user.fullName}`,
      title: "🪪 بطاقة الهوية",
      subtitle: "Z-FinSight",
      intro: "لقد استلمت بطاقة هوية لـ:",
      companyLabel: "الشركة:",
      companyIdLabel: "رقم الشركة:",
      nameLabel: "الاسم الكامل:",
      usernameLabel: "اسم المستخدم:",
      emailLabel: "البريد الإلكتروني:",
      departmentLabel: "القسم:",
      rolesLabel: "الأدوار:",
      passwordLabel: "كلمة المرور المؤقتة:",
      note: "تؤكد بطاقة الهوية هذه دور عضو الفريق وصلاحياته داخل المنظمة.",
      passwordNote: "⚠️ يرجى تغيير كلمة المرور عند تسجيل الدخول لأول مرة.",
      footer1: `© ${new Date().getFullYear()} Z-FinSight. جميع الحقوق محفوظة.`,
      footer2: "هذه رسالة تلقائية. يرجى عدم الرد على هذا البريد الإلكتروني.",
      direction: "rtl"
    } : {
      subject: `Identity Card - ${cardData.user.fullName}`,
      title: "🪪 Identity Card",
      subtitle: "Z-FinSight",
      intro: "You have received an identity card for:",
      companyLabel: "Company:",
      companyIdLabel: "Company ID:",
      nameLabel: "Full Name:",
      usernameLabel: "Username:",
      emailLabel: "Email:",
      departmentLabel: "Department:",
      rolesLabel: "Roles:",
      passwordLabel: "Temporary Password:",
      note: "This identity card confirms the team member's role and permissions within the organization.",
      passwordNote: "⚠️ Please change your password on first login.",
      footer1: `© ${new Date().getFullYear()} Z-FinSight. All rights reserved.`,
      footer2: "This is an automated message. Please do not reply to this email.",
      direction: "ltr"
    };

    // ✅ Generate bilingual HTML email
    const htmlContent = `
      <!DOCTYPE html>
      <html dir="${emailContent.direction}">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
          body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
            direction: ${emailContent.direction};
          }
          .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #ffffff;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
          }
          .header {
            background: linear-gradient(135deg, #06d6a0 0%, #0891b2 100%);
            color: #ffffff;
            padding: 32px 24px;
            text-align: center;
          }
          .header h1 {
            margin: 0 0 8px 0;
            font-size: 28px;
            font-weight: 800;
          }
          .header p {
            margin: 0;
            font-size: 14px;
            opacity: 0.95;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
          }
          .content {
            padding: 32px 28px;
          }
          .content h2 {
            margin: 0 0 8px 0;
            font-size: 20px;
            color: #0a0e1a;
          }
          .content > p {
            margin: 0 0 24px 0;
            color: #64748b;
            font-size: 15px;
          }
          .card {
            border: 2px solid #06d6a0;
            border-radius: 12px;
            padding: 24px;
            margin: 20px 0;
            background: linear-gradient(135deg, #f0fdfa 0%, #ecfeff 100%);
          }
          .card-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 14px 0;
            padding: 12px 0;
            border-bottom: 1px solid rgba(6, 214, 160, 0.2);
          }
          .card-row:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
          }
          .label {
            font-weight: 700;
            color: #0891b2;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            min-width: 140px;
          }
          .value {
            color: #0a0e1a;
            font-weight: 600;
            font-size: 15px;
            text-align: ${isArabic ? 'left' : 'right'};
            flex: 1;
          }
          .roles {
            display: inline-block;
            background: linear-gradient(135deg, #06d6a0, #0891b2);
            color: white;
            padding: 6px 14px;
            border-radius: 6px;
            margin: 3px;
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
          }
          .note {
            background: #fef3c7;
            border-${isArabic ? 'right' : 'left'}: 4px solid #f59e0b;
            padding: 16px 20px;
            border-radius: 8px;
            margin: 24px 0 0 0;
          }
          .note p {
            margin: 0;
            color: #92400e;
            font-size: 14px;
            line-height: 1.6;
          }
          .footer {
            background-color: #0a0e1a;
            padding: 24px;
            text-align: center;
            color: #94a3b8;
            font-size: 13px;
          }
          .footer p {
            margin: 8px 0;
            line-height: 1.6;
          }
          @media (max-width: 600px) {
            .card-row {
              flex-direction: column;
              align-items: flex-start;
              gap: 8px;
            }
            .label {
              min-width: auto;
            }
            .value {
              text-align: ${isArabic ? 'right' : 'left'};
            }
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>${emailContent.title}</h1>
            <p>${emailContent.subtitle}</p>
          </div>
          
          <div class="content">
            <h2>${emailContent.intro}</h2>
            
            <div class="card">
              <div class="card-row">
                <span class="label">${emailContent.companyLabel}</span>
                <span class="value">${escapeHtml(cardData.companyName)}</span>
              </div>
              <div class="card-row">
                <span class="label">${emailContent.companyIdLabel}</span>
                <span class="value">${escapeHtml(cardData.companyId)}</span>
              </div>
              <div class="card-row">
                <span class="label">${emailContent.nameLabel}</span>
                <span class="value">${escapeHtml(cardData.user.fullName)}</span>
              </div>
              <div class="card-row">
                <span class="label">${emailContent.usernameLabel}</span>
                <span class="value">${escapeHtml(cardData.user.username)}</span>
              </div>
              <div class="card-row">
                <span class="label">${emailContent.emailLabel}</span>
                <span class="value">${escapeHtml(cardData.user.email)}</span>
              </div>
              <div class="card-row">
                <span class="label">${emailContent.departmentLabel}</span>
                <span class="value">${escapeHtml(cardData.user.department || 'N/A')}</span>
              </div>
              <div class="card-row">
                <span class="label">${emailContent.rolesLabel}</span>
                <span class="value">
                  ${(cardData.user.roles || []).map(role => `<span class="roles">${escapeHtml(role)}</span>`).join('')}
                </span>
              </div>
              ${cardData.user.password ? `
              <div class="card-row" style="background: #fef3c7; border: 2px solid #f59e0b; border-radius: 8px; padding: 16px; margin-top: 16px;">
                <span class="label" style="color: #92400e;">${emailContent.passwordLabel}</span>
                <span class="value" style="color: #92400e; font-family: monospace; font-size: 18px; font-weight: 800; letter-spacing: 2px;">${escapeHtml(cardData.user.password)}</span>
              </div>
              ` : ''}
            </div>
            
            <div class="note">
              <p>${emailContent.note}</p>
              ${cardData.user.password ? `<p style="margin-top: 12px; font-weight: 700;">${emailContent.passwordNote}</p>` : ''}
            </div>
          </div>
          
          <div class="footer">
            <p><strong>${emailContent.footer1}</strong></p>
            <p>${emailContent.footer2}</p>
          </div>
        </div>
      </body>
      </html>
    `;

    // ✅ Send email
    await transporter.sendMail({
      from: `"Z-FinSight" <${process.env.GMAIL_USER}>`,
      to: email,
      subject: emailContent.subject,
      html: htmlContent,
    });

    console.log(`✅ Identity card shared to: ${email} - Language: ${language}`);

    return res.json({
      success: true,
      message: isArabic 
        ? "تم مشاركة بطاقة الهوية بنجاح" 
        : "Identity card shared successfully",
    });
  } catch (err) {
    console.error("❌ Share identity card error:", err);
    res.status(500).json({
      success: false,
      message: req.body.lang?.includes('ar') 
        ? "فشل في مشاركة بطاقة الهوية" 
        : "Failed to share identity card",
      error: err.message,
    });
  }
});

// ✅ Helper function to escape HTML
function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

module.exports = router;