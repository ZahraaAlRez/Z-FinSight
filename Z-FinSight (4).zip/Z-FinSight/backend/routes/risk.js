const express = require("express");
const router = express.Router();

const Company = require("../models/Company");
const FxRateSnapshot = require("../models/FxRateSnapshot");
const {
  requireAuth,
  requireCompanyScope,
  requireRoles,
} = require("../middleware/authGuard");

// GET /api/risk/fx - Calculate FX risk level based on currency exposure
router.get(
  "/fx",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager", "financial"]),
  async (req, res) => {
    try {
      // Get companyId (public code)
      let companyId = req.userCompanyCode;
      
      if (!companyId && req.userCompanyId) {
        const company = await Company.findById(req.userCompanyId).select("companyId currencies").lean();
        if (company) {
          companyId = company.companyId;
        }
      }

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      // Get company details
      const company = await Company.findOne({ companyId }).select("currencies").lean();
      if (!company) {
        return res.status(404).json({
          success: false,
          message: "Company not found",
        });
      }

      const currencies = company.currencies || [];
      if (currencies.length === 0) {
        return res.json({
          success: true,
          riskLevel: "Low",
          message: "No currencies configured",
          exposure: {},
          rates: []
        });
      }

      // Get latest FX snapshot
      const snapshot = await FxRateSnapshot.findOne({ companyId })
        .sort({ fetchedAt: -1, createdAt: -1 })
        .lean();

      if (!snapshot || !snapshot.rates || snapshot.rates.length === 0) {
        return res.json({
          success: true,
          riskLevel: "Low",
          message: "No FX data available",
          exposure: {},
          rates: []
        });
      }

      // Analyze rates for risk
      const rates = snapshot.rates || [];
      let maxChangePercent = 0;
      let totalExposure = 0;
      const exposure = {};

      // Calculate exposure and find max volatility
      rates.forEach(rate => {
        const changePercent = Math.abs(rate.changePercent || 0);
        maxChangePercent = Math.max(maxChangePercent, changePercent);
        
        // Track exposure per currency pair
        const pairKey = `${rate.base}/${rate.target}`;
        exposure[pairKey] = {
          base: rate.base,
          target: rate.target,
          rate: rate.rate,
          change: rate.change,
          changePercent: rate.changePercent,
          volatility: changePercent
        };

        // If changePercent is significant, add to total exposure
        if (changePercent > 0) {
          totalExposure += changePercent;
        }
      });

      // Determine risk level based on volatility thresholds
      let riskLevel = "Low";
      if (maxChangePercent >= 5) {
        riskLevel = "High";
      } else if (maxChangePercent >= 2) {
        riskLevel = "Medium";
      }

      // Calculate average volatility
      const avgVolatility = rates.length > 0
        ? totalExposure / rates.length
        : 0;

      res.json({
        success: true,
        riskLevel,
        exposure: {
          maxVolatility: Math.round(maxChangePercent * 100) / 100,
          avgVolatility: Math.round(avgVolatility * 100) / 100,
          currencyPairs: exposure,
          totalPairs: rates.length
        },
        rates: rates.map(r => ({
          base: r.base,
          target: r.target,
          rate: r.rate,
          changePercent: r.changePercent
        })),
        baseCurrency: currencies[0] || "USD", // First currency as base
        currencies
      });
    } catch (err) {
      console.error("fx risk error:", err);
      res.status(500).json({
        success: false,
        message: "Server error",
        error: err.message
      });
    }
  }
);

module.exports = router;
