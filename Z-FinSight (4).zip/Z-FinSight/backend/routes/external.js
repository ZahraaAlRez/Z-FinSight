// backend/routes/external.js
const express = require("express");
const ExternalSnapshot = require("../models/ExternalSnapshot");
const User = require("../models/User");
const Company = require("../models/Company");
const KpiSnapshot = require("../models/KpiSnapshot");
const Recommendation = require("../models/Recommendation");
const Transaction = require("../models/Transaction");
const {
  requireAuth,
  requireRoles,
  requireCompanyScope,
  checkExternalAccess,
} = require("../middleware/authGuard");

const router = express.Router();

// Helper function to get company public code from JWT token
async function getCompanyPublicCode(req) {
  const companyCode = req.userCompanyCode;
  if (companyCode) return companyCode;
  
  const companyDbId = req.userCompanyId;
  if (companyDbId) {
    const company = await Company.findById(companyDbId).lean();
    if (company) {
      return company.companyId; // Public code
    }
  }
  return null;
}

// Helper function to get pack templates (matching frontend)
function getPackTemplates() {
  return {
    bank: {
      key: "bank",
      labelEn: "Bank Pack",
      labelAr: "حزمة بنك",
      allowedPages: ["overview", "reports", "news", "notes", "settings"],
      flags: {
        allowNews: true,
        allowTopCompanies: false,
        allowExternalRecs: true,
        allowInternalRecs: false,
        allowExport: true,
        allowDocs: true,
        allowNotes: true
      },
      masking: { hideVendors: false, hideCustomers: false, hidePayroll: false }
    },
    investor: {
      key: "investor",
      labelEn: "Investor Pack",
      labelAr: "حزمة مستثمر",
      allowedPages: ["overview", "reports", "news", "notes", "settings"],
      flags: {
        allowNews: true,
        allowTopCompanies: true,
        allowExternalRecs: true,
        allowInternalRecs: false,
        allowExport: true,
        allowDocs: false,
        allowNotes: true
      },
      masking: { hideVendors: true, hideCustomers: true, hidePayroll: true }
    },
    auditor: {
      key: "auditor",
      labelEn: "Auditor Pack",
      labelAr: "حزمة مدقق",
      allowedPages: ["overview", "reports", "news", "notes", "settings"],
      flags: {
        allowNews: false,
        allowTopCompanies: false,
        allowExternalRecs: false,
        allowInternalRecs: false,
        allowExport: true,
        allowDocs: true,
        allowNotes: true
      },
      masking: { hideVendors: false, hideCustomers: false, hidePayroll: false }
    },
    partner: {
      key: "partner",
      labelEn: "Partner Pack",
      labelAr: "حزمة شريك",
      allowedPages: ["overview", "reports", "news", "notes", "settings"],
      flags: {
        allowNews: true,
        allowTopCompanies: false,
        allowExternalRecs: true,
        allowInternalRecs: false,
        allowExport: false,
        allowDocs: false,
        allowNotes: true
      },
      masking: { hideVendors: true, hideCustomers: true, hidePayroll: true }
    }
  };
}

// Helper function to get pack type from JWT token (for external users)
function getUserPackType(req) {
  const { roles, externalType } = req.user;
  
  if (!roles || !roles.includes('external')) {
    return null;
  }
  
  // Map User.externalType enum to pack type
  const typeMap = {
    'bank': 'bank',
    'investor': 'investor',
    'auditor': 'auditor',
    'government': 'auditor', // Map government to auditor pack
    'other': 'partner' // Map other to partner pack
  };
  
  return typeMap[externalType] || 'bank';
}

// ============================================
// GET /api/external/pack - Get pack configuration
// ============================================
router.get(
  "/pack",
  requireAuth,
  requireCompanyScope,
  requireRoles(["external"]),
  checkExternalAccess,
  async (req, res) => {
    try {
      // ✅ SECURITY: Pack type comes from user's externalType (from JWT token)
      // NEVER accept pack from query params
      const packType = getUserPackType(req);
      
      if (!packType) {
        return res.status(403).json({
          success: false,
          message: "Invalid external user type",
        });
      }
      
      const templates = getPackTemplates();
      const pack = templates[packType];
      
      if (!pack) {
        return res.status(404).json({
          success: false,
          message: "Pack not found",
        });
      }
      
      res.json({
        success: true,
        packKey: pack.key,
        label: pack.labelEn,
        labelAr: pack.labelAr,
        allowedPages: pack.allowedPages,
        flags: pack.flags,
        masking: pack.masking,
      });
    } catch (err) {
      console.error("external pack error:", err);
      res.status(500).json({
        success: false,
        message: "Server error",
        error: err.message,
      });
    }
  }
);

// ============================================
// GET /api/external/snapshot - Get latest published snapshot
// ============================================
router.get(
  "/snapshot",
  requireAuth,
  requireCompanyScope,
  requireRoles(["external"]),
  checkExternalAccess,
  async (req, res) => {
    try {
      // ✅ SECURITY: companyId and packType from token only
      const companyId = await getCompanyPublicCode(req);
      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }
      
      const packType = getUserPackType(req);
      if (!packType) {
        return res.status(403).json({
          success: false,
          message: "Invalid external user type",
        });
      }
      
      // Get latest snapshot
      const snapshot = await ExternalSnapshot.getLatest(companyId, packType);
      
      if (!snapshot) {
        return res.status(404).json({
          success: false,
          message: "No published snapshot found",
        });
      }
      
      // Return snapshot data
      res.json({
        success: true,
        currency: snapshot.currency || "USD",
        netProfit: snapshot.metrics?.netProfit,
        netMargin: snapshot.metrics?.netMargin,
        liquidity: snapshot.metrics?.liquidity,
        debtEquity: snapshot.metrics?.debtEquity,
        cashBank: snapshot.metrics?.cashBank,
        runwayMonths: snapshot.metrics?.runwayMonths,
        liq: snapshot.liquidity || {},
        debt: snapshot.debt || {},
        cf: snapshot.cashflow || {},
        note: snapshot.note || "",
        period: snapshot.period || "",
        publishedAt: snapshot.publishedAt,
      });
    } catch (err) {
      console.error("external snapshot error:", err);
      res.status(500).json({
        success: false,
        message: "Server error",
        error: err.message,
      });
    }
  }
);

// ============================================
// GET /api/external/summary - Alias for snapshot
// ============================================
router.get(
  "/summary",
  requireAuth,
  requireCompanyScope,
  requireRoles(["external"]),
  checkExternalAccess,
  async (req, res) => {
    // Redirect to snapshot endpoint
    req.url = "/snapshot";
    return router.handle(req, res);
  }
);

// ============================================
// GET /api/external/reports - Get reports list
// ============================================
router.get(
  "/reports",
  requireAuth,
  requireCompanyScope,
  requireRoles(["external"]),
  checkExternalAccess,
  async (req, res) => {
    try {
      const companyId = await getCompanyPublicCode(req);
      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }
      
      const packType = getUserPackType(req);
      if (!packType) {
        return res.status(403).json({
          success: false,
          message: "Invalid external user type",
        });
      }
      
      // Get latest snapshot
      const snapshot = await ExternalSnapshot.getLatest(companyId, packType);
      
      if (!snapshot) {
        return res.json({
          success: true,
          items: [],
          reports: [],
        });
      }
      
      // Get pack template to check allowExport flag
      const templates = getPackTemplates();
      const pack = templates[packType];
      
      // Filter reports if export not allowed
      let reports = snapshot.reports || [];
      if (pack && !pack.flags.allowExport) {
        // Still return reports but mark them as non-exportable
        reports = reports.map(r => ({ ...r, exportable: false }));
      }
      
      res.json({
        success: true,
        items: reports,
        reports: reports,
      });
    } catch (err) {
      console.error("external reports error:", err);
      res.status(500).json({
        success: false,
        message: "Server error",
        error: err.message,
      });
    }
  }
);

// ============================================
// GET /api/external/recommendations - Get recommendations
// ============================================
router.get(
  "/recommendations",
  requireAuth,
  requireCompanyScope,
  requireRoles(["external"]),
  checkExternalAccess,
  async (req, res) => {
    try {
      const companyId = await getCompanyPublicCode(req);
      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }
      
      const packType = getUserPackType(req);
      if (!packType) {
        return res.status(403).json({
          success: false,
          message: "Invalid external user type",
        });
      }
      
      // Get pack template to check flags
      const templates = getPackTemplates();
      const pack = templates[packType];
      
      // Get type from query param (external|internal)
      const type = req.query.type || "external";
      
      // Check if recommendations are allowed for this pack
      if (type === "external" && (!pack || !pack.flags.allowExternalRecs)) {
        return res.json({
          success: true,
          items: [],
          recommendations: [],
        });
      }
      
      if (type === "internal" && (!pack || !pack.flags.allowInternalRecs)) {
        return res.json({
          success: true,
          items: [],
          recommendations: [],
        });
      }
      
      // Query recommendations
      const query = { companyId, type };
      const limit = Math.min(parseInt(req.query.limit || "50", 10), 200);
      
      const recommendations = await Recommendation.find(query)
        .sort({ priority: 1, createdAt: -1 })
        .limit(limit)
        .lean();
      
      // Format for frontend
      const formatted = recommendations.map(rec => ({
        title: rec.title,
        summary: rec.insight || rec.recommendations?.[0] || "",
        priority: rec.priority?.toLowerCase() || "medium",
        category: rec.category,
      }));
      
      res.json({
        success: true,
        items: formatted,
        recommendations: formatted,
      });
    } catch (err) {
      console.error("external recommendations error:", err);
      res.status(500).json({
        success: false,
        message: "Server error",
        error: err.message,
      });
    }
  }
);

// ============================================
// GET /api/external/documents - Get documents list
// ============================================
router.get(
  "/documents",
  requireAuth,
  requireCompanyScope,
  requireRoles(["external"]),
  checkExternalAccess,
  async (req, res) => {
    try {
      const companyId = await getCompanyPublicCode(req);
      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }
      
      const packType = getUserPackType(req);
      if (!packType) {
        return res.status(403).json({
          success: false,
          message: "Invalid external user type",
        });
      }
      
      // Get pack template to check allowDocs flag
      const templates = getPackTemplates();
      const pack = templates[packType];
      
      if (!pack || !pack.flags.allowDocs) {
        return res.json({
          success: true,
          items: [],
          documents: [],
        });
      }
      
      // Get latest snapshot
      const snapshot = await ExternalSnapshot.getLatest(companyId, packType);
      
      if (!snapshot) {
        return res.json({
          success: true,
          items: [],
          documents: [],
        });
      }
      
      res.json({
        success: true,
        items: snapshot.docs || [],
        documents: snapshot.docs || [],
      });
    } catch (err) {
      console.error("external documents error:", err);
      res.status(500).json({
        success: false,
        message: "Server error",
        error: err.message,
      });
    }
  }
);

// ============================================
// GET /api/external/reports/main - Get main report
// ============================================
router.get(
  "/reports/main",
  requireAuth,
  requireCompanyScope,
  requireRoles(["external"]),
  checkExternalAccess,
  async (req, res) => {
    try {
      const companyId = await getCompanyPublicCode(req);
      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }
      
      const packType = getUserPackType(req);
      if (!packType) {
        return res.status(403).json({
          success: false,
          message: "Invalid external user type",
        });
      }
      
      // Get latest snapshot
      const snapshot = await ExternalSnapshot.getLatest(companyId, packType);
      
      if (!snapshot || !snapshot.reports || snapshot.reports.length === 0) {
        return res.status(404).json({
          success: false,
          message: "No main report found",
        });
      }
      
      // Return first report as main report
      const mainReport = snapshot.reports[0];
      
      res.json({
        success: true,
        report: mainReport,
        url: mainReport.url || "",
      });
    } catch (err) {
      console.error("external reports/main error:", err);
      res.status(500).json({
        success: false,
        message: "Server error",
        error: err.message,
      });
    }
  }
);

// ============================================
// GET /api/external/reports/export - Export reports
// ============================================
router.get(
  "/reports/export",
  requireAuth,
  requireCompanyScope,
  requireRoles(["external"]),
  checkExternalAccess,
  async (req, res) => {
    try {
      const companyId = await getCompanyPublicCode(req);
      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }
      
      const packType = getUserPackType(req);
      if (!packType) {
        return res.status(403).json({
          success: false,
          message: "Invalid external user type",
        });
      }
      
      // Get pack template to check allowExport flag
      const templates = getPackTemplates();
      const pack = templates[packType];
      
      if (!pack || !pack.flags.allowExport) {
        return res.status(403).json({
          success: false,
          message: "Export not allowed for this pack type",
        });
      }
      
      // Get latest snapshot
      const snapshot = await ExternalSnapshot.getLatest(companyId, packType);
      
      if (!snapshot) {
        return res.status(404).json({
          success: false,
          message: "No published snapshot found",
        });
      }
      
      // Return export data (for now, return snapshot data)
      // In future, this could generate PDF/Excel export
      res.json({
        success: true,
        data: {
          period: snapshot.period,
          metrics: snapshot.metrics,
          reports: snapshot.reports,
          publishedAt: snapshot.publishedAt,
        },
      });
    } catch (err) {
      console.error("external reports/export error:", err);
      res.status(500).json({
        success: false,
        message: "Server error",
        error: err.message,
      });
    }
  }
);

// ============================================
// POST /api/external/publish - Publish external snapshot (Manager/Admin only)
// ============================================
router.post(
  "/publish",
  requireAuth,
  requireCompanyScope,
  requireRoles(["admin", "manager"]),
  async (req, res) => {
    try {
      const companyId = await getCompanyPublicCode(req);
      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }
      
      const { packType, period, metrics, reports, docs, note, allowedSections, liquidity, debt, cashflow, currency } = req.body;
      
      if (!packType || !["bank", "investor", "auditor", "partner"].includes(packType)) {
        return res.status(400).json({
          success: false,
          message: "Valid packType is required (bank, investor, auditor, partner)",
        });
      }
      
      // Mark previous snapshot as not current
      await ExternalSnapshot.markPreviousAsNotCurrent(companyId, packType);
      
      // Create new snapshot
      const snapshot = await ExternalSnapshot.create({
        companyId,
        packType,
        period: period || "",
        metrics: metrics || {},
        liquidity: liquidity || {},
        debt: debt || {},
        cashflow: cashflow || {},
        allowedSections: allowedSections || [],
        reports: reports || [],
        docs: docs || [],
        note: note || "",
        currency: currency || "USD",
        publishedBy: req.user.userId,
        publishedAt: new Date(),
        isCurrent: true,
      });
      
      res.json({
        success: true,
        snapshot: snapshot.toObject(),
        message: "Snapshot published successfully",
      });
    } catch (err) {
      console.error("external publish error:", err);
      res.status(500).json({
        success: false,
        message: "Server error",
        error: err.message,
      });
    }
  }
);

// ============================================
// POST /api/external/publish/:packType - Convenience endpoint
// ============================================
router.post(
  "/publish/:packType",
  requireAuth,
  requireCompanyScope,
  requireRoles(["admin", "manager"]),
  async (req, res) => {
    // Add packType from URL to body
    req.body.packType = req.params.packType;
    // Forward to main publish endpoint
    req.url = "/publish";
    return router.handle(req, res);
  }
);

// ============================================
// GET /api/external/publish/history - Get publishing history (Manager/Admin only)
// ============================================
router.get(
  "/publish/history",
  requireAuth,
  requireCompanyScope,
  requireRoles(["admin", "manager"]),
  async (req, res) => {
    try {
      const companyId = await getCompanyPublicCode(req);
      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }
      
      const packType = req.query.packType; // Optional filter
      
      const query = { companyId };
      if (packType) {
        query.packType = packType;
      }
      
      const snapshots = await ExternalSnapshot.find(query)
        .sort({ publishedAt: -1 })
        .limit(100)
        .lean();
      
      res.json({
        success: true,
        items: snapshots,
        total: snapshots.length,
      });
    } catch (err) {
      console.error("external publish/history error:", err);
      res.status(500).json({
        success: false,
        message: "Server error",
        error: err.message,
      });
    }
  }
);

module.exports = router;
