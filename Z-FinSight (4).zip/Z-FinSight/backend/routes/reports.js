const express = require("express");
const Transaction = require("../models/Transaction");
const TransactionLine = require("../models/TransactionLine");
const Account = require("../models/Account");
const {
  calculateAllKPIs,
  getRevenue,
  getCOGS,
  getOperatingExpenses,
  getInterestExpense,
  getIncomeTax,
} = require("../utils/accountingCalculations");
const { generateBalanceSheet } = require("../utils/balanceSheetCalculations");
const { getARAgingReport, getAPAgingReport } = require("../utils/agingCalculations");
const { getCashFlowTrend } = require("../utils/dashboardCalculations");
const { startOfPeriod, endOfPeriod } = require("../utils/dates");

const {
  requireAuth,
  requireRoles,
  requireCompanyScope,
} = require("../middleware/authGuard");

const router = express.Router();

function dateRange(req) {
  const from = req.query.from ? new Date(req.query.from) : null;
  const to = req.query.to ? new Date(req.query.to) : null;
  const q = {};
  if (from || to) {
    q.date = {};
    if (from) q.date.$gte = from;
    if (to) q.date.$lte = to;
  }
  return q;
}

// Profit & Loss - Complete P&L Structure
router.get(
  "/pl",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager", "financial"]),
  async (req, res) => {
    try {
      const companyId = req.userCompanyId;

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      const dateFilter = dateRange(req);
      const startDate = dateFilter.date?.$gte || startOfPeriod("current");
      const endDate = dateFilter.date?.$lte || endOfPeriod("current");

      // Get revenue breakdown
      const revenueAccounts = await TransactionLine.aggregate([
        {
          $lookup: {
            from: "transactions",
            localField: "transaction_id",
            foreignField: "_id",
            as: "transaction",
          },
        },
        { $unwind: "$transaction" },
        {
          $lookup: {
            from: "accounts",
            localField: "account_id",
            foreignField: "_id",
            as: "account",
          },
        },
        { $unwind: "$account" },
        {
          $match: {
            "transaction.companyId": companyId,
            "transaction.date": { $gte: startDate, $lte: endDate },
            "transaction.status": "posted",
            "account.account_type": "revenue",
            "account.is_active": true,
          },
        },
        {
          $group: {
            _id: "$account.account_name",
            amount: {
              $sum: { $subtract: ["$credit_amount", "$debit_amount"] },
            },
          },
        },
      ]);

      // Get COGS breakdown
      const cogsAccounts = await TransactionLine.aggregate([
        {
          $lookup: {
            from: "transactions",
            localField: "transaction_id",
            foreignField: "_id",
            as: "transaction",
          },
        },
        { $unwind: "$transaction" },
        {
          $lookup: {
            from: "accounts",
            localField: "account_id",
            foreignField: "_id",
            as: "account",
          },
        },
        { $unwind: "$account" },
        {
          $match: {
            "transaction.companyId": companyId,
            "transaction.date": { $gte: startDate, $lte: endDate },
            "transaction.status": "posted",
            "account.account_type": "cogs",
            "account.is_active": true,
          },
        },
        {
          $group: {
            _id: "$account.account_name",
            amount: {
              $sum: { $subtract: ["$debit_amount", "$credit_amount"] },
            },
          },
        },
      ]);

      // Get operating expenses breakdown
      const operatingExpenseAccounts = await TransactionLine.aggregate([
        {
          $lookup: {
            from: "transactions",
            localField: "transaction_id",
            foreignField: "_id",
            as: "transaction",
          },
        },
        { $unwind: "$transaction" },
        {
          $lookup: {
            from: "accounts",
            localField: "account_id",
            foreignField: "_id",
            as: "account",
          },
        },
        { $unwind: "$account" },
        {
          $match: {
            "transaction.companyId": companyId,
            "transaction.date": { $gte: startDate, $lte: endDate },
            "transaction.status": "posted",
            "account.account_type": "expense",
            "account.is_active": true,
            $or: [
              { "account.account_name": { $not: { $regex: /interest|tax/i } } },
              { "account.expense_category": { $nin: ["financing", "tax"] } },
            ],
          },
        },
        {
          $group: {
            _id: "$account.account_name",
            amount: {
              $sum: { $subtract: ["$debit_amount", "$credit_amount"] },
            },
            category: { $first: "$account.expense_category" },
          },
        },
      ]);

      // Calculate all KPIs
      const kpis = await calculateAllKPIs(companyId, startDate, endDate);

      res.json({
        success: true,
        data: {
          revenue: {
            items: revenueAccounts.map((acc) => ({
              account_name: acc._id,
              amount: Math.round(acc.amount * 100) / 100,
            })),
            total: kpis.revenue,
          },
          cogs: {
            items: cogsAccounts.map((acc) => ({
              account_name: acc._id,
              amount: Math.round(acc.amount * 100) / 100,
            })),
            total: kpis.cogs,
          },
          gross_profit: kpis.grossProfit,
          gross_margin: kpis.grossMargin,
          operating_expenses: {
            items: operatingExpenseAccounts.map((acc) => ({
              account_name: acc._id,
              category: acc.category || "general",
              amount: Math.round(acc.amount * 100) / 100,
            })),
            total: kpis.operating_expenses,
          },
          operating_profit: kpis.operating_profit,
          operating_margin: kpis.operating_margin,
          interest_expense: kpis.interest_expense,
          profit_before_tax: kpis.profit_before_tax,
          income_tax: kpis.income_tax,
          net_profit_after_tax: kpis.net_profit_after_tax,
          net_profit_margin: kpis.net_profit_margin,
          tax_burden: kpis.taxBurden,
          period_start: startDate,
          period_end: endDate,
        },
      });
    } catch (err) {
      console.error("reports pl error:", err);
      res.status(500).json({
        success: false,
        message: "Server error",
        error: err.message,
      });
    }
  }
);

// Expenses by Category
router.get(
  "/expenses-by-category",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager", "financial"]),
  async (req, res) => {
    try {
      // ✅ SECURITY: Use companyId from JWT token only (set by requireCompanyScope)
      const companyId = req.userCompanyId;
      
      if (!companyId) {
        return res.status(400).json({ 
          success: false, 
          message: "companyId is required" 
        });
      }

      const q = { companyId, type: "expense", ...dateRange(req) };
      const txs = await Transaction.find(q).lean();

      const map = {};
      for (const t of txs) {
        const k = t.category || "Uncategorized";
        map[k] = (map[k] || 0) + Number(t.amount || 0);
      }

      const items = Object.entries(map)
        .map(([category, total]) => ({ category, total }))
        .sort((a, b) => b.total - a.total);

      res.json({ success: true, items });
    } catch (err) {
      console.error("reports exp error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// Simple Cash Flow (income - expense)
router.get(
  "/cashflow",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager", "financial"]),
  async (req, res) => {
    try {
      const companyId = req.userCompanyId;

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      const q = { companyId, ...dateRange(req) };
      const txs = await Transaction.find(q).lean();

      let cashIn = 0,
        cashOut = 0;

      for (const t of txs) {
        if (t.type === "income") cashIn += Number(t.amount || 0);
        else cashOut += Number(t.amount || 0);
      }

      res.json({
        success: true,
        cashIn: Math.round(cashIn * 100) / 100,
        cashOut: Math.round(cashOut * 100) / 100,
        net: Math.round((cashIn - cashOut) * 100) / 100,
      });
    } catch (err) {
      console.error("reports cashflow error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// Balance Sheet
router.get(
  "/balance-sheet",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager", "financial"]),
  async (req, res) => {
    try {
      const companyId = req.userCompanyId;

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      const balanceSheet = await generateBalanceSheet(companyId);

      res.json({
        success: true,
        data: balanceSheet,
      });
    } catch (err) {
      console.error("reports balance-sheet error:", err);
      res.status(500).json({
        success: false,
        message: err.message || "Server error",
        error: err.message,
      });
    }
  }
);

// AR Aging Report
router.get(
  "/ar-aging",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager", "financial"]),
  async (req, res) => {
    try {
      const companyId = req.userCompanyId;

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      const report = await getARAgingReport(companyId);

      res.json({
        success: true,
        data: report,
      });
    } catch (err) {
      console.error("reports ar-aging error:", err);
      res.status(500).json({
        success: false,
        message: "Server error",
        error: err.message,
      });
    }
  }
);

// AP Aging Report
router.get(
  "/ap-aging",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager", "financial"]),
  async (req, res) => {
    try {
      const companyId = req.userCompanyId;

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      const report = await getAPAgingReport(companyId);

      res.json({
        success: true,
        data: report,
      });
    } catch (err) {
      console.error("reports ap-aging error:", err);
      res.status(500).json({
        success: false,
        message: "Server error",
        error: err.message,
      });
    }
  }
);

// Cash Flow Trend (Last 30 Days)
router.get(
  "/cash-flow-trend",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager", "financial"]),
  async (req, res) => {
    try {
      const companyId = req.userCompanyId;

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      const trend = await getCashFlowTrend(companyId);

      res.json({
        success: true,
        data: trend,
      });
    } catch (err) {
      console.error("reports cash-flow-trend error:", err);
      res.status(500).json({
        success: false,
        message: "Server error",
        error: err.message,
      });
    }
  }
);

module.exports = router;