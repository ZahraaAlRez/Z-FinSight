const express = require("express");
const router = express.Router();

const Company = require("../models/Company");
const FxRateSnapshot = require("../models/FxRateSnapshot");

function pickCompanyId(req) {
  return (req.query.companyId || req.params.companyId || "").trim();
}

// GET /api/fx?companyId=CMP_007
router.get("/", async (req, res) => {
  try {
    const companyPublicId = pickCompanyId(req);

    if (!companyPublicId) {
      return res.status(400).json({ ok: false, message: "companyId is required" });
    }

    const company = await Company.findOne({ companyId: companyPublicId });
    if (!company) {
      return res.status(404).json({ ok: false, message: "Company not found" });
    }

    // آخر snapshot
    const snap = await FxRateSnapshot.findOne({ companyId: companyPublicId })
      .sort({ fetchedAt: -1, createdAt: -1 });

    const lastUpdated = snap ? (snap.fetchedAt || snap.updatedAt || snap.createdAt || null) : null;

    return res.json({
      ok: true,
      data: snap ? snap : { rates: [] },
      meta: {
        companyId: companyPublicId,
        source: snap ? "cache" : "empty",
        lastUpdated,
      },
    });
  } catch (err) {
    console.error("❌ /api/fx error:", err);
    return res.status(500).json({ ok: false, message: "Server error" });
  }
});

module.exports = router;
