const express = require("express");
const mongoose = require("mongoose");
const Company = require("../models/Company");
const User = require("../models/User");
const {
  requireAuth,
  requireRoles,
  requireCompanyScope,
  requireAdmin,
} = require("../middleware/authGuard");

const router = express.Router();

// ============================================
// GET /api/companies - List companies (admin only)
// ============================================
router.get(
  "/",
  requireAuth,
  requireRoles(["admin"]), // Allow company admins too
  async (req, res) => {
    try {
      const limit = Math.min(parseInt(req.query.limit || "50", 10), 200);
      const page = Math.max(parseInt(req.query.page || "1", 10), 1);
      const skip = (page - 1) * limit;

      const query = {};
      
      // If user is not system admin, only show their company
      const isSystemAdmin = req.user.isAdmin && req.user.adminId;
      if (!isSystemAdmin && req.userCompanyId) {
        query._id = req.userCompanyId;
      }
      
      if (req.query.isActive !== undefined) {
        query.isActive = req.query.isActive === "true";
      }
      if (req.query.isVerified !== undefined) {
        query.isVerified = req.query.isVerified === "true";
      }
      if (req.query.industry) {
        query.industry = req.query.industry;
      }
      if (req.query.country) {
        query.country = req.query.country;
      }

      const [companies, total] = await Promise.all([
        Company.find(query)
          .sort({ createdAt: -1 })
          .skip(skip)
          .limit(limit)
          .lean(),
        Company.countDocuments(query),
      ]);

      res.json({
        success: true,
        items: companies,
        total,
        page,
        limit,
      });
    } catch (err) {
      console.error("companies list error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// ============================================
// PATCH /api/companies/:id/activate - Activate company (MUST BE BEFORE /:id)
// ============================================
router.patch(
  "/:id/activate",
  requireAuth,
  requireRoles(["admin"]), // Allow company admins too
  async (req, res) => {
    try {
      const companyId = req.params.id;
      
      // Check if user is system admin or company admin
      const isSystemAdmin = req.user.isAdmin && req.user.adminId;
      // Use req.user.companyId (from JWT) or req.userCompanyId (from requireCompanyScope if used)
      const userCompanyId = req.userCompanyId || req.user.companyId;
      const userCompanyCode = req.userCompanyCode || req.user.companyCode;

      // If not system admin, ensure they can only activate their own company
      if (!isSystemAdmin) {
        if (!userCompanyId && !userCompanyCode) {
          return res.status(403).json({
            success: false,
            message: "Company information not found",
          });
        }
        
        // Check if the companyId matches user's company (by _id or companyId)
        let allowed = false;
        
        // Check by MongoDB _id
        if (userCompanyId && companyId === String(userCompanyId)) {
          allowed = true;
        }
        
        // Check by public companyId code
        if (!allowed && userCompanyCode && companyId === userCompanyCode) {
          allowed = true;
        }
        
        // If still not allowed, try to fetch user's company to compare
        if (!allowed && userCompanyId) {
          try {
            const userCompany = await Company.findById(userCompanyId).lean();
            if (userCompany) {
              if (companyId === userCompany.companyId || companyId === String(userCompany._id)) {
                allowed = true;
              }
            }
          } catch (err) {
            console.error("Error fetching user company:", err);
          }
        }
        
        if (!allowed) {
          return res.status(403).json({
            success: false,
            message: "You can only activate your own company",
          });
        }
      }

      // Try to find company by _id (MongoDB ObjectId) or companyId (public code)
      let company = null;
      
      // Check if companyId is a valid MongoDB ObjectId
      const isValidObjectId = mongoose.Types.ObjectId.isValid(companyId);
      
      if (isValidObjectId) {
        // Try to find by MongoDB _id first
        company = await Company.findById(companyId);
      }
      
      // If not found by _id, try to find by public companyId code
      if (!company) {
        company = await Company.findOne({ companyId: companyId });
      }

      if (!company) {
        return res.status(404).json({
          success: false,
          message: "Company not found",
        });
      }

      company.isActive = true;
      await company.save();

      res.json({
        success: true,
        message: "Company activated successfully",
        company: {
          companyId: company.companyId,
          companyName: company.companyName,
          isActive: company.isActive,
        },
      });
    } catch (err) {
      console.error("company activate error:", err);
      res.status(500).json({ 
        success: false, 
        message: err.message || "Server error",
        error: process.env.NODE_ENV === "development" ? err.stack : undefined
      });
    }
  }
);

// ============================================
// PATCH /api/companies/:id/deactivate - Deactivate company (MUST BE BEFORE /:id)
// ============================================
router.patch(
  "/:id/deactivate",
  requireAuth,
  requireRoles(["admin"]), // Allow company admins too
  async (req, res) => {
    try {
      const companyId = req.params.id;
      
      // Check if user is system admin or company admin
      const isSystemAdmin = req.user.isAdmin && req.user.adminId;
      // Use req.user.companyId (from JWT) or req.userCompanyId (from requireCompanyScope if used)
      const userCompanyId = req.userCompanyId || req.user.companyId;
      const userCompanyCode = req.userCompanyCode || req.user.companyCode;

      // If not system admin, ensure they can only deactivate their own company
      if (!isSystemAdmin) {
        if (!userCompanyId && !userCompanyCode) {
          return res.status(403).json({
            success: false,
            message: "Company information not found",
          });
        }
        
        // Check if the companyId matches user's company (by _id or companyId)
        let allowed = false;
        
        // Check by MongoDB _id
        if (userCompanyId && companyId === String(userCompanyId)) {
          allowed = true;
        }
        
        // Check by public companyId code
        if (!allowed && userCompanyCode && companyId === userCompanyCode) {
          allowed = true;
        }
        
        // If still not allowed, try to fetch user's company to compare
        if (!allowed && userCompanyId) {
          try {
            const userCompany = await Company.findById(userCompanyId).lean();
            if (userCompany) {
              if (companyId === userCompany.companyId || companyId === String(userCompany._id)) {
                allowed = true;
              }
            }
          } catch (err) {
            console.error("Error fetching user company:", err);
          }
        }
        
        if (!allowed) {
          return res.status(403).json({
            success: false,
            message: "You can only deactivate your own company",
          });
        }
      }

      // Try to find company by _id (MongoDB ObjectId) or companyId (public code)
      let company = null;
      
      // Check if companyId is a valid MongoDB ObjectId
      const isValidObjectId = mongoose.Types.ObjectId.isValid(companyId);
      
      if (isValidObjectId) {
        // Try to find by MongoDB _id first
        company = await Company.findById(companyId);
      }
      
      // If not found by _id, try to find by public companyId code
      if (!company) {
        company = await Company.findOne({ companyId: companyId });
      }

      if (!company) {
        return res.status(404).json({
          success: false,
          message: "Company not found",
        });
      }

      company.isActive = false;
      await company.save();

      res.json({
        success: true,
        message: "Company deactivated successfully",
        company: {
          companyId: company.companyId,
          companyName: company.companyName,
          isActive: company.isActive,
        },
      });
    } catch (err) {
      console.error("company deactivate error:", err);
      res.status(500).json({ 
        success: false, 
        message: err.message || "Server error",
        error: process.env.NODE_ENV === "development" ? err.stack : undefined
      });
    }
  }
);

// ============================================
// POST /api/companies/:id/verify - Verify company email (MUST BE BEFORE /:id)
// ============================================
router.post(
  "/:id/verify",
  requireAuth,
  requireRoles(["admin"]), // Allow company admins too
  async (req, res) => {
    try {
      const companyId = req.params.id;
      
      // Check if user is system admin or company admin
      const isSystemAdmin = req.user.isAdmin && req.user.adminId;
      // Use req.user.companyId (from JWT) or req.userCompanyId (from requireCompanyScope if used)
      const userCompanyId = req.userCompanyId || req.user.companyId;
      const userCompanyCode = req.userCompanyCode || req.user.companyCode;

      // If not system admin, ensure they can only verify their own company
      if (!isSystemAdmin) {
        if (!userCompanyId && !userCompanyCode) {
          return res.status(403).json({
            success: false,
            message: "Company information not found",
          });
        }
        
        // Check if the companyId matches user's company (by _id or companyId)
        let allowed = false;
        
        // Check by MongoDB _id
        if (userCompanyId && companyId === String(userCompanyId)) {
          allowed = true;
        }
        
        // Check by public companyId code
        if (!allowed && userCompanyCode && companyId === userCompanyCode) {
          allowed = true;
        }
        
        // If still not allowed, try to fetch user's company to compare
        if (!allowed && userCompanyId) {
          try {
            const userCompany = await Company.findById(userCompanyId).lean();
            if (userCompany) {
              if (companyId === userCompany.companyId || companyId === String(userCompany._id)) {
                allowed = true;
              }
            }
          } catch (err) {
            console.error("Error fetching user company:", err);
          }
        }
        
        if (!allowed) {
          return res.status(403).json({
            success: false,
            message: "You can only verify your own company",
          });
        }
      }

      // Try to find company by _id (MongoDB ObjectId) or companyId (public code)
      let company = null;
      
      // Check if companyId is a valid MongoDB ObjectId
      const isValidObjectId = mongoose.Types.ObjectId.isValid(companyId);
      
      if (isValidObjectId) {
        // Try to find by MongoDB _id first
        company = await Company.findById(companyId);
      }
      
      // If not found by _id, try to find by public companyId code
      if (!company) {
        company = await Company.findOne({ companyId: companyId });
      }

      if (!company) {
        return res.status(404).json({
          success: false,
          message: "Company not found",
        });
      }

      company.isVerified = true;
      await company.save();

      res.json({
        success: true,
        message: "Company verified successfully",
        company: {
          companyId: company.companyId,
          companyName: company.companyName,
          isVerified: company.isVerified,
        },
      });
    } catch (err) {
      console.error("company verify error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// ============================================
// GET /api/companies/:id - Get company details
// ============================================
router.get(
  "/:id",
  requireAuth,
  async (req, res) => {
    try {
      const companyId = req.params.id;
      const isAdmin = req.user.roles?.includes("admin");
      const isSystemAdmin = req.user.isAdmin && req.user.adminId;
      
      // Use req.user.companyId (from JWT) or req.userCompanyId (from requireCompanyScope if used)
      const userCompanyId = req.userCompanyId || req.user.companyId;
      const userCompanyCode = req.userCompanyCode || req.user.companyCode;

      // Non-admin users can only view their own company
      if (!isAdmin && !isSystemAdmin) {
        if (!userCompanyId && !userCompanyCode) {
          return res.status(403).json({
            success: false,
            message: "Access denied",
          });
        }
        
        // Check if the companyId matches user's company (by _id or companyId)
        let allowed = false;
        
        // Check by MongoDB _id
        if (userCompanyId && companyId === String(userCompanyId)) {
          allowed = true;
        }
        
        // Check by public companyId code
        if (!allowed && userCompanyCode && companyId === userCompanyCode) {
          allowed = true;
        }
        
        // If still not allowed, try to fetch user's company to compare
        if (!allowed && userCompanyId) {
          try {
            const userCompany = await Company.findById(userCompanyId).lean();
            if (userCompany) {
              if (companyId === userCompany.companyId || companyId === String(userCompany._id)) {
                allowed = true;
              }
            }
          } catch (err) {
            console.error("Error fetching user company:", err);
          }
        }
        
        if (!allowed) {
          return res.status(403).json({
            success: false,
            message: "Access denied",
          });
        }
      }

      // Try to find company by _id (MongoDB ObjectId) or companyId (public code)
      let company = null;
      
      // Check if companyId is a valid MongoDB ObjectId
      const isValidObjectId = mongoose.Types.ObjectId.isValid(companyId);
      
      if (isValidObjectId) {
        // Try to find by MongoDB _id first
        company = await Company.findById(companyId).lean();
      }
      
      // If not found by _id, try to find by public companyId code
      if (!company) {
        company = await Company.findOne({ companyId: companyId }).lean();
      }

      if (!company) {
        return res.status(404).json({
          success: false,
          message: "Company not found",
        });
      }

      // Get user count for this company
      const userCount = await User.countDocuments({
        companyId: company._id,
      });

      res.json({
        success: true,
        company: {
          ...company,
          userCount,
        },
      });
    } catch (err) {
      console.error("company details error:", err);
      res.status(500).json({ 
        success: false, 
        message: err.message || "Server error",
        error: process.env.NODE_ENV === "development" ? err.stack : undefined
      });
    }
  }
);

// ============================================
// PATCH /api/companies/:id - Update company
// ============================================
router.patch(
  "/:id",
  requireAuth,
  requireRoles(["admin"]), // Allow company admins too
  async (req, res) => {
    try {
      const companyId = req.params.id;
      
      // Check if user is system admin or company admin
      const isSystemAdmin = req.user.isAdmin && req.user.adminId;
      // Use req.user.companyId (from JWT) or req.userCompanyId (from requireCompanyScope if used)
      const userCompanyId = req.userCompanyId || req.user.companyId;
      const userCompanyCode = req.userCompanyCode || req.user.companyCode;

      // If not system admin, ensure they can only update their own company
      if (!isSystemAdmin) {
        if (!userCompanyId && !userCompanyCode) {
          return res.status(403).json({
            success: false,
            message: "Company information not found",
          });
        }
        
        // Check if the companyId matches user's company (by _id or companyId)
        let allowed = false;
        
        // Check by MongoDB _id
        if (userCompanyId && companyId === String(userCompanyId)) {
          allowed = true;
        }
        
        // Check by public companyId code
        if (!allowed && userCompanyCode && companyId === userCompanyCode) {
          allowed = true;
        }
        
        // If still not allowed, try to fetch user's company to compare
        if (!allowed && userCompanyId) {
          try {
            const userCompany = await Company.findById(userCompanyId).lean();
            if (userCompany) {
              if (companyId === userCompany.companyId || companyId === String(userCompany._id)) {
                allowed = true;
              }
            }
          } catch (err) {
            console.error("Error fetching user company:", err);
          }
        }
        
        if (!allowed) {
          return res.status(403).json({
            success: false,
            message: "You can only update your own company",
          });
        }
      }
      
      const {
        companyName,
        industry,
        industryOther,
        country,
        countryOther,
        currencies,
        companyEmail,
        language,
      } = req.body || {};

      // Try to find company by _id (MongoDB ObjectId) or companyId (public code)
      let company = null;
      
      // Check if companyId is a valid MongoDB ObjectId
      const isValidObjectId = mongoose.Types.ObjectId.isValid(companyId);
      
      if (isValidObjectId) {
        // Try to find by MongoDB _id first
        company = await Company.findById(companyId);
      }
      
      // If not found by _id, try to find by public companyId code
      if (!company) {
        company = await Company.findOne({ companyId: companyId });
      }

      if (!company) {
        return res.status(404).json({
          success: false,
          message: "Company not found",
        });
      }

      // Build update object
      const update = {};
      if (companyName !== undefined) update.companyName = companyName.trim();
      if (industry !== undefined) update.industry = industry;
      if (industryOther !== undefined) update.industryOther = industryOther;
      if (country !== undefined) update.country = country;
      if (countryOther !== undefined) update.countryOther = countryOther;
      if (currencies !== undefined && Array.isArray(currencies)) {
        update.currencies = currencies;
      }
      if (companyEmail !== undefined) {
        update.companyEmail = companyEmail.toLowerCase().trim();
      }
      if (language !== undefined && ["ar", "en"].includes(language)) {
        update.language = language;
      }

      const updated = await Company.findOneAndUpdate(
        { _id: company._id },
        update,
        { new: true }
      ).lean();

      res.json({
        success: true,
        company: updated,
      });
    } catch (err) {
      console.error("company update error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// ============================================
// GET /api/companies/settings - Get company settings (current company)
// ============================================
router.get(
  "/settings",
  requireAuth,
  requireCompanyScope,
  async (req, res) => {
    try {
      const companyId = req.userCompanyId;

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      const company = await Company.findOne({ _id: companyId }).lean();

      if (!company) {
        return res.status(404).json({
          success: false,
          message: "Company not found",
        });
      }

      res.json({
        success: true,
        settings: {
          companyId: company.companyId,
          companyName: company.companyName,
          industry: company.industry,
          industryOther: company.industryOther,
          country: company.country,
          countryOther: company.countryOther,
          currencies: company.currencies,
          companyEmail: company.companyEmail,
          language: company.language,
          isActive: company.isActive,
          isVerified: company.isVerified,
        },
      });
    } catch (err) {
      console.error("company settings error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

// ============================================
// PATCH /api/companies/settings - Update company settings
// ============================================
router.patch(
  "/settings",
  requireAuth,
  requireCompanyScope,
  requireRoles(["admin"]),
  async (req, res) => {
    try {
      const companyId = req.userCompanyId;

      if (!companyId) {
        return res.status(400).json({
          success: false,
          message: "companyId is required",
        });
      }

      const {
        companyName,
        industry,
        industryOther,
        country,
        countryOther,
        currencies,
        companyEmail,
        language,
      } = req.body || {};

      const company = await Company.findById(companyId);

      if (!company) {
        return res.status(404).json({
          success: false,
          message: "Company not found",
        });
      }

      // Build update object
      const update = {};
      if (companyName !== undefined) update.companyName = companyName.trim();
      if (industry !== undefined) update.industry = industry;
      if (industryOther !== undefined) update.industryOther = industryOther;
      if (country !== undefined) update.country = country;
      if (countryOther !== undefined) update.countryOther = countryOther;
      if (currencies !== undefined && Array.isArray(currencies)) {
        update.currencies = currencies;
      }
      if (companyEmail !== undefined) {
        update.companyEmail = companyEmail.toLowerCase().trim();
      }
      if (language !== undefined && ["ar", "en"].includes(language)) {
        update.language = language;
      }

      const updated = await Company.findByIdAndUpdate(
        companyId,
        update,
        { new: true }
      ).lean();

      res.json({
        success: true,
        settings: {
          companyId: updated.companyId,
          companyName: updated.companyName,
          industry: updated.industry,
          industryOther: updated.industryOther,
          country: updated.country,
          countryOther: updated.countryOther,
          currencies: updated.currencies,
          companyEmail: updated.companyEmail,
          language: updated.language,
          isActive: updated.isActive,
          isVerified: updated.isVerified,
        },
      });
    } catch (err) {
      console.error("company settings update error:", err);
      res.status(500).json({ success: false, message: "Server error" });
    }
  }
);

module.exports = router;
