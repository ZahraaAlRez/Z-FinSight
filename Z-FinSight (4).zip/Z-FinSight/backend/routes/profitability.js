const express = require("express");
const {
  requireAuth,
  requireRoles,
  requireCompanyScope,
} = require("../middleware/authGuard");

const router = express.Router();

/**
 * POST /api/profitability/calculate
 * Profitability Calculator
 * Input: { revenue, cogs, operating_expenses, interest_expense, taxes }
 * Calculate all metrics: gross profit, margins, operating profit, PBT, PAT, tax burden
 */
router.post(
  "/calculate",
  requireAuth,
  requireCompanyScope,
  requireRoles(["accountant", "admin", "manager", "financial"]),
  async (req, res) => {
    try {
      const {
        revenue = 0,
        cogs = 0,
        operating_expenses = 0,
        interest_expense = 0,
        taxes = 0,
      } = req.body;

      // Validate inputs
      if (
        typeof revenue !== "number" ||
        typeof cogs !== "number" ||
        typeof operating_expenses !== "number" ||
        typeof interest_expense !== "number" ||
        typeof taxes !== "number"
      ) {
        return res.status(400).json({
          success: false,
          message: "All inputs must be numbers",
        });
      }

      // Step 1: Gross Profit
      const grossProfit = revenue - cogs;
      const grossMargin = revenue > 0 ? (grossProfit / revenue) * 100 : 0;

      // Step 2: Operating Profit
      const operatingProfit = grossProfit - operating_expenses;
      const operatingMargin = revenue > 0 ? (operatingProfit / revenue) * 100 : 0;

      // Step 3: Profit Before Tax
      const profitBeforeTax = operatingProfit - interest_expense;

      // Step 4: Net Profit After Tax
      const netProfitAfterTax = profitBeforeTax - taxes;
      const netProfitMargin = revenue > 0 ? (netProfitAfterTax / revenue) * 100 : 0;

      // Step 5: Tax Burden
      const taxBurden = profitBeforeTax > 0 ? (taxes / profitBeforeTax) * 100 : 0;

      // Round all values to 2 decimal places
      const result = {
        // Input Summary
        revenue: Math.round(revenue * 100) / 100,
        cogs: Math.round(cogs * 100) / 100,
        operating_expenses: Math.round(operating_expenses * 100) / 100,
        interest_expense: Math.round(interest_expense * 100) / 100,
        taxes: Math.round(taxes * 100) / 100,

        // Calculated Results
        gross_profit: Math.round(grossProfit * 100) / 100,
        gross_margin: Math.round(grossMargin * 100) / 100,
        operating_profit: Math.round(operatingProfit * 100) / 100,
        operating_margin: Math.round(operatingMargin * 100) / 100,
        profit_before_tax: Math.round(profitBeforeTax * 100) / 100,
        net_profit_after_tax: Math.round(netProfitAfterTax * 100) / 100,
        net_profit_margin: Math.round(netProfitMargin * 100) / 100,
        tax_burden: Math.round(taxBurden * 100) / 100,

        // Additional Metrics
        ebitda: Math.round(operatingProfit * 100) / 100, // simplified, ignoring D&A for now
        effective_tax_rate: Math.round(taxBurden * 100) / 100,
      };

      res.json({
        success: true,
        data: result,
      });
    } catch (err) {
      console.error("Profitability calculation error:", err);
      res.status(500).json({
        success: false,
        message: "Server error",
        error: err.message,
      });
    }
  }
);

module.exports = router;
