const express = require("express");
const cors = require("cors");
const path = require("path");
const nodemailer = require("nodemailer");
require("dotenv").config();

// MongoDB
const mongoose = require("mongoose");

// Routes (existing)
const registerRoutes = require("./routes/register");
const authRoutes = require("./routes/auth");
const usersRoutes = require("./routes/users");
const newsRoutes = require("./routes/news");
const topCompaniesRoutes = require("./routes/topCompanies");
const fxRoutes = require("./routes/fx");
const riskRoutes = require("./routes/risk");
const recommendationsRoutes = require("./routes/recommendations");
const identityCardsRoutes = require("./routes/identityCards");
const mediaRoutes = require("./routes/media");
const notifyRoutes = require("./routes/notify");
const devRoutes = require("./routes/dev");

// ✅ NEW Accountant Routes (make sure file names match EXACTLY in /routes)
const transactionsRoutes = require("./routes/transactions");
const kpisRoutes = require("./routes/kpis");
const reconcileRoutes = require("./routes/reconcile");
const reportsRoutes = require("./routes/reports");
const statsRoutes = require("./routes/stats");
const notificationsRoutes = require("./routes/notifications");
const companiesRoutes = require("./routes/companies");
const auditRoutes = require("./routes/audit");
const healthRoutes = require("./routes/health");

// Middleware
const { requireAuth, requireAdmin } = require("./middleware/authGuard");

// Schedulers
const scheduler = require("./jobs/scheduler");
const recommendationScheduler = require("./jobs/recommendationScheduler");

const app = express();

// ============================================
// CORS - UPDATED FOR STABILITY
// ============================================
app.use(
  cors({
    origin: function (origin, callback) {
      // Allow requests with no origin (like mobile apps, Postman, or file://)
      if (!origin) return callback(null, true);
      
      const allowedOrigins = [
        "http://127.0.0.1:5500",
        "http://localhost:5500",
        "http://127.0.0.1:5501",
        "http://localhost:5501",
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        // Add any other origins from CORS_ORIGIN env var
        ...(process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(",") : []),
      ];
      
      if (allowedOrigins.indexOf(origin) !== -1 || process.env.NODE_ENV === "development") {
        callback(null, true);
      } else {
        console.warn(`⚠️ CORS blocked origin: ${origin}`);
        callback(new Error("Not allowed by CORS"));
      }
    },
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    credentials: true,
    allowedHeaders: ["Content-Type", "Authorization", "Accept-Language", "X-Requested-With"],
  })
);

app.use(express.json());

// ============================================
// Static files for uploaded avatars
// ============================================
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// ============================================
// MongoDB Connection - IMPROVED ERROR HANDLING
// ============================================
mongoose
  .connect(process.env.MONGO_URI)
  .then(() => {
    console.log("✅ MongoDB connected successfully");

    // Start scheduler only if enabled
    if (process.env.ENABLE_SCHEDULER === "true") {
      try {
        scheduler.startScheduler();
        console.log("✅ Main scheduler started");
      } catch (err) {
        console.error("⚠️ Scheduler failed to start:", err.message);
      }
    } else {
      console.log(
        "⏸️  Main scheduler disabled (set ENABLE_SCHEDULER=true to enable)"
      );
    }

    // Recommendation scheduler
    try {
      recommendationScheduler.startAll();
      console.log("✅ Recommendation scheduler started");
    } catch (err) {
      console.error("⚠️ Recommendation scheduler failed:", err.message);
    }
  })
  .catch((err) => {
    console.error("❌ MongoDB connection error:", err);
    console.error("   Please check your MONGO_URI in .env file");
    process.exit(1);
  });

// ============================================
// Root Endpoint
// ============================================
app.get("/", (req, res) => {
  res.json({
    success: true,
    message: "✅ Z-FinSight Backend is running!",
    version: "2.1",
    endpoints: {
      registration: "/api/register/*",
      authentication: "/api/auth/*",
      users: "/api/users/*",

      dashboard: "/api/news, /api/fx, /api/top-companies, /api/recommendations",

      // ✅ Accountant
      accounting: "/api/transactions, /api/kpis, /api/reconcile, /api/reports, /api/stats",

      identityCards: "/api/identity-cards/*",
    },
  });
});

// ============================================
// API Routes
// ============================================
app.use("/api/health", healthRoutes);
app.use("/api/register", registerRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/users", usersRoutes);

app.use("/api/news", newsRoutes);
app.use("/api/top-companies", topCompaniesRoutes);
app.use("/api/fx", fxRoutes);
app.use("/api/risk", riskRoutes);

app.use("/api/recommendations", recommendationsRoutes);
app.use("/api/identity-cards", identityCardsRoutes);
app.use("/api/media", mediaRoutes);
app.use("/api/notify", notifyRoutes);
app.use("/api/dev", devRoutes);

// ✅ Accountant APIs (ONLY ONCE)
app.use("/api/transactions", transactionsRoutes);
app.use("/api/kpis", kpisRoutes);
app.use("/api/reconcile", reconcileRoutes);
app.use("/api/reports", reportsRoutes);
app.use("/api/stats", statsRoutes);
app.use("/api/profitability", require("./routes/profitability"));
app.use("/api/notifications", notificationsRoutes);
app.use("/api/companies", companiesRoutes);
app.use("/api/audit", auditRoutes);

// ✅ External Portal APIs
app.use("/api/external", require("./routes/external"));

// ============================================
// Scheduler Manual Triggers (Admin Only)
// ============================================
app.post(
  "/api/scheduler/trigger/news",
  requireAuth,
  requireAdmin,
  async (req, res) => {
    try {
      await scheduler.runNewsUpdate();
      res.json({ success: true, message: "News update triggered successfully" });
    } catch (err) {
      console.error("❌ Manual news trigger error:", err);
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

app.post(
  "/api/scheduler/trigger/fx",
  requireAuth,
  requireAdmin,
  async (req, res) => {
    try {
      await scheduler.runFxUpdate();
      res.json({ success: true, message: "FX update triggered successfully" });
    } catch (err) {
      console.error("❌ Manual FX trigger error:", err);
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

app.post(
  "/api/scheduler/trigger/companies",
  requireAuth,
  requireAdmin,
  async (req, res) => {
    try {
      await scheduler.runCompaniesUpdate();
      res.json({
        success: true,
        message: "Companies update triggered successfully",
      });
    } catch (err) {
      console.error("❌ Manual companies trigger error:", err);
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

app.post(
  "/api/scheduler/trigger/recommendations",
  requireAuth,
  requireAdmin,
  async (req, res) => {
    try {
      await recommendationScheduler.triggerManual();
      res.json({
        success: true,
        message: "Recommendations triggered successfully",
      });
    } catch (err) {
      console.error("❌ Manual recommendations trigger error:", err);
      res.status(500).json({ success: false, message: err.message });
    }
  }
);

// ============================================
// Contact Form (Public - No Auth Required)
// ============================================
app.post("/api/contact", async (req, res) => {
  try {
    const { fullName, email, message, lang } = req.body;

    // Validation
    if (!fullName || fullName.trim().length < 2) {
      return res.status(400).json({
        success: false,
        message: lang === "ar" ? "الاسم غير صالح" : "Invalid full name",
      });
    }

    if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
      return res.status(400).json({
        success: false,
        message: lang === "ar" ? "البريد الإلكتروني غير صالح" : "Invalid email",
      });
    }

    if (!message || message.trim().length < 5) {
      return res.status(400).json({
        success: false,
        message: lang === "ar" ? "الرسالة قصيرة جداً" : "Message too short",
      });
    }

    // Create email transporter
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.GMAIL_USER,
        pass: process.env.GMAIL_APP_PASSWORD,
      },
    });

    // Send email
    await transporter.sendMail({
      from: `"Z-FinSight Contact" <${process.env.GMAIL_USER}>`,
      to: process.env.GMAIL_USER,
      replyTo: email,
      subject: `New Contact Message - ${fullName}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h2 style="color: #0f172a;">New Contact Message from Z-FinSight</h2>
          <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <p><strong>Name:</strong> ${escapeHtml(fullName)}</p>
            <p><strong>Email:</strong> ${escapeHtml(email)}</p>
            <p><strong>Message:</strong></p>
            <p style="white-space: pre-wrap;">${escapeHtml(message)}</p>
          </div>
          <p style="color: #64748b; font-size: 13px;">
            Sent from Z-FinSight Contact Form
          </p>
        </div>
      `,
    });

    console.log("✅ Contact email sent from:", email);

    res.json({
      success: true,
      message: lang === "ar" ? "تم إرسال رسالتك بنجاح" : "Message sent successfully",
    });
  } catch (err) {
    console.error("❌ Contact form error:", err);
    res.status(500).json({
      success: false,
      message: req.body.lang === "ar" ? "خطأ في الخادم" : "Server error",
    });
  }
});

// Helper function to escape HTML
function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

// ============================================
// 404 Handler
// ============================================
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: "Route not found",
    requestedPath: req.path,
  });
});

// ============================================
// Global Error Handler
// ============================================
app.use((err, req, res, next) => {
  console.error("❌ Unhandled error:", err);
  res.status(500).json({
    success: false,
    message: "Internal server error",
    error: process.env.NODE_ENV === "development" ? err.message : undefined,
  });
});

// ============================================
// Graceful Shutdown
// ============================================
process.on("SIGTERM", () => {
  console.log("\n⏹️  SIGTERM received. Shutting down gracefully...");
  mongoose.connection.close(() => {
    console.log("✅ MongoDB connection closed");
    process.exit(0);
  });
});

process.on("SIGINT", () => {
  console.log("\n⏹️  SIGINT received. Shutting down gracefully...");
  mongoose.connection.close(() => {
    console.log("✅ MongoDB connection closed");
    process.exit(0);
  });
});

// ============================================
// Start Server
// ============================================
const PORT = process.env.PORT || 4001;
app.listen(PORT, () => {
  console.log(`\n${"=".repeat(60)}`);
  console.log(`✅ Z-FinSight Backend Server v2.1`);
  console.log(`   Running on: http://localhost:${PORT}`);
  console.log(`   Environment: ${process.env.NODE_ENV || "development"}`);
  console.log(`${"=".repeat(60)}\n`);
});

module.exports = app;