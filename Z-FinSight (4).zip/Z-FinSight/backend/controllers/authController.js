const bcrypt = require('bcryptjs');
const User = require('../models/User');
const Admin = require('../models/Admin');
const Company = require('../models/Company');
const { generateTokenPair, verifyToken } = require('./tokenService');
const { logAudit, AUDIT_ACTIONS } = require('./auditLogger');

/**
 * Auth Controller
 * Handles authentication endpoints: login, refresh, logout, /me
 */

// ============================================
// 1️⃣ User Login
// ============================================
async function userLogin(req, res) {
  try {
    const { identifier, username, email, password } = req.body;

    // Find user by identifier, username, or email
    const searchField = identifier || username || email;
    if (!searchField) {
      return res.status(400).json({
        success: false,
        message: 'Identifier, username, or email is required',
      });
    }

    const user = await User.findOne({
      $or: [
        { username: searchField },
        { email: searchField },
      ],
    }).populate('companyId');

    if (!user) {
      // Log failed login attempt
      await logAudit({
        username: searchField,
        action: AUDIT_ACTIONS.LOGIN_FAILED,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
        success: false,
        errorMessage: 'User not found',
      });

      return res.status(401).json({
        success: false,
        message: 'Invalid credentials',
      });
    }

    // Verify password
    const isPasswordValid = await bcrypt.compare(password, user.passwordHash);
    if (!isPasswordValid) {
      // Log failed login attempt
      await logAudit({
        userId: user._id,
        username: user.username,
        companyId: user.companyId?._id,
        action: AUDIT_ACTIONS.LOGIN_FAILED,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
        success: false,
        errorMessage: 'Invalid password',
      });

      return res.status(401).json({
        success: false,
        message: 'Invalid credentials',
      });
    }

    // Check if user is active
    if (!user.isActive) {
      return res.status(403).json({
        success: false,
        message: 'Your account has been deactivated. Contact your administrator.',
      });
    }

    // Check if company is active
    if (user.companyId && !user.companyId.isActive) {
      return res.status(403).json({
        success: false,
        message: 'Company account is inactive. Contact support.',
      });
    }

    // Check external user access expiry
    if (user.roles.includes('external') && user.isAccessExpired()) {
      return res.status(403).json({
        success: false,
        message: 'Your access has expired. Contact your administrator.',
      });
    }

    // Generate tokens
    const tokenPayload = {
      userId: user._id.toString(),
      roles: user.roles,
      companyId: user.companyId?._id?.toString() || null,
      companyCode: user.companyId?.companyCode || null,
      mustChangePassword: user.mustChangePassword || false,
    };
    
    // Add externalType for external users
    if (user.roles && user.roles.includes('external') && user.externalType) {
      tokenPayload.externalType = user.externalType;
    }

    const { accessToken, refreshToken, expiresAt } = generateTokenPair(tokenPayload);

    // Log successful login
    await logAudit({
      userId: user._id,
      username: user.username,
      companyId: user.companyId?._id,
      companyCode: user.companyId?.companyCode,
      action: AUDIT_ACTIONS.LOGIN,
      ipAddress: req.ip,
      userAgent: req.headers['user-agent'],
      success: true,
    });

    // Return response
    res.json({
      success: true,
      token: accessToken,
      refreshToken,
      expiresAt,
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        fullName: user.fullName,
        roles: user.roles,
        companyId: user.companyId?._id,
        companyCode: user.companyId?.companyCode,
        mustChangePassword: user.mustChangePassword,
        allowedModules: user.allowedModules,
        externalType: user.externalType || null,
      },
    });
  } catch (err) {
    console.error('User login error:', err);
    res.status(500).json({
      success: false,
      message: 'Login failed',
    });
  }
}

// ============================================
// 2️⃣ Admin Login
// ============================================
async function adminLogin(req, res) {
  try {
    const { identifier, password } = req.body;

    if (!identifier) {
      return res.status(400).json({
        success: false,
        message: 'Identifier is required',
      });
    }

    const admin = await Admin.findOne({
      $or: [
        { username: identifier },
        { email: identifier },
      ],
    });

    if (!admin) {
      await logAudit({
        username: identifier,
        action: AUDIT_ACTIONS.LOGIN_FAILED,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
        success: false,
        errorMessage: 'Admin not found',
      });

      return res.status(401).json({
        success: false,
        message: 'Invalid credentials',
      });
    }

    const isPasswordValid = await bcrypt.compare(password, admin.passwordHash);
    if (!isPasswordValid) {
      await logAudit({
        adminId: admin._id,
        username: admin.username,
        action: AUDIT_ACTIONS.LOGIN_FAILED,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
        success: false,
        errorMessage: 'Invalid password',
      });

      return res.status(401).json({
        success: false,
        message: 'Invalid credentials',
      });
    }

    if (!admin.isActive) {
      return res.status(403).json({
        success: false,
        message: 'Admin account is inactive',
      });
    }

    // Generate tokens
    const tokenPayload = {
      userId: admin._id.toString(),
      adminId: admin._id.toString(),
      roles: ['admin'],
      isAdmin: true,
    };

    const { accessToken, refreshToken, expiresAt } = generateTokenPair(tokenPayload);

    // Log successful login
    await logAudit({
      adminId: admin._id,
      username: admin.username,
      action: AUDIT_ACTIONS.LOGIN,
      ipAddress: req.ip,
      userAgent: req.headers['user-agent'],
      success: true,
    });

    res.json({
      success: true,
      token: accessToken,
      refreshToken,
      expiresAt,
      admin: {
        id: admin._id,
        username: admin.username,
        email: admin.email,
        fullName: admin.fullName,
        isAdmin: true,
      },
    });
  } catch (err) {
    console.error('Admin login error:', err);
    res.status(500).json({
      success: false,
      message: 'Login failed',
    });
  }
}

// ============================================
// 3️⃣ Refresh Token
// ============================================
async function refreshToken(req, res) {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({
        success: false,
        message: 'No token provided',
      });
    }

    const token = authHeader.split(' ')[1];

    // Verify current token (may be expired, but we still want to extract userId)
    let decoded;
    try {
      decoded = verifyToken(token);
    } catch (err) {
      // If token is expired but otherwise valid, we can still refresh
      if (err.message === 'Token expired') {
        const jwt = require('jsonwebtoken');
        decoded = jwt.decode(token);
        
        if (!decoded || !decoded.userId) {
          return res.status(401).json({
            success: false,
            message: 'Invalid token',
          });
        }
      } else {
        return res.status(401).json({
          success: false,
          message: err.message || 'Invalid token',
        });
      }
    }

    // Fetch fresh user data
    let user, admin;
    if (decoded.isAdmin && decoded.adminId) {
      admin = await Admin.findById(decoded.adminId);
      if (!admin || !admin.isActive) {
        return res.status(401).json({
          success: false,
          message: 'Admin not found or inactive',
        });
      }
    } else {
      user = await User.findById(decoded.userId).populate('companyId');
      if (!user || !user.isActive) {
        return res.status(401).json({
          success: false,
          message: 'User not found or inactive',
        });
      }

      // Check company active status
      if (user.companyId && !user.companyId.isActive) {
        return res.status(403).json({
          success: false,
          message: 'Company account is inactive',
        });
      }

      // Check external access expiry
      if (user.roles.includes('external') && user.isAccessExpired()) {
        return res.status(403).json({
          success: false,
          message: 'Your access has expired',
        });
      }
    }

    // Generate new tokens
    const tokenPayload = admin ? {
      userId: admin._id.toString(),
      adminId: admin._id.toString(),
      roles: ['admin'],
      isAdmin: true,
    } : {
      userId: user._id.toString(),
      roles: user.roles,
      companyId: user.companyId?._id?.toString() || null,
      companyCode: user.companyId?.companyCode || null,
      mustChangePassword: user.mustChangePassword || false,
    };

    const { accessToken, refreshToken: newRefreshToken, expiresAt } = generateTokenPair(tokenPayload);

    // Log token refresh
    await logAudit({
      userId: decoded.userId,
      adminId: decoded.adminId,
      companyId: user?.companyId?._id,
      action: AUDIT_ACTIONS.TOKEN_REFRESH,
      ipAddress: req.ip,
      userAgent: req.headers['user-agent'],
      success: true,
    });

    res.json({
      success: true,
      token: accessToken,
      refreshToken: newRefreshToken,
      expiresAt,
      user: user ? {
        id: user._id,
        username: user.username,
        email: user.email,
        fullName: user.fullName,
        roles: user.roles,
        companyId: user.companyId?._id,
        companyCode: user.companyId?.companyCode,
        mustChangePassword: user.mustChangePassword,
      } : undefined,
    });
  } catch (err) {
    console.error('Token refresh error:', err);
    res.status(500).json({
      success: false,
      message: 'Token refresh failed',
    });
  }
}

// ============================================
// 4️⃣ Get Current User (/me)
// ============================================
async function getMe(req, res) {
  try {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required',
      });
    }

    const { userId, isAdmin, adminId } = req.user;

    if (isAdmin && adminId) {
      const admin = await Admin.findById(adminId);
      if (!admin) {
        return res.status(404).json({
          success: false,
          message: 'Admin not found',
        });
      }

      return res.json({
        success: true,
        user: {
          id: admin._id,
          username: admin.username,
          email: admin.email,
          fullName: admin.fullName,
          isAdmin: true,
        },
      });
    }

    const user = await User.findById(userId).populate('companyId');
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    res.json({
      success: true,
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        fullName: user.fullName,
        roles: user.roles,
        department: user.department,
        companyId: user.companyId?._id,
        companyCode: user.companyId?.companyCode,
        companyName: user.companyId?.companyName,
        mustChangePassword: user.mustChangePassword,
        allowedModules: user.allowedModules,
        isActive: user.isActive,
      },
    });
  } catch (err) {
    console.error('Get me error:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch user data',
    });
  }
}

// ============================================
// 5️⃣ Logout
// ============================================
async function logout(req, res) {
  try {
    // Log logout
    await logAudit({
      userId: req.user?.userId,
      adminId: req.user?.adminId,
      companyId: req.user?.companyId,
      action: AUDIT_ACTIONS.LOGOUT,
      ipAddress: req.ip,
      userAgent: req.headers['user-agent'],
      success: true,
    });

    // In future: invalidate token in Redis/DB
    // For now, just return success (client will clear token)

    res.json({
      success: true,
      message: 'Logged out successfully',
    });
  } catch (err) {
    console.error('Logout error:', err);
    res.status(500).json({
      success: false,
      message: 'Logout failed',
    });
  }
}

module.exports = {
  userLogin,
  adminLogin,
  refreshToken,
  getMe,
  logout,
};