const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Company = require('../models/Company');
const Admin = require('../models/Admin'); // ✅ FIXED: Capital A

// ============================================
// 1️⃣ Require Authentication (JWT)
// ============================================
const requireAuth = async (req, res, next) => {
  try {
    // ✅ Get token from header
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required. No token provided.',
      });
    }

    const token = authHeader.split(' ')[1];

    // ✅ Verify token (this will throw if expired or invalid)
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    // ✅ Enforce exp claim exists (production readiness)
    if (!decoded.exp) {
      return res.status(401).json({
        success: false,
        message: 'Invalid token: missing expiration',
      });
    }

    // ✅ Standardize user object structure
    req.user = {
      userId: decoded.userId,
      roles: decoded.roles || [],
      companyId: decoded.companyId,
      companyCode: decoded.companyCode,
      mustChangePassword: decoded.mustChangePassword || false,
      externalType: decoded.externalType || null, // For external users
      // Legacy support
      isAdmin: decoded.isAdmin || false,
      adminId: decoded.adminId,
    };
    
    next();
  } catch (err) {
    if (err.name === 'JsonWebTokenError') {
      return res.status(401).json({
        success: false,
        message: 'Invalid token',
      });
    }
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({
        success: false,
        message: 'Token expired. Please login again.',
      });
    }
    return res.status(500).json({
      success: false,
      message: 'Authentication error',
    });
  }
};

// ============================================
// 2️⃣ Require Specific Roles
// ============================================
const requireRoles = (allowedRoles) => {
  return async (req, res, next) => {
    try {
      // ✅ Must have user info from requireAuth
      if (!req.user) {
        return res.status(401).json({
          success: false,
          message: 'Authentication required',
        });
      }

      const { roles, isAdmin } = req.user;

      // ✅ Admin bypass (if explicitly marked as admin or has admin role)
      if (isAdmin || (roles && roles.includes('admin'))) {
        return next();
      }

      // ✅ Check if user has any of the allowed roles
      if (!roles || !Array.isArray(roles) || roles.length === 0) {
        return res.status(403).json({
          success: false,
          message: 'Forbidden',
        });
      }

      const hasPermission = roles.some(role => allowedRoles.includes(role));

      if (!hasPermission) {
        return res.status(403).json({
          success: false,
          message: 'Forbidden',
        });
      }

      next();
    } catch (err) {
      return res.status(500).json({
        success: false,
        message: 'Authorization error',
      });
    }
  };
};

// ============================================
// 2.5️⃣ Require Scope (Scaffold for future use)
// ============================================
const requireScope = (scope) => {
  return async (req, res, next) => {
    try {
      if (!req.user) {
        return res.status(401).json({
          success: false,
          message: 'Authentication required',
        });
      }

      // TODO: Implement scope-based authorization
      // For now, this is a scaffold that allows all authenticated users
      // Future implementation could check req.user.scopes array
      
      next();
    } catch (err) {
      return res.status(500).json({
        success: false,
        message: 'Scope verification error',
      });
    }
  };
};

// ============================================
// 3️⃣ Require Company Scope (Tenant Scoping)
// ============================================
const requireCompanyScope = async (req, res, next) => {
  try {
    // ✅ Must have user info from requireAuth
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required',
      });
    }

    const { companyId, companyCode } = req.user;

    // ✅ Ensure companyId or companyCode exists
    if (!companyId && !companyCode) {
      return res.status(403).json({
        success: false,
        message: 'Forbidden',
      });
    }

    // ✅ For finance modules, NEVER accept companyId from client query params
    // Always use req.user.companyId from token
    if (req.query.companyId || req.query.companyCode || req.body.companyId || req.body.companyCode) {
      const clientCompanyId = req.query.companyId || req.body.companyId;
      const clientCompanyCode = req.query.companyCode || req.body.companyCode;

      // Verify client-provided company matches token company
      if (clientCompanyId && clientCompanyId !== companyId) {
        return res.status(403).json({
          success: false,
          message: 'Forbidden',
        });
      }

      if (clientCompanyCode && clientCompanyCode !== companyCode) {
        return res.status(403).json({
          success: false,
          message: 'Forbidden',
        });
      }
    }

    // ✅ Attach company info to request for use in routes
    req.userCompanyId = companyId;
    req.userCompanyCode = companyCode;

    next();
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: 'Company scope verification error',
    });
  }
};

// ============================================
// 3.5️⃣ Require Active Company (Legacy - kept for backward compatibility)
// ============================================
const requireActiveCompany = async (req, res, next) => {
  try {
    // ✅ Must have user info from requireAuth
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required',
      });
    }

    const { companyId } = req.user;

    if (!companyId) {
      return res.status(403).json({
        success: false,
        message: 'Forbidden',
      });
    }

    // ✅ Check if company exists and is active
    const company = await Company.findById(companyId);

    if (!company) {
      return res.status(404).json({
        success: false,
        message: 'Company not found',
      });
    }

    if (!company.isActive) {
      return res.status(403).json({
        success: false,
        message: 'Company account is inactive. Contact support.',
      });
    }

    // ✅ Attach company info to request (optional)
    req.company = company;

    next();
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: 'Company verification error',
    });
  }
};

// ============================================
// 4️⃣ Check External User Access
// ============================================
const checkExternalAccess = async (req, res, next) => {
  try {
    // ✅ Must have user info from requireAuth
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required',
      });
    }

    const { userId, roles } = req.user;

    // ✅ Skip check if not external user
    if (!roles || !roles.includes('external')) {
      return next();
    }

    // ✅ Fetch user from database
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found',
      });
    }

    // ✅ Check access expiry
    if (user.isAccessExpired()) {
      return res.status(403).json({
        success: false,
        message: 'Your access has expired. Contact your administrator.',
      });
    }

    // ✅ Attach allowedModules to request for route-level checks
    req.allowedModules = user.allowedModules || [];

    next();
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: 'Access verification error',
      error: err.message,
    });
  }
};

// ============================================
// 5️⃣ Require Module Access (for external users)
// ============================================
const requireModuleAccess = (moduleName) => {
  return async (req, res, next) => {
    try {
      const { roles } = req.user;

      // ✅ Non-external users have full access
      if (!roles || !roles.includes('external')) {
        return next();
      }

      // ✅ Check if module is allowed for external user
      const allowedModules = req.allowedModules || [];

      if (!allowedModules.includes(moduleName)) {
        return res.status(403).json({
          success: false,
          message: `Access denied. You don't have permission to access the ${moduleName} module.`,
        });
      }

      next();
    } catch (err) {
      return res.status(500).json({
        success: false,
        message: 'Module access verification error',
        error: err.message,
      });
    }
  };
};

// ============================================
// 6️⃣ Admin-Only Access
// ============================================
const requireAdmin = async (req, res, next) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: 'Authentication required',
      });
    }

    const { isAdmin, adminId } = req.user;

    if (!isAdmin || !adminId) {
      return res.status(403).json({
        success: false,
        message: 'Admin access required',
      });
    }

    // ✅ Verify admin exists and is active
    const admin = await Admin.findById(adminId);

    if (!admin) {
      return res.status(404).json({
        success: false,
        message: 'Admin not found',
      });
    }

    if (!admin.isActive) {
      return res.status(403).json({
        success: false,
        message: 'Admin account is inactive',
      });
    }

    next();
  } catch (err) {
    return res.status(500).json({
      success: false,
      message: 'Admin verification error',
      error: err.message,
    });
  }
};

module.exports = {
  requireAuth,
  requireRoles,
  requireScope,
  requireCompanyScope,
  requireActiveCompany,
  checkExternalAccess,
  requireModuleAccess,
  requireAdmin,
};