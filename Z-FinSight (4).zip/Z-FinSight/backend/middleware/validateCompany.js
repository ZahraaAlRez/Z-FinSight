function resolveCompanyId(req) {
  // admin can query any companyId, others must use token companyId
  const q = req.query.companyId || req.body.companyId || "";
  if ((req.user?.role || "") === "admin") return q || req.user.companyId;
  return req.user?.companyId;
}
module.exports = { resolveCompanyId };
