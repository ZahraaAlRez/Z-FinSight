const jwt = require('jsonwebtoken');

/**
 * Token Service
 * Centralized token generation and validation with expiry handling
 */

// Token expiry times (in seconds)
const TOKEN_EXPIRY = {
  ACCESS: 60 * 60, // 1 hour
  REFRESH: 7 * 24 * 60 * 60, // 7 days
  REMEMBER_ME: 30 * 24 * 60 * 60, // 30 days
};

/**
 * Generate access token with expiry
 * @param {Object} payload - User data to encode
 * @param {Object} options - Additional options
 * @returns {string} JWT token
 */
function generateAccessToken(payload, options = {}) {
  const { expiresIn = TOKEN_EXPIRY.ACCESS } = options;

  if (!process.env.JWT_SECRET) {
    throw new Error('JWT_SECRET not configured in environment');
  }

  // Ensure payload has required fields
  const tokenPayload = {
    userId: payload.userId,
    roles: payload.roles || [],
    companyId: payload.companyId || null,
    companyCode: payload.companyCode || null,
    mustChangePassword: payload.mustChangePassword || false,
    isAdmin: payload.isAdmin || false,
    adminId: payload.adminId || null,
    // Add timestamp
    iat: Math.floor(Date.now() / 1000),
  };

  return jwt.sign(tokenPayload, process.env.JWT_SECRET, {
    expiresIn,
  });
}

/**
 * Generate refresh token (longer expiry)
 * @param {Object} payload - User data to encode
 * @returns {string} JWT refresh token
 */
function generateRefreshToken(payload) {
  if (!process.env.JWT_SECRET) {
    throw new Error('JWT_SECRET not configured in environment');
  }

  const tokenPayload = {
    userId: payload.userId,
    type: 'refresh',
    iat: Math.floor(Date.now() / 1000),
  };

  return jwt.sign(tokenPayload, process.env.JWT_SECRET, {
    expiresIn: TOKEN_EXPIRY.REFRESH,
  });
}

/**
 * Verify and decode token
 * @param {string} token - JWT token to verify
 * @returns {Object} Decoded payload
 * @throws {Error} If token is invalid or expired
 */
function verifyToken(token) {
  if (!process.env.JWT_SECRET) {
    throw new Error('JWT_SECRET not configured in environment');
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // Enforce exp claim exists
    if (!decoded.exp) {
      throw new Error('Invalid token: missing expiration');
    }

    return decoded;
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      throw new Error('Token expired');
    }
    if (err.name === 'JsonWebTokenError') {
      throw new Error('Invalid token');
    }
    throw err;
  }
}

/**
 * Decode token without verification (for debugging)
 * @param {string} token - JWT token
 * @returns {Object|null} Decoded payload or null
 */
function decodeToken(token) {
  try {
    return jwt.decode(token);
  } catch (err) {
    return null;
  }
}

/**
 * Check if token is expired
 * @param {string} token - JWT token
 * @returns {boolean} True if expired
 */
function isTokenExpired(token) {
  try {
    const decoded = decodeToken(token);
    if (!decoded || !decoded.exp) return true;
    
    const now = Math.floor(Date.now() / 1000);
    return decoded.exp < now;
  } catch {
    return true;
  }
}

/**
 * Get token expiry timestamp
 * @param {string} token - JWT token
 * @returns {number|null} Unix timestamp or null
 */
function getTokenExpiry(token) {
  try {
    const decoded = decodeToken(token);
    return decoded?.exp || null;
  } catch {
    return null;
  }
}

/**
 * Generate both access and refresh tokens
 * @param {Object} payload - User data
 * @param {Object} options - Token options
 * @returns {Object} { accessToken, refreshToken, expiresAt }
 */
function generateTokenPair(payload, options = {}) {
  const accessToken = generateAccessToken(payload, options);
  const refreshToken = generateRefreshToken(payload);
  
  const decoded = decodeToken(accessToken);
  const expiresAt = decoded?.exp ? new Date(decoded.exp * 1000).toISOString() : null;

  return {
    accessToken,
    refreshToken,
    expiresAt,
  };
}

module.exports = {
  TOKEN_EXPIRY,
  generateAccessToken,
  generateRefreshToken,
  verifyToken,
  decodeToken,
  isTokenExpired,
  getTokenExpiry,
  generateTokenPair,
};