const jwt = require("jsonwebtoken");

function requireAuth(req, res, next) {
  try {
    const h = req.headers.authorization || "";
    const token = h.startsWith("Bearer ") ? h.slice(7) : null;
    if (!token) return res.status(401).json({ success: false, message: "Missing token" });

    const decoded = jwt.verify(token, process.env.JWT_SECRET || "CHANGE_ME");
    req.user = {
      userId: decoded.userId,
      role: (decoded.role || "").toLowerCase(),
      companyId: decoded.companyId
    };
    next();
  } catch (e) {
    return res.status(401).json({ success: false, message: "Invalid token" });
  }
}

function requireRole(roles = []) {
  return (req, res, next) => {
    const r = (req.user?.role || "").toLowerCase();
    if (!roles.includes(r)) return res.status(403).json({ success: false, message: "Forbidden" });
    next();
  };
}

module.exports = { requireAuth, requireRole };
