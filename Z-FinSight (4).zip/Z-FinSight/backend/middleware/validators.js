const { z } = require("zod");

// ============================================
// Validation Schemas
// ============================================

/**
 * User Login Schema
 * Accepts identifier, username, or email (for compatibility)
 */
const userLoginSchema = z.object({
  identifier: z.string().trim().min(1).optional(),
  username: z.string().trim().min(1).optional(),
  email: z.string().email().optional(),
  password: z.string().min(1, "Password is required"),
}).refine(
  (data) => data.identifier || data.username || data.email,
  {
    message: "Must provide identifier, username, or email",
    path: ["identifier"],
  }
);

/**
 * Change Password Schema
 */
const changePasswordSchema = z.object({
  identifier: z.string().trim().min(1).optional(),
  username: z.string().trim().min(1).optional(),
  email: z.string().email().optional(),
  oldPassword: z.string().min(1, "Old password is required"),
  newPassword: z.string().min(6, "Password must be at least 6 characters"),
  confirmNewPassword: z.string().min(1, "Password confirmation is required"),
}).refine(
  (data) => data.identifier || data.username || data.email,
  {
    message: "Must provide identifier, username, or email",
    path: ["identifier"],
  }
).refine(
  (data) => data.newPassword === data.confirmNewPassword,
  {
    message: "New passwords do not match",
    path: ["confirmNewPassword"],
  }
).refine(
  (data) => data.oldPassword !== data.newPassword,
  {
    message: "New password must be different from current password",
    path: ["newPassword"],
  }
);

/**
 * Create User Schema
 */
const createUserSchema = z.object({
  companyId: z.string().min(1, "Company ID is required"),
  fullName: z.string().trim().min(1, "Full name is required"),
  username: z.string().trim().min(1, "Username is required"),
  email: z.string().email("Invalid email address"),
  department: z.string().trim().min(1, "Department is required"),
  roles: z.array(z.enum(["admin", "manager", "accountant", "financial_analyst", "external"])).min(1, "At least one role is required"),
  password: z.string().min(6, "Password must be at least 6 characters").optional(),
  externalType: z.enum(["bank", "investor", "government", "auditor", "other"]).optional(),
  allowedModules: z.array(z.enum(["profitability", "market", "efficiency", "debt", "liquidity", "tax"])).optional(),
  accessExpiry: z.string().datetime().optional().or(z.date().optional()),
});

// ============================================
// Validation Middleware
// ============================================

/**
 * Validate request body against a Zod schema
 * @param {z.ZodSchema} schema - Zod schema to validate against
 * @returns {Function} Express middleware
 */
const validate = (schema) => {
  return (req, res, next) => {
    try {
      // Validate and transform the request body
      const validated = schema.parse(req.body);
      
      // Replace req.body with validated and transformed data
      req.body = validated;
      
      next();
    } catch (error) {
      if (error instanceof z.ZodError) {
        // Return first error message for cleaner responses
        const firstError = error.errors[0];
        return res.status(400).json({
          success: false,
          message: firstError.message || "Validation error",
        });
      }
      
      // Unexpected error
      return res.status(500).json({
        success: false,
        message: "Validation error",
      });
    }
  };
};

module.exports = {
  userLoginSchema,
  changePasswordSchema,
  createUserSchema,
  validate,
};
