# Z-FinSight Backend - Complete API

Full backend server for Z-FinSight with user management, authentication, and email verification.

---

## 📁 File Structure

```
backend/
├── server.js              # Main server file
├── .env.example           # Environment variables template
├── package.json           # Dependencies
├── routes/
│   ├── register.js        # Company & Admin registration
│   ├── auth.js            # Login & authentication
│   └── users.js           # User management (NEW)
└── models/
    ├── Company.js         # Company data model
    ├── Admin.js           # Admin data model
    ├── User.js            # User data model (NEW)
    └── VerificationCode.js # Email verification codes
```

---

## 🚀 Quick Start

### 1. Install Dependencies
```bash
cd backend
npm install
```

### 2. Configure Environment
Copy `.env.example` to `.env` and fill in your credentials:
```bash
cp .env.example .env
```

Edit `.env` with:
- MongoDB Atlas connection string
- Gmail credentials
- JWT secret

### 3. Start Server

**Development mode:**
```bash
npm run dev
```

**Production mode:**
```bash
npm start
```

---

## 📡 Available APIs

### **Contact Form**
```
POST /api/contact
Body: { fullName, email, message }
```

### **Company Registration**
```
POST /api/register/company
Body: {
  companyName,
  industry,
  industryOther,
  country,
  countryOther,
  currencies: ["USD", "LBP"],
  companyEmail
}
Response: {
  success: true,
  data: {
    companyId: "CMP_001",  // Auto-generated
    companyDbId: "...",    // MongoDB _id
    companyName: "..."
  }
}
```

### **Admin Registration**
```
POST /api/register/admin
Body: {
  companyId,           // MongoDB _id from company registration
  fullName,
  username,
  email,
  password,
  confirmPassword
}
Response: { success: true, message: "Verification code sent" }
```

### **Email Verification**
```
POST /api/register/verify
Body: { email, otpCode }
Response: {
  success: true,
  data: {
    companyId: "CMP_001",
    companyName: "..."
  }
}
```

### **Resend OTP**
```
POST /api/register/resend-otp
Body: { email }
Response: { success: true }
```

### **Login**
```
POST /api/auth/login
Body: {
  identifier,  // username or email
  password
}
Response: {
  success: true,
  data: {
    token,     // JWT token
    admin: { ... },
    company: { ... }
  }
}
```

### **Add Users (NEW)**
```
POST /api/users/add
Body: {
  companyId,  // MongoDB _id
  users: [
    {
      fullName: "John Doe",
      username: "johndoe",
      email: "john@company.com",
      department: "Engineering",
      role: "user",        // admin | manager | accountant | user
      password: "temp123"  // Initial password
    }
  ]
}
Response: {
  success: true,
  message: "2 user(s) created successfully",
  data: {
    created: [...],
    errors: [...]  // If any failed
  }
}
```

### **Get Users (NEW)**
```
GET /api/users/:companyId
Response: {
  success: true,
  data: {
    companyId: "CMP_001",
    companyName: "...",
    users: [...]
  }
}
```

### **Change Password (NEW)**
```
POST /api/users/change-password
Body: {
  username,
  oldPassword,
  newPassword
}
Response: { success: true }
```

---

## 🗄️ Database Models

### **Company**
```javascript
{
  companyId: "CMP_001",          // Auto-generated
  companyName: "...",
  industry: "finance",           // Used for news & recommendations
  country: "lb",                 // Used for news & recommendations
  currencies: ["USD", "LBP"],    // Used for exchange rates in dashboard
  companyEmail: "...",
  createdAt: Date
}
```

### **Admin**
```javascript
{
  companyId: ObjectId,           // Reference to Company
  fullName: "...",
  username: "...",
  email: "...",
  passwordHash: "...",
  isVerified: true/false,
  createdAt: Date
}
```

### **User (NEW)**
```javascript
{
  companyId: ObjectId,           // Reference to Company
  fullName: "...",
  username: "...",
  email: "...",
  department: "Engineering",
  role: "user",                  // Different dashboards per role
  initialPasswordHash: "...",    // First password (kept for records)
  currentPasswordHash: "...",    // Current password
  isFirstLogin: true/false,      // Forces password change on first login
  createdAt: Date,
  updatedAt: Date
}
```

---

## 🔐 Security Features

✅ Password hashing with bcrypt  
✅ Email verification with OTP  
✅ JWT token authentication  
✅ Duplicate username/email prevention  
✅ Password history (initial + current)  
✅ First login password change enforcement  

---

## 🎯 Key Features

### **Company Data for Dashboard**
- Industry & Country saved → Used for:
  - News filtering (industry + country specific)
  - Top companies recommendations (competitors)
  - Market insights
  
- Currencies saved → Used for:
  - Exchange rate display in dashboard
  - Multi-currency financial reports

### **User Management**
- Multiple users per company
- Role-based access (admin, manager, accountant, user)
- Different dashboards based on role
- Password tracking (initial + current)
- Force password change on first login

---

## 🧪 Testing

### Test Server
```bash
curl http://localhost:4001
# Response: ✅ Z-FinSight Backend is running!
```

### Test Company Registration
```bash
curl -X POST http://localhost:4001/api/register/company \
  -H "Content-Type: application/json" \
  -d '{
    "companyName": "Test Corp",
    "industry": "finance",
    "country": "lb",
    "currencies": ["USD", "LBP"]
  }'
```

---

## 🐛 Troubleshooting

**MongoDB connection failed:**
- Check MONGO_URI in `.env`
- Ensure IP is whitelisted in MongoDB Atlas
- Verify username/password

**Emails not sending:**
- Check Gmail credentials in `.env`
- Use App Password (not regular password)
- Enable 2-factor authentication on Gmail

**Port already in use:**
```bash
# Kill process on port 4001
lsof -ti:4001 | xargs kill -9
```

---

**Created for Z-FinSight Project** 🚀