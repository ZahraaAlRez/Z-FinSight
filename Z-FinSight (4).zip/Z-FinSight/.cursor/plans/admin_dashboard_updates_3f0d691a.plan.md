---
name: Admin Dashboard Updates
overview: Update admin-dashboard.html to fix dropdown z-index, increase spacing, remove News Impact Trend card, add accounting cards, add chart help icons, enhance right column lists, rename button, restructure Analytics Hub, and ensure all new content is i18n-ready.
todos:
  - id: fix-dropdown
    content: Fix dropdown z-index to 99999 and ensure proper stacking context. Update dropdown action handlers (Profile → Company Settings + scroll, Settings → Company Settings, Logout → clear token + redirect)
    status: in_progress
  - id: increase-spacing
    content: "Increase gaps: .grid (18px→24px), .stats (12px→16px), .mid (14px→20px), .right (14px→18px), .list items (10px→14px). Increase padding: .box (14px→18px), .stat (14px→16px). Keep design identical"
    status: pending
  - id: remove-trend-card
    content: Remove the entire 'News Impact Trend' card (id='impactTrendCard') from Overview page
    status: pending
  - id: add-accounting-cards
    content: "Add 4 new accounting snapshot cards to Overview: After-Tax Profit, Net Profit Margin, Tax Burden %, Liquidity (Current Ratio). Match existing stat card design and add i18n keys"
    status: pending
    dependencies:
      - remove-trend-card
  - id: add-chart-help-icons
    content: Add circular '!' info icons to newsImpactCard and priorityCard. Implement click handlers to show modal with chart help text. Add i18n keys for help content
    status: pending
  - id: add-list-actions
    content: Add three dots icon (⋯) to each item in Latest Updates and Latest AI Recommendations lists. Add 'View more' links at bottom of each card with navigation handlers
    status: pending
  - id: rename-company-button
    content: Rename 'Add Company' button to 'Update Company' and update click handler to redirect to register.html. Add i18n key
    status: pending
  - id: restructure-analytics
    content: "Restructure Analytics Hub with 6 sections: Tax Process Analysis (Profit Tax, VAT, Payroll, Tax burden %, After-tax profit), Profitability Analysis (Gross/Net profit, margins, MoM/YoY, insight box), Market Analysis (Market position, growth vs market, competitors), Efficiency Analysis (Revenue/employee, cost/unit, asset utilization), Debt Analysis (Total debt, Debt/Equity, interest coverage), Liquidity Analysis (Current ratio, cash, short-term liabilities). Add i18n keys"
    status: pending
  - id: dynamic-welcome
    content: "Update welcome card title to use dynamic company name: ${companyName} Administrator (fallback to 'Company Administrator'). Use getCompanyName() function"
    status: pending
  - id: update-i18n
    content: "Add all new translation keys to js/lang.js using localStorage.getItem('lang'). Keys for: accounting cards, chart help text, view more links, update company button, analytics sections (6 sections), welcome administrator text. Support en, fr, ar, zh. Do NOT break existing keys"
    status: pending
    dependencies:
      - add-accounting-cards
      - add-chart-help-icons
      - add-list-actions
      - rename-company-button
      - restructure-analytics
      - dynamic-welcome
  - id: verify-no-breaking
    content: Verify all existing pages remain, navigation works, dropdown is functional, existing i18n keys intact, design system preserved
    status: pending
    dependencies:
      - fix-dropdown
      - increase-spacing
      - remove-trend-card
      - add-accounting-cards
      - add-chart-help-icons
      - add-list-actions
      - rename-company-button
      - restructure-analytics
      - dynamic-welcome
      - update-i18n
---

# Admin Dashboard Updates

## Overview

Update `admin-dashboard.html` with 10 specific requirements while preserving the existing design system (colors, typography, radius, shadows, layout style). All new text must use `data-i18n` attributes and corresponding entries in `js/lang.js`.

## Implementation Details

### 1. Fix Admin Dropdown Z-Index Issue

**File**: `admin-dashboard.html` (CSS section)

**Changes**:

- Ensure `.topbar` has `overflow: visible;` (already present at line 67)
- Ensure `.top-actions` has `position: relative; overflow: visible;` (check line 137)
- Increase `.dropdown` z-index from `60` (line 220) to `99999`
- Check and remove/avoid stacking context issues in parent wrappers:
- Verify no parent containers have `overflow: hidden` that clips the dropdown
- Avoid transforms that create new stacking contexts (do NOT remove animations globally)
- Update dropdown action handlers in JavaScript (lines 1286-1314):
- Profile → opens Company Settings tab + scroll to "Company Profile" section
- Settings → opens Company Settings tab (same page)
- Logout → clears localStorage keys (token, etc.) and redirects to `login.html`
- **Result**: Dropdown items must always appear fully on top

### 2. Increase Spacing and Layout Sizes

**File**: `admin-dashboard.html` (CSS section)

**Changes**:

- Increase `.grid` gap from `18px` (line 253) to `24px`
- Increase `.stats` gap from `12px` (line 425) to `16px` (conservative increase)
- Increase `.mid` gap from `14px` (line 470) to `20px`
- Increase `.right` gap from `14px` (line 574) to `18px`
- Increase `.list` item margin-bottom from `10px` (line 593) to `14px`
- Increase card padding slightly: `.box` padding from `14px` (line 475) to `18px` (or equivalent p-20)
- Increase `.stat` padding from `14px` (line 430) to `16px`
- Optionally increase `.wrap` max-width from `1450px` (line 44) to `1500px` if needed for better screen fill
- **Rule**: Keep design identical; only adjust sizes/gaps for readability

### 3. Remove News Impact Trend Card

**File**: `admin-dashboard.html` (HTML section)

**Changes**:

- Remove the entire `<div class="card big" id="impactTrendCard">` block (lines 960-969)

### 4. Add Accounting Snapshot Cards to Overview

**File**: `admin-dashboard.html` (HTML section, after stats row)

**Changes**:

- Add new row after the existing stats row (after line 932)
- Create 4 new stat cards matching existing `.stat` design:
- After-Tax Profit (with value, label, icon)
- Net Profit Margin (with value, label, icon)
- Tax Burden % (with value, label, icon)
- Liquidity (Current Ratio) (with value, label, icon)
- Use same card structure as existing stats (`.card.stat`)
- Add `data-i18n` attributes for all labels
- Add corresponding i18n keys to `js/lang.js`

### 5. Add Info Icons to Charts

**File**: `admin-dashboard.html` (HTML + CSS + JS sections)

**Changes**:

- Add circular "!" icon to top-right of `#newsImpactCard` (line 935)
- Add circular "!" icon to top-right of `#priorityCard` (line 946)
- Style: small circular icon, positioned absolutely in top-right corner
- On click: show modal with help text explaining:
- How to read the chart
- What increasing/decreasing means
- Example interpretation (business meaning)
- Use existing `.modal-backdrop` and `.modal` structure (lines 1133-1141)
- Add `data-i18n` attributes for help text
- Add click handlers in JavaScript section

### 6. Right Column Lists: Three Dots + View More

**File**: `admin-dashboard.html` (HTML + CSS + JS sections)

**Changes**:

- Add three dots icon (⋯) to each `.item` in `#latestUpdates` and `#latestRecs`
- Position dots aligned to the right of each item
- Add "View more" link at bottom of `#latestUpdatesCard` and `#latestRecsCard`
- "View more" in Latest Updates → navigate to `page-news` (setActivePage("news"))
- "View more" in AI Recommendations → navigate to `page-recs` (setActivePage("recs"))
- Add `data-i18n` attributes for "View more" text
- Update CSS for item layout to accommodate dots

### 7. Rename "Add Company" to "Update Company"

**File**: `admin-dashboard.html` (HTML + JS sections)

**Changes**:

- Change button text from "Add Company" to "Update Company" (line 1122)
- Update `data-i18n` attribute to new key
- Update click handler (line 1518) to redirect to `register.html`
- Add new i18n key to `js/lang.js`

### 8. Restructure Analytics Hub

**File**: `admin-dashboard.html` (HTML section, `#page-analytics`)

**Changes**:

- Keep as single page (no new HTML files)
- Add 6 clear section headers with specific content:

1. **Tax Process Analysis**

- Profit Tax, VAT, Payroll taxes, Tax burden %, After-tax profit

2. **Profitability Analysis**

- Gross profit, Net profit, margins, MoM/YoY trend, insight box

3. **Market Analysis**

- Market position, company growth vs market growth, competitors/top companies snapshot

4. **Efficiency Analysis**

- Revenue per employee, cost per unit, asset utilization

5. **Debt Analysis**

- Total debt, Debt/Equity, interest coverage

6. **Liquidity Analysis**

- Current ratio, cash, short-term liabilities
- Each section should show bullet points/content matching the above
- Add "Insight box" info text explaining significance, YoY comparisons, benchmarks
- Use existing card structure (consistent with design system, but not crowded)
- Add `data-i18n` attributes for all new text

### 9. Dynamic Welcome Card Text

**File**: `admin-dashboard.html` (JavaScript section)

**Changes**:

- Update welcome card title to use dynamic company name:
- Change from static "Z-FinSight Administrator" to `${companyName} Administrator`
- Fallback to "Company Administrator" if companyName is not available
- Update `setTopCompanyUI()` function or welcome card rendering to use `getCompanyName()`
- Add i18n key for "Administrator" suffix if needed

### 10. Translation System (i18n)

**File**: `js/lang.js`

**Changes**:

- Use `localStorage.getItem("lang")` as the language key (do NOT invent new key)
- Add all new translation keys for:
- Accounting snapshot cards (4 cards × 4 languages)
- Chart help text (2 charts × 4 languages)
- "View more" text (2 languages)
- "Update Company" button
- Analytics Hub section titles and content (6 sections × 4 languages)
- Dropdown action labels (if missing)
- Welcome card "Administrator" text
- Ensure keys follow existing naming convention
- Support: en, fr, ar, zh
- **Do NOT break existing translations**

### 11. Ensure No Breaking Changes

**Verification**:

- All existing pages remain in sidebar (Overview, Analytics Hub, Recommendations, News & Competitors, Users & Access, Identity Cards, Company Settings)
- Navigation works (sidebar switching, no full page reload)
- Dropdown menu visible and functional (always on top)
- Existing i18n keys remain intact
- Design system preserved (colors, gradients, typography, radius, shadows, card styles)
- Top bar center shows Company Name or Company ID (prefer Company Name) - verify this is working

## Files to Modify

1. **admin-dashboard.html**

- CSS section: dropdown z-index, spacing adjustments
- HTML section: remove impactTrendCard, add accounting cards, add info icons, add three dots/view more, rename button, restructure Analytics Hub
- JavaScript section: update dropdown handlers, add chart help handlers, add navigation handlers

2. **js/lang.js**

- Add all new i18n keys for en, fr, ar, zh

## CSS Selectors to Change

- `.dropdown` → z-index: 99999
- `.top-actions` → ensure `overflow: visible;` (in addition to `position: relative;`)
- `.grid` → gap: 24px (from 18px)
- `.stats` → gap: 16px (from 12px) - conservative increase
- `.mid` → gap: 20px (from 14px)
- `.right` → gap: 18px (from 14px)
- `.list .item` → margin-bottom: 14px (from 10px)
- `.box` → padding: 18px (from 14px, or equivalent p-20)
- `.stat` → padding: 16px (from 14px)
- `.wrap` → max-width: 1500px (optional, from 1450px) for better screen fill

## Deliverables

- Updated `admin-dashboard.html` with all changes
- Updated `js/lang.js` with new translation keys
- Dropdown fixed and functional
- Overview page without News Impact Trend, with Accounting Snapshot cards
- All new content translation-ready