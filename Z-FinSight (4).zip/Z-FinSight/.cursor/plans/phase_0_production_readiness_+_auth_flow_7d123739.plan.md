---
name: Phase 0 Production Readiness + Auth Flow
overview: Implement production-ready security hardening for backend (helmet, CORS, rate limiting, JWT expiration, validation, unified error handling) and create a clean frontend auth system with js/auth.js. Consolidate admin login into user-login flow while maintaining backward compatibility.
todos:
  - id: backend-deps
    content: Add helmet, express-rate-limit, zod to package.json
    status: completed
  - id: security-middleware
    content: Add helmet and rate limiting to server.js
    status: completed
  - id: cors-env
    content: Update CORS to use CORS_ORIGIN env variable
    status: completed
  - id: jwt-standardize
    content: Update JWT tokens to include companyId, companyCode, and enforce exp
    status: completed
  - id: auth-middleware
    content: Update requireAuth middleware to verify exp and standardize responses
    status: completed
  - id: rbac-middleware
    content: Enhance requireRoles and add requireScope scaffold
    status: completed
  - id: tenant-scoping
    content: Create requireCompanyScope middleware
    status: completed
  - id: validation-layer
    content: Create validators.js with Zod schemas and validate middleware
    status: completed
  - id: error-handler
    content: Update unified error handler in server.js
    status: completed
  - id: auth-me-endpoint
    content: Add GET /api/auth/me endpoint
    status: completed
  - id: response-standardize
    content: Ensure all routes return standardized {success, message, data} format
    status: completed
  - id: frontend-auth-js
    content: Create js/auth.js with apiFetch, getMe, guardPage functions
    status: completed
  - id: login-update
    content: Update login.html to use js/auth.js and store zf_token/zf_user
    status: completed
  - id: dashboard-guards
    content: Add guardPage() calls to all dashboard HTML files
    status: completed
  - id: logout-functionality
    content: Add logout buttons/functionality to dashboards
    status: completed
---

# Phase 0 Production Readiness + Auth Flow Implementation

## A. Backend Hardening

### 1. Security Middleware Setup
**File: `backend/server.js`**
- Add `helmet` middleware for security headers
- Update CORS to use `CORS_ORIGIN` env variable (comma-separated), default to `http://localhost:5500,http://127.0.0.1:5500`
- Add rate limiting specifically for `/api/auth/*` routes (5 requests per 15 minutes per IP)

**Dependencies to add:**
- `helmet` - Security headers
- `express-rate-limit` - Rate limiting

### 2. JWT Token Standardization
**File: `backend/routes/auth.js`**
- Update `/api/auth/user-login` to issue tokens with:
  - `expiresIn: "12h"` (or 24h based on requirement)
  - Payload: `{ userId, roles, companyId (ObjectId), companyCode (string like "CMP_001"), mustChangePassword }`
- Update `/api/auth/login` (admin) to use same structure but mark as deprecated
- Ensure all JWT tokens include `exp` claim

### 3. Unified Auth Middleware
**File: `backend/middleware/authGuard.js`**
- Update `requireAuth` to:
  - Verify JWT and check `exp` exists
  - Attach `req.user = { userId, roles, companyId, companyCode, mustChangePassword }`
  - Return standardized 401 JSON: `{success:false,message:"..."}`
  - Handle TokenExpiredError and JsonWebTokenError separately

### 4. RBAC Middleware Enhancement
**File: `backend/middleware/authGuard.js`**
- Update `requireRoles(roles[])` to work with unified user model
- Add `requireScope(scope)` function (scaffold for future use)
- Ensure 403 responses: `{success:false,message:"Forbidden"}`

### 5. Tenant Scoping Middleware
**File: `backend/middleware/authGuard.js`**
- Create `requireCompanyScope` middleware:
  - Ensures `req.user.companyId` or `req.user.companyCode` exists
  - For finance modules, NEVER accept companyId from client query params
  - Always use `req.user.companyId` from token
  - Return 403 if companyId mismatch detected

### 6. Validation Layer with Zod
**File: `backend/middleware/validators.js` (NEW)**
- Create validation schemas:
  - `userLoginSchema`: validates `{identifier/username/email, password}`
  - `changePasswordSchema`: validates `{identifier/username/email, oldPassword, newPassword, confirmNewPassword}`
  - `createUserSchema`: validates user creation body
- Create `validate(schema)` middleware function

**Dependencies to add:**
- `zod` - Schema validation

**Files to update:**
- `backend/routes/auth.js` - Add validation middleware to routes
- `backend/routes/users.js` - Add validation to user creation

### 7. Unified Error Handler
**File: `backend/server.js`**
- Update existing error handler to:
  - Handle Zod validation errors (400 with message)
  - Handle JWT errors (401)
  - Handle authorization errors (403)
  - Handle 404 (already exists)
  - All errors return: `{success:false,message:"..."}`
  - In development, include `error` field with details

### 8. GET /api/auth/me Endpoint
**File: `backend/routes/auth.js`**
- Add `GET /api/auth/me` route
- Protected by `requireAuth`
- Returns: `{success:true,user:{userId,roles,companyId,companyCode,mustChangePassword}}`
- Uses data from `req.user` (from JWT)

### 9. Response Standardization
**Files: All route files**
- Ensure all responses follow pattern:
  - Success: `{success:true, data: {...}}` or `{success:true, user: {...}}`
  - Error: `{success:false, message:"..."}`
  - 403: `{success:false, message:"Forbidden"}`

## B. Frontend Auth Flow

### 1. Create js/auth.js
**File: `js/auth.js` (NEW)**
- Constants:
  - `API_BASE` from `window.API_BASE` or `localStorage.getItem("API_BASE")` or default `http://localhost:4001`
- Functions:
  - `getToken()` - reads from `localStorage.getItem("zf_token")`
  - `setAuth(token, user)` - stores `zf_token` and `zf_user` (JSON stringified)
  - `clearAuth()` - removes `zf_token` and `zf_user`
  - `apiFetch(path, options)` - auto-adds `Authorization: Bearer <token>`, handles 401 → redirect to login.html
  - `getMe()` - calls `GET /api/auth/me`, returns user object
  - `guardPage({allowedRoles:[], requirePasswordChange:false})`:
    - If no token → redirect to login.html
    - Call `/me`, if `mustChangePassword` true → redirect to change-password.html
    - If role not in `allowedRoles` → show 403 page or redirect to login

### 2. Update login.html
**File: `login.html`**
- Include `<script src="js/auth.js"></script>` before existing scripts
- Update login form handler:
  - Use only `/api/auth/user-login` (remove admin login fallback)
  - Store ONLY: `localStorage.setItem("zf_token", token)` and `localStorage.setItem("zf_user", JSON.stringify(user))`
  - If `mustChangePassword === true` → redirect to `change-password.html`
  - Else redirect based on role:
    - `admin` → `admin-dashboard.html`
    - `manager` → `manager-dashboard.html`
    - `accountant` → `accountant-dashboard.html`
    - `financial_analyst` → `financial-dashboard.html`
    - `external` → `external-dashboard.html`
- Keep existing UI/design unchanged

### 3. Add Logout Functionality
**Files: All dashboard HTML files**
- Add logout button/functionality that:
  - Calls `clearAuth()` from `js/auth.js`
  - Redirects to `login.html`
- Can be added to existing profile menu or navigation

### 4. Update Dashboard Pages
**Files: `admin-dashboard.html`, `manager-dashboard.html`, `accountant-dashboard.html`, `financial-dashboard.html`**
- Include `<script src="js/auth.js"></script>` before dashboard scripts
- Replace existing `apiFetch` calls (if any) with `apiFetch` from `js/auth.js`
- Add `guardPage()` call at page initialization:
  - `admin-dashboard.html`: `guardPage({allowedRoles:["admin"]})`
  - `manager-dashboard.html`: `guardPage({allowedRoles:["manager"]})`
  - `accountant-dashboard.html`: `guardPage({allowedRoles:["accountant"]})`
  - `financial-dashboard.html`: `guardPage({allowedRoles:["financial_analyst"]})`

## C. Project Structure & Configuration

### 1. Environment Variables
**File: `backend/.env.example` (NEW or UPDATE)**
```
PORT=4001
MONGO_URI=
JWT_SECRET=
CORS_ORIGIN=http://localhost:5500,http://127.0.0.1:5500
NODE_ENV=development
```

### 2. Package.json Updates
**File: `backend/package.json`**
- Add dependencies:
  - `helmet`
  - `express-rate-limit`
  - `zod`

## D. Testing Checklist

After implementation, verify:
- [ ] Login works with `/api/auth/user-login`
- [ ] `/api/auth/me` returns correct user data
- [ ] Accountant cannot access admin endpoints (403)
- [ ] Expired token sends user to login (401)
- [ ] Manager cannot access other companies' data (tenant scoping)
- [ ] Rate limiting works on `/api/auth/*` endpoints
- [ ] All API responses follow `{success, message, data/user}` format
- [ ] Frontend `guardPage()` redirects correctly based on roles
- [ ] Logout clears auth and redirects to login

## Implementation Order

1. Backend dependencies and security middleware
2. JWT standardization and auth middleware updates
3. Validation layer and error handler
4. `/api/auth/me` endpoint
5. Frontend `js/auth.js` creation
6. Login page updates
7. Dashboard page updates with `guardPage()`
8. Logout functionality
9. Testing and verification